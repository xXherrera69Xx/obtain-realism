<!DOCTYPE html>
<html lang="es">

<head>
  <title><?php echo $page; ?> • Fooder</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Viex Inc.">

  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
  <link rel="icon" sizes="192x192" href="../../images/Logo Fooder icono.png">
  <link href="../../css/style_layout1.css" rel="stylesheet">

  <script src="../../js/bootstrap.bundle.js"></script>
  <script src="../../js/jquery.min.js"></script>
</head>

<body>

  <?php
  // Traigo todas las funciones necesarias
  require_once "../../includes/functions.php";
  // Traigo el menu
  require_once('../../includes/menu.php');
  ?>

  <!-- Empieza el contenido especifico -->
  <div class="container ">
    <?php require_once($section . ".php") ?>
  </div>
  <!-- Termina el contenido especifico -->

  <div id="scroll-up">
    <i class="bi bi-chevron-up"></i>
  </div>

  <script src="../../js/main.js" type="text/javascript"></script>
</body>

</html>