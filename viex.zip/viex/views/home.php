<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <!--Inicio del carousel-->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <a href="searches.php?search=empanada">
        <div class="overlay-image" style="background-image:url(../../images/categories/15/category_empanada.jpg);"></div>
      </a>
      <div class="carousel-caption d-none d-md-block">
        <h3>Empanadas</h3>
        <p>Categoria</p>
      </div>
    </div>
    <div class="carousel-item">
      <a href="searches.php?search=pizza">
        <div class="overlay-image" style="background-image:url(../../images/categories/13/pizza.jpg);"></div>
      </a>
      <div class="carousel-caption d-none d-md-block">
        <h3>Pizzas</h3>
        <p>Categoria</p>
      </div>
    </div>
    <div class="carousel-item">
      <a href="searches.php?search=pasta">
        <div class="overlay-image" style="background-image:url(../../images/categories/17/category_pastas.jpg);"></div>
      </a>
      <div class="carousel-caption d-none d-md-block">
        <h3>Pastas</h3>
        <p>Categoria</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>


<div id="container__recipes">

</div>


<script src="../../js/recipes.js" type="text/javascript"></script>
<script src="../../js/reports.js" type="text/javascript"></script>
<script src="../../js/likes.js" type="text/javascript"></script>
<script src="../../js/delete.js" type="text/javascript"></script>