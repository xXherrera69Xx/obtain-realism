<div class="container-v5">
  <div class="container__submenu">
    <div class="container__submenu-accounts">
      <a href="../web/mod_accounts.php" aria-selected="false" id="submenu__item-recipes">Cuentas</a>
    </div>
    <div class="container__submenu--recipes">
      <a href="../web/mod_recipes_reported.php" aria-selected="true" id="submenu__item-recipes">Recetas reportadas</a>
    </div>
    <div class="container__submenu-comments">
      <a href="../web/mod_comments_reported.php" aria-selected="false" id="submenu__item-recipes">Comentarios reportados</a>
    </div>
    <div class="container__submenu-categories">
      <a href="../web/mod_categories.php" aria-selected="false" id="submenu__item-recipes">Categorias</a>
    </div>
  </div>
</div>

<div id="container__specific"></div>

<script src="../../js/mod/recipes_reported.js" type="text/javascript"></script>