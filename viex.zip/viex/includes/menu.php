<div class="container-v4 sticky-top">


  <nav class="container__menu justify-content-lg-between">
    <a href="home.php" class="container__menu--logo">
      <img class="bi" src="../../images/Logo Fooder icono.PNG" alt="Logo" width="50">
    </a>


    <form action="../web/searches.php" method="GET" class="container__menu--search col-8 col-sm-4" id="principal__seeker">
      <input type="search" class="container__menu--text form-control" placeholder="Buscar..." name="search" value="<?php echo (isset($search)) ? $search : null; ?>" id="principal__seeker--search">
      <button type="submit" class="container__menu--submit"><i class="bi bi-search" style="font-size: 1.2rem; padding-right: 3px;"></i></button>
    </form>

    <div class="">
      <ul class="container__menu--nav">
        <li><a href="../web/home.php" title="Inicio" class="container__menu--nav-item"><i class="bi bi-house-door px-2" id="home"></i></a></li>
        <li><a href="../web/recipes_followed.php" title="Recetas seguidas" class="container__menu--nav-item"><i class="bi bi-people px-2" id="recipes_followed"></i></a></li>
        <?php if (isset($_SESSION['user'])) { ?>
          <li><a href="../web/post_recipe.php" title="Publicar recetas" class="container__menu--nav-item"><i class="bi bi-plus-circle px-2" id="post_recipe"></i></a></li>

          <li>
            <div class="dropdown ps-2" data-bs-toggle="modal" data-bs-target="#miModal">
              <img title="Opciones de perfil" class="container__menu--nav-profile dropbtn" src="<?php echo profile_pic($_SESSION['user']['id']); ?>" alt="foto perfil" id="btn_profile"></abbr>

              <div id="dropdown_profile" class="dropdown-content">
                <p class="dropdown-content__name">Iniciado sesión como <b><?php echo $_SESSION['user']['username'] ?></b></p>
                <a class="dropdown-content__profile" href="../web/profile.php?id=<?php echo $_SESSION['user']['id']; ?>"><img src="../../images/icons/user.png" width="18px" class="me-2"> Perfil</a>
                <a class="dropdown-content__setting" href="../web/edit_profile.php"><img src="../../images/icons/settings.png" width="18px" class="me-2" alt=""> Configuracion</a>
                <?php if ($_SESSION['user']['role_id'] == 3) { ?>
                  <a class="dropdown-content__admin" href="../web/mod_accounts.php"><img src="../../images/icons/admin.png" width="18px" class="me-2"> Administrador</a>
                <?php } else if ($_SESSION['user']['role_id'] == 2) { ?>
                  <a class="dropdown-content__moder" href="../web/mod_accounts.php"><img src="../../images/icons/crown.png" width="18px" class="me-2"> Moderador</a>
                <?php } ?>
                <a class="dropdown-content__logout" href="../web/logout.php"><img src="../../images/icons/log-out.png" width="18px" class=" me-2"> Salir</a>

              </div>
            </div>
          </li>
        <?php } else { ?>
          <li><a href="../web/login.php" class="container__menu--nav-item"><i class="bi bi-plus-circle px-2"></i></a></li>
          <li><a href="../web/login.php"><button type="button" class="container__menu--nav-button">Iniciar sesión</button></a></li>

        <?php } ?>
      </ul>
    </div>
  </nav>
</div>