<?php

//session_start();

require_once "../../../includes/config.php";
require_once "../../../includes/functions.php";

$page = (isset($_POST['page'])) ? $_POST['page'] : 1;

if ($_POST['for'] == 'categories_mod') {
  if (isset($_SESSION['user']) && $_SESSION['user']['role_id'] != 1) {
    //Para categorias
    $sqlCategories = "SELECT categories.* FROM categories";
  }
}


$resultCategories = mysqli_query($conn, $sqlCategories);
if (!$resultCategories) {
  die('Error de Consulta' . mysqli_error($conn));
}

$amt_categories_page = ceil(mysqli_num_rows($resultCategories) / CANT_REG_PAG);

$sqlCategories .= " LIMIT " . CANT_REG_PAG * ($page - 1) . ", " . CANT_REG_PAG;
$resultCategories = mysqli_query($conn, $sqlCategories);
if (!$resultCategories) {
  die('Error de Consulta' . mysqli_error($conn));
}
$rowCategories = mysqli_fetch_all($resultCategories, MYSQLI_ASSOC);

foreach ($rowCategories as $key => $value) {
  $rowCategories[$key]['category_img'] = category_pics($value['id']);
}

$message = [
  'message' => "Hecho",
  'user_logged_id' => (isset($_SESSION['user']['id'])) ? $_SESSION['user']['id'] : null,
  'categories' => $rowCategories,
  'amt_categories_page' => $amt_categories_page
];

header("Content-Type: application/json; charset=utf-8");
return print_r(json_encode($message));
