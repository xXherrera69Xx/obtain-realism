<?php

//session_start();

require_once "../../../includes/config.php";

$dir = "../../../images/profiles/" . $_SESSION['user']['id'];

if (is_dir($dir)) {
  // Borrar foto de perfil en archivos
  $files = scandir($dir, 1);
  foreach ($files as $file) {
    unlink($dir . "/" . $file);
  }
  // Eliminar directorio (necesita antes estar vacio para poder eliminarlo, por eso lo anterior)
  rmdir($dir);
}
header("Location: ../edit_profile.php");
