<?php
//session_start();

require_once "../../../includes/config.php";

$photo = $_FILES['avatar']['tmp_name'];
$img_type = $_FILES['avatar']['type'];
$img_size = $_FILES['avatar']['size'];

if (strpos($img_type, "jpeg") || strpos($img_type, "png") || strpos($img_type, "gif") || strpos($img_type, "webp")) {
  if ($img_size < 3000000 /*3MB*/) {
    // Verifico si existe una carpeta en images/profile. Si no existe, la creo. Si existe entro y borro los archivos que tiene (no las carpetas), luego lo cierro
    $dir = "../../../images/profiles/" . $_SESSION['user']['id'];
    if (!is_dir($dir)) {
      mkdir($dir);
    } else {
      $files = scandir($dir, 1);
      foreach ($files as $file) {
        unlink($dir . "/" . $file);
      }
    }

    $ruta = "images/profiles/" . $_SESSION['user']['id'] . "/" . $_FILES['avatar']['name'];
    move_uploaded_file($photo, "../../../" . $ruta);
    header("Location: ../edit_profile.php");
  } else {
    // El archivo pesa mas de 3MB. Sirve para los mensajes de error
    header("Location: ../edit_profile.php");
  }
} else {
  // El archivo no es jpeg, png o gif. Sirve para los mensajes de error
  header("Location: ../edit_profile.php");
}
