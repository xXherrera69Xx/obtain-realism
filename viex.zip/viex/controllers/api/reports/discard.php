<?php

require_once "../../../includes/config.php";
require_once "../../../includes/functions.php";

if ($_SESSION['user']['role_id'] != 1) {
  $update = "UPDATE reports 
      SET verdict = '".$_POST['verdict']."' , admin_id = ".$_SESSION['user']['id'].", resolved_at = now() 
      WHERE id = ".$_POST['id'];
  
  $result_update = mysqli_query($conn, $update);
  if (!$result_update) {
    die('Error de Consulta' . mysqli_error($conn));
  }  
}



$message = [
  'message' => "Hecho",
  'action' => "Descartar reporte"
];

header("Content-Type: application/json; charset=utf-8");
return print_r(json_encode($message));
