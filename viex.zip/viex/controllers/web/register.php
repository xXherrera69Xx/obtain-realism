<?php
require_once "../../includes/config.php";


$page = "Registrate";
$section = "register";
require_once('../../views/layout2.php');
