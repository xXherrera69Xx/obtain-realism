<?php

//session_start();

require_once "../../includes/config.php";


$page = "Recetas seguidas";
$section = "recipes_followed";
require_once "../../views/layout.php";
