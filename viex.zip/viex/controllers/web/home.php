<?php

//session_start();

require_once "../../includes/config.php";


$page = "Inicio";
$section = "home";
require_once "../../views/layout.php";
