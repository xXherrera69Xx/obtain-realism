var file = document.getElementById('file');
var cant_files = 0;
var aux = 0;
var formData = new FormData();

var rutaAbsoluta = location.href;
var id = rutaAbsoluta.split("=").pop();

getImgs();

function getImgs() {
  $.ajax({
    url: '../api/recipes/has_imgs.php?id=' + id,
    dataType: 'JSON',
    success: function (data) {
      if (data) {
        var keys = Object.keys(data)
        for (i = 0; i < keys.length; i++) {
          createThumbnail(data[keys[i]], i, data[keys[i]], 'img_server');
          cant_files++;
        }
        if (cant_files == 4) {
          $("#selectfile").attr("disabled", true);
        }
      }
    }
  });
}

$("#selectfile").click(function () {
  $(file).click();
});

file.addEventListener('change', function (e) {
  if (cant_files < 4) {
    if (cant_files + file.files.length < 5) {
      // Agrego a la cantidad de archivos que ya hay "subidos", los que quiere subir
      cant_files += file.files.length;

      for (var i = 0; i < file.files.length; i++) {
        // Creo nombre ramdom para cada imagen que "sube"
        var thumbnail_id = Math.floor(Math.random() * 30000) + '_' + Date.now();
        createThumbnail(file, i, thumbnail_id);
        // Agrego cada imagen al formData
        formData.append(thumbnail_id, file.files[i]);

      }
      if (cant_files == 4) {
        $("#selectfile").attr("disabled", true);
      }

      e.target.value = '';
    } else {
      // Esta intentando subir mas fotos de las que puede
      message_imgs = "Elige hasta 4 fotos"
    }

  }

});

// Mandar a traves de un fetch con un formData, los datos del formulario
function editRecipe(title, intro = null, ingredients, steps) {
  formData.append('title', title);
  formData.append('introduction', intro);
  formData.append('ingredients', ingredients);
  formData.append('steps', steps);
  formData.append('id', id);

  fetch('../api/recipes/edit.php', {
    method: 'POST',
    body: formData
  })
    .then(function (response) {
      return response.json();
    })
    .then(function (data) {
      console.log(data);

      if (data.message == 'Se actualizó correctamente la receta') {
        window.location.href = "../web/home.php";
        clearImgToRemoveAndThumbnails();
      } else {
        // Este alert es temporal
        alert(data.message + " " + data.message_img)
      }
    })
    .catch(function (err) {
      console.log(err);
    });
}

var createThumbnail = function (file_or_img_server, iterator = '', thumbnail_id, type = 'file') {
  var thumbnail = document.createElement('div');
  thumbnail.classList.add('thumbnail', thumbnail_id, type);
  thumbnail.dataset.id = thumbnail_id

  thumbnail.setAttribute('style', `background-image: url(${(type != 'file') ? `../../images/recipes/${id}/${file_or_img_server}` : URL.createObjectURL(file_or_img_server.files[iterator])})`);
  document.getElementById('preview-images').appendChild(thumbnail);
  createCloseButton(thumbnail_id);
}

// Crear boton para cerrar cada imagen
var createCloseButton = function (thumbnail_id) {
  var closeButton = document.createElement('div');
  closeButton.classList.add('close-button');
  closeButton.innerHTML = '<i class="bi bi-x"></i>';
  document.getElementsByClassName(thumbnail_id)[0].appendChild(closeButton);
}

var clearImgToRemoveAndThumbnails = function () {
  // Guardo en un array todas las claves del formData
  keys = [...formData.keys()];
  // Borro todo el contenido del formData
  for (i = 0; i < keys.length; i++) {
    if (keys[i] != 'title' && keys[i] != 'introduction' && keys[i] != 'ingredients' && keys[i] != 'steps' && keys[i] != 'id') {
      formData.delete(keys[i]);
    }
  }

  $("#selectfile").attr("disabled", false);
  aux = 0;
  form.reset();
  // Dejo de mostrar las imagenes
  document.querySelectorAll('.thumbnail').forEach(function (thumbnail) {
    thumbnail.remove();
  });

  cant_files = 0;
  getImgs();
  // Mostrar aviso que diga que se actualizó correctamente la receta y darle dos opciones, ir a su perfil (para verla) y seguir editando
}

document.body.addEventListener('click', function (e) {
  // e = evento que ocurre
  // e.target = el elemento al cual le pasa el evento  
  // parentNode = al padre del elemento
  if (e.target.classList.contains('bi-x')) {
    e.target.parentNode.parentNode.remove();
    // El dataset.id tiene el valor del respectivo thumbnail_id
    if (e.target.parentNode.parentNode.classList.contains('img_server')) {
      // Las imagenes que ya estaban en la receta, si son agregadas al formData, significa que el usuario las quiere eliminar
      formData.append(`imgs_to_remove[${aux}]`, e.target.parentNode.parentNode.dataset.id);
      aux++;
    } else {
      formData.delete(e.target.parentNode.parentNode.dataset.id);
    }

    if (cant_files == 4) {
      $("#selectfile").attr("disabled", false);
    }
    cant_files--;
  }
});




window.addEventListener('load', () => {
  const form = document.getElementById('form')
  const title = document.getElementById('title')
  const intro = document.getElementById('intro')
  const steps = document.getElementById('steps')
  const ingredients = document.getElementById('ingredients')

  form.addEventListener('submit', (e) => {
    e.preventDefault()
    validarango()
  })

  const validarango = () => {
    const titlevalue = title.value.trim()
    const ingredientsvalue = ingredients.value.trim()
    const introvalue = intro.value.trim()
    const stepsvalue = steps.value.trim()
    habilitar = 0;

    //revisa los ingredientes
    if (!ingredientsvalue) {
      falla(ingredients, 'Ingrese los ingredientes sin caracteres especiales')
    } else if (ingredientsvalue.length > 500) {
      falla(ingredients, 'Demasiado largo')
    } else {
      ok(ingredients)
      habilitar++;
    }
    //revisa el titulo
    if (!titlevalue) {
      falla(title, 'Ingrese un titulo sin caracteres especiales')
    } else if (titlevalue.length > 75) {
      falla(title, 'El titulo debe ser más pequeño')
    } else {
      ok(title)
      habilitar++;
    }

    //revisa la introducción
    if (introvalue.length > 250) {
      falla(intro, 'La introducción debe ser menor')
    } else {
      ok(intro)
      habilitar++;
    }

    //revisa los pasos
    if (!stepsvalue) {
      falla(steps, 'Ingrese los pasos a seguir sin caracteres especiales')
    } else if (stepsvalue.length > 2000) {
      falla(steps, 'Ingrese pasos más cortos')
    } else {
      ok(steps)
      habilitar++;
    }

    if (habilitar == 4) {
      //document.getElementById("form").submit()}
      editRecipe(titlevalue, introvalue, ingredientsvalue, stepsvalue);
    }
  }

  const falla = (textarea, msj) => {
    const form = textarea.parentElement
    const warning = form.querySelector('p')
    warning.innerText = msj
    form.classList = 'form__container--content fail'
  }
  const ok = (textarea, msj) => {
    const form = textarea.parentElement
    const warning = form.querySelector('p')
    form.classList = 'form__container--content success'
  }
})