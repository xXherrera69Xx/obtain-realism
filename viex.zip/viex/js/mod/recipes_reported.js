let num_page = 1;
let num_page_reports = 1;
let data_recipes_reported;

loadRecipesReported();

$(window).on("scroll", function () {
  var scrollHeight = $(document).height();
  var scrollPosition = $(window).height() + $(window).scrollTop();
  if ((scrollHeight - scrollPosition) / scrollHeight === 0) {
    if (data_recipes_reported.amt_recipes_page >= num_page) {
      loadRecipesReported();
    }
  }
});


$(document).ready(function () {
  $("#container__specific").on("click", ".btn_see-more", function () {
    let recipe_id = this.id.split("_")[1];
    document.getElementById(`container-steps_${recipe_id}`).classList.toggle("d-none")

    if (this.innerText == "Ver más") {
      this.innerText = "Ver menos";
    } else {
      this.innerText = "Ver más";
    }
  })

  $("#container__specific").on("click", ".recipe_reports", function () {
    var id = this.id.split("_").pop()
    if (typeof $(`#modalReportsRecipes_${id}`)[0] == 'undefined') {
      loadReportsRecipes(id)
    }

    if (!document.getElementById(`modalReportsRecipes_${id}`).classList.contains('show')) {
      $(`#modalReportsRecipes_${id}`).modal('show')
    }
  })

  $("#container__specific").on("click", ".btn-close-modal-reports", function () {
    $(this).modal('hide')
    if (this.dataset.closeType == "btn-x") {
      var modal = this.parentNode.parentNode.parentNode.parentNode
    } else {
      var modal = this.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode
    }
    $(modal).remove()
    num_page_reports = 1
  })


  $("#container__specific").on("click", ".report-discard-ban", function () {
    if (typeof $(`.modal-footer`)[0] != 'undefined') {
      $(`.modal-footer`).remove()
    }

    let id = this.id.split("_").pop()
    let code_html = `
    <div class="modal-footer modal-footer-reports" id="modal-footer_${id}">
      <h6 class="m-0 mb-2">Sobre reporte: ${id}</h6>
      <form class="container__report--verdict form">
        <div class="container__inputs--reports">
          <div class="container__item--inputs">
            <span>Veredicto</span>
            <textarea class="form-control" placeholder="Ingrese un veredicto" name="verdict" required></textarea>
          </div>`
    if (this.id.includes("ban")) {
      code_html += `
          <div class="container__item--inputs">
            <span>Tiempo de ban (en horas)</span>
            <input type="text" class="form-control" name="time_banned" required> 
          </div>`
    }
    code_html += `
        </div>
        <div class="container__options--submit">
          <button type="button" class="btn btn-secondary btn-close-modal-reports" data-bs-dismiss="modal" data-close-type="btn-cancel">Cancelar</button>
          <button type="submit" class="btn btn-primary">${(this.id.includes("ban")) ? "Banear cuenta" : "Confirmar veredicto"}</button>
        </div>
      </form>
    </div>`;
    $(this.parentNode.parentNode.parentNode.parentNode.parentNode).append(code_html);

  })

  $("#container__specific").on("click", ".btn-view-more-reports", function () {
    let id = this.id.split("_").pop()
    document.getElementById(`text-view-more-report_${id}`).classList.toggle("d-none")

    if (this.innerText == "Ver más") {
      this.innerText = "Ver menos";
    } else {
      this.innerText = "Ver más";
    }
  })
})

function loadRecipesReported() {
  // Cargar recetas reportadas
  $.ajax({
    url: `../api/recipes/show.php`,
    type: 'POST',
    async: false,
    data: { page: num_page, for: "recipes_reported_mod" },
    dataType: 'JSON',
    success: function (data) {
      data_recipes_reported = data;
      recipes_reported = data_recipes_reported.recipes
      let code_html = ""
      recipes_reported.forEach(recipe => {
        code_html += `
          <div class="container-v3 recipe" id="recipe_${recipe.id}">
            <div class="container__user">
              <div>
                <a class="container__user--profilepicture" href="profile.php?id=${recipe.user_id}">
                  <img src="${recipe.profile_pic}" alt="foto perfil">
                </a>
              </div>
              <div class="container__user--name-date">
                <div class="container__user--username">
                  <a href="profile.php?id=${recipe.user_id}">${recipe.username}</a>
                </div>
                <div class="container__user--separator">
                  <span>•</span>
                </div>
                <div class="container__user--date">
                  <span for="dateUp">
                    ${recipe.created_at}
                  </span>
                </div>

              </div>
            </div>
            <div class="container__recipe">

              <div class="container__recipe--title">
                <span>
                  <h5>${recipe.title}</h5>
                </span>
              </div>`

        if (recipe.recipe_imgs != null) {
          code_html += `
              <div class="container__all-imgs">`;
          recipe.recipe_imgs.forEach(value => {
            code_html += `
                  <div class="container__img-recipe">
                    <img class="recipe__img-item" src="../../images/recipes/${recipe.id}/${value}" alt="foto receta">
                  </div>`;
          });
          code_html += `
              </div>`;
        }

        code_html += `<div class="container__recipe--content">`;

        if (recipe.introduction != "") {
          code_html += `
                <div class="container__recipe--introduction">
                  <span>${recipe.introduction}</span>
                </div>`;
        }

        code_html +=
          `<div class="container__recipe--ingredients">
                  <h6>Ingredientes</h6>
                  <span>${recipe.ingredients}</span>
                </div>
              </div>

              <div class="container__recipe--steps d-none" id="container-steps_${recipe.id}">
                <h6>Pasos</h6>
                <span>${recipe.steps}</span>
              </div>
              
              <div class="container__recipe--see-more">
                <a id="btn-see-more_${recipe.id}"  class="btn btn_see-more" role="button">Ver más</a>
              </div>

            </div>
            <div class="container__options--mod d-flex">
              <div class="recipe_reports container__btn--view-reports mt-2 " id="container-recipe-reports_${recipe.id}">
                <a id="recipe_reports_${recipe.id}" class="btn btn-light" role="button">Ver reportes</a>
              </div>
            </div>
          </div>`;

      })
      $('#container__specific').append(code_html);
      num_page++;
    }
  })

}

function loadReportsRecipes(recipe_id) {
  $.ajax({
    url: `../api/reports/show.php`,
    type: 'POST',
    async: false,
    data: { page: num_page_reports, for: "reports_recipes_mod", recipe_id: recipe_id },
    dataType: 'JSON',
    success: function (data) {

      data_reports_recipes = data;
      reports_recipes = data_reports_recipes.reports

      var code_html = `
        <div class="modal fade" id="modalReportsRecipes_${recipe_id}" data-bs-backdrop="static" data-modal-type="modal-view-reports" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-scrollable" style="max-width: 800px;">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Reportes de la cuenta: ${data_reports_recipes.username_reported}</h5>
                <button type="button" class="btn-close btn-close-modal-reports" data-bs-dismiss="modal" data-close-type="btn-x" aria-label="Close"></button>
              </div>
              <div class="modal-body">`

      reports_recipes.forEach(report_recipe => {

        code_html += `
                <div class="container__report">
                  <div class="container__data--report">
                    <div class="container__item--data">
                      <span>${report_recipe.id}</span>
                    </div>
                    <div class="container__item--data">
                      <span>${report_recipe.reporter_user_id}</span>
                    </div>
                    <div class="container__item--data">
                      <span>${report_recipe.created_at}</span>
                    </div>
                    <div class="container__item--data">
                      <span>${report_recipe.reason}</span>
                    </div>
                    <div class="container__item--data">
                      <div>
                        ${report_recipe.justification.slice(0, 220)}`
        if (report_recipe.justification.slice(220, 1000)) {
          code_html += `...
                        <span id="text-view-more-report_${report_recipe.id}" class="d-none">${report_recipe.justification.slice(220, 1000)}</span>
                        <button type="button" class="btn btn-view-more-reports p-0" id="view-more-report_${report_recipe.id}">Ver más</button>`
        }
        code_html += `
                      </div>
                    </div>
                  </div>
                  <div class="container__inputs--report">
                    <div class="container__btn--inputs">
                      <button type="button" class="btn btn-secondary report-discard-ban" id="btn-discard-report_${report_recipe.id}">Descartar reporte</button>
                    </div>
                    <div class="container__btn--inputs">
                      <button type="button" class="btn btn-danger report-discard-ban" id="btn-ban-account_${report_recipe.id}">Banear cuenta</button>
                    </div>
                  </div>
                </div>`;
      })

      code_html += `
                </div>
            </div>
          </div>
        </div>`;


      $(`#recipe_${recipe_id}`).append(code_html);
      num_page_reports++;

    }
  })
}
