var num_page = 1;
let num_page_reports = 1
let data_comments_reported;

loadCommentsReported();

$(window).on("scroll", function () {
  var scrollHeight = $(document).height();
  var scrollPosition = $(window).height() + $(window).scrollTop();
  if ((scrollHeight - scrollPosition) / scrollHeight === 0) {
    if (data_comments_reported.amt_comments_page >= num_page) {
      loadCommentsReported();
    }
  }
});

$(document).ready(function () {
  $("#container__specific").on("click", ".comment_reports", function () {
    var id = this.id.split("_").pop()
    if (typeof $(`#modalReportsComments_${id}`)[0] == 'undefined') {
      loadReportsComments(id)
    }

    if (!document.getElementById(`modalReportsComments_${id}`).classList.contains('show')) {
      $(`#modalReportsComments_${id}`).modal('show')
    }
  })

  $("#container__specific").on("click", ".btn-close-modal-reports", function () {
    $(this).modal('hide')
    if (this.dataset.closeType == "btn-x") {
      var modal = this.parentNode.parentNode.parentNode.parentNode
    } else {
      var modal = this.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode
    }
    $(modal).remove()
    num_page_reports = 1
  })


  $("#container__specific").on("click", ".report-discard-ban", function () {
    if (typeof $(`.modal-footer`)[0] != 'undefined') {
      $(`.modal-footer`).remove()
    }

    let id = this.id.split("_").pop()
    let code_html = `
    <div class="modal-footer modal-footer-reports" id="modal-footer_${id}">
      <h6 class="m-0 mb-2">Sobre reporte: ${id}</h6>
      <form class="container__report--verdict form">
        <div class="container__inputs--reports">
          <div class="container__item--inputs">
            <span>Veredicto</span>
            <textarea class="form-control" placeholder="Ingrese un veredicto" name="verdict" required></textarea>
          </div>`
    if (this.id.includes("ban")) {
      code_html += `
          <div class="container__item--inputs">
            <span>Tiempo de ban (en horas)</span>
            <input type="text" class="form-control" name="time_banned" required> 
          </div>`
    }
    code_html += `
        </div>
        <div class="container__options--submit">
          <button type="button" class="btn btn-secondary btn-close-modal-reports" data-bs-dismiss="modal" data-close-type="btn-cancel">Cancelar</button>
          <button type="submit" class="btn btn-primary">${(this.id.includes("ban")) ? "Banear cuenta" : "Confirmar veredicto"}</button>
        </div>
      </form>
    </div>`;
    $(this.parentNode.parentNode.parentNode.parentNode.parentNode).append(code_html);

  })

  $("#container__specific").on("click", ".btn-view-more-reports", function () {
    let id = this.id.split("_").pop()
    document.getElementById(`text-view-more-report_${id}`).classList.toggle("d-none")

    if (this.innerText == "Ver más") {
      this.innerText = "Ver menos";
    } else {
      this.innerText = "Ver más";
    }
  })
})

function loadCommentsReported() {
  // Cargar recetas reportadas
  $.ajax({
    url: `../api/comments/show.php`,
    type: 'POST',
    data: { page: num_page, for: "comments_reported_mod" },
    dataType: 'JSON',
    success: function (data) {
      data_comments_reported = data;
      let comments_reported = data_comments_reported.comments
      let code_html = ""

      comments_reported.forEach(comment => {
        code_html += `
          <div class="container-v3" id="comment_${comment.id}">
            <div class="container__user">
              <div class="container__user--profilepicture">
                <a href="profile.php?id=${comment.user_id}">
                  <img src="${comment.profile_pic}" alt="foto perfil">
                </a>
              </div>
              <div class="container__user--name-date">
                <div class="container__user--username">
                  <a href="profile.php?id=${comment.user_id}">${comment.username}</a>
                </div>
                <div class="container__user--separator">
                  <span>•</span>
                </div>
                <div class="container__user--date">
                  <span for="dateUp">
                    ${comment.created_at}
                  </span>
                </div>
              </div>
            </div>
            <div class="container__comment">
              <span>${comment.comment}</span>
            </div>
            <div class="container__options--mod d-flex">
              <div class="comment_reports container__btn--view-reports mt-2 " id="container-comment-reports_${comment.id}">
                <a id="comment_reports_${comment.id}" class="btn btn-light" role="button">Ver reportes</a>
              </div>
            </div>
          </div>`
      });
      $('#container__specific').append(code_html);
      num_page++;


    }
  })
}


function loadReportsComments(comment_id) {
  $.ajax({
    url: `../api/reports/show.php`,
    type: 'POST',
    async: false,
    data: { page: num_page_reports, for: "reports_comments_mod", comment_id: comment_id },
    dataType: 'JSON',
    success: function (data) {

      data_reports_comments = data;
      reports_comments = data_reports_comments.reports

      var code_html = `
        <div class="modal fade" id="modalReportsComments_${comment_id}" data-bs-backdrop="static" data-modal-type="modal-view-reports" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-scrollable" style="max-width: 800px;">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Reportes de la cuenta: ${data_reports_comments.username_reported}</h5>
                <button type="button" class="btn-close btn-close-modal-reports" data-bs-dismiss="modal" data-close-type="btn-x" aria-label="Close"></button>
              </div>
              <div class="modal-body">`

      reports_comments.forEach(report_comment => {

        code_html += `
                <div class="container__report">
                  <div class="container__data--report">
                    <div class="container__item--data">
                      <span>${report_comment.id}</span>
                    </div>
                    <div class="container__item--data">
                      <span>${report_comment.reporter_user_id}</span>
                    </div>
                    <div class="container__item--data">
                      <span>${report_comment.reason}</span>
                    </div>
                    <div class="container__item--data">
                      <div>
                        ${report_comment.justification.slice(0, 220)}`
        if (report_comment.justification.slice(220, 1000)) {
          code_html += `...
                        <span id="text-view-more-report_${report_comment.id}" class="d-none">${report_comment.justification.slice(220, 1000)}</span>
                        <button type="button" class="btn btn-view-more-reports p-0" id="view-more-report_${report_comment.id}">Ver más</button>`
        }
        code_html += `
                      </div>
                    </div>
                  </div>
                  <div class="container__inputs--report">
                    <div class="container__btn--inputs">
                      <button type="button" class="btn btn-secondary report-discard-ban" id="btn-discard-report_${report_comment.id}">Descartar reporte</button>
                    </div>
                    <div class="container__btn--inputs">
                      <button type="button" class="btn btn-danger report-discard-ban" id="btn-ban-account_${report_comment.id}">Banear cuenta</button>
                    </div>
                  </div>
                </div>`;
      })

      code_html += `
                </div>
            </div>
          </div>
        </div>`;


      $(`#comment_${comment_id}`).append(code_html);
      num_page_reports++;

    }
  })
}

