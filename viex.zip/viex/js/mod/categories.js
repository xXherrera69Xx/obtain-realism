var num_page = 1;

loadCategories();

var data_categories;

$(window).on("scroll", function () {
    var scrollHeight = $(document).height();
    var scrollPosition = $(window).height() + $(window).scrollTop();
    if ((scrollHeight - scrollPosition) / scrollHeight === 0) {
        loadCategories();
        //console.log(num_page)
    }
});

function loadCategories() {
	// Cargar cuentas reportadas

	$.ajax({
		url: `../api/categories/show.php`,
		type: "POST",
		data: { page: num_page, for: "categories_mod" },
		datatype: "JSON",
		success: function (data) {
			console.log(data);
			data_categories = data;
			categories = data_categories.categories;
			var code_html = ``;

			categories.forEach((category) => {
				code_html += `
          <div class="container-v3">
            <div class="container-all">`;

				if (category.category_img != null) {
					console.log(category.category_img[0]);
					code_html += `
              <div class="container__img">
                <img src="../../images/categories/${category.id}/${category.category_img[0]}" alt="foto perfil">
              </div>`;
				}
				code_html += `
              <div class="container__userdata">
                <div class="container__userdata--username">
                  <span>${category.name}</span>
                </div>
              </div>
              <div class="container__options--categories">
                <div class="container__edit--category">
                  <a href="#" class="btn btn-light" role="button">Editar</a>
                </div>
                <div class="container__delete--category">
                  <a href="#" class="btn btn-danger" role="button">Eliminar</a>
                </div>
              </div>
            </div>
          </div>`;
			});

			$("#container__specific").append(code_html);
			num_page++;
		},
	});
}
