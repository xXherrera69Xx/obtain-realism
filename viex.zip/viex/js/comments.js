// Paginador de comentarios
var num_page = 1;
var comments;
var rutaAbsoluta = location.href;
var recipe_id = rutaAbsoluta.split("=")[1];

loadComments();
$(window).on("scroll", function () {
  var scrollHeight = $(document).height();
  var scrollPosition = $(window).height() + $(window).scrollTop();
  if ((scrollHeight - scrollPosition) / scrollHeight === 0) {
    if (data_comments.amt_comments_page >= num_page) {
      loadComments();
    }

  }
});

var data_comments;
function loadComments() {
  $.ajax({
    url: `../api/comments/show.php`,
    type: 'POST',
    data: { page: num_page, recipe_id: recipe_id, for: "comments_publication" },
    dataType: 'JSON',
    success: function (data) {
      data_comments = data;
      comments = data_comments.comments

      comments.forEach(comment => {
        var code_html = `
          <div class="container-v3" id="comment_${comment.id}">
            <div class="container__user">
              <div class="container__user--profilepicture">
                <a href="profile.php?id=${comment.user_id}">
                  <img src="${comment.profile_pic}" alt="foto perfil">
                </a>
              </div>
              <div class="container__user--name-date">
                <div class="container__user--username">
                  <a href="profile.php?id=${comment.user_id}">${comment.username}</a>
                </div>
                <div class="container__user--separator">
                  <span>•</span>
                </div>
                <div class="container__user--date">
                  <span for="dateUp">
                    ${comment.created_at}
                  </span>
                </div>
              </div>
            </div>
            <div class="container__comment">
              <span>${comment.comment}</span>
            </div>

            <div class="container__feedback">`

        if (data_comments.user_logged_id == null) {
          code_html += `
              <div class="container__feedback--likes">
                <a class="" id="${comment.id}" href="login.php" role="button">
                  <img src="../../images/icons/nolike.png" width="22px" alt="like_icon">
                  <span>${comment.cant_likes}</span>
                </a>
              </div>
              <div class="container__feedback--report">
                <a class='btn' href="../web/login.php" role="button"><i class="bi bi-flag"></i></a>
              </div>`;

        } else {
          code_html += `
              <!--- Verificar si le dio o no like -->
              <div class="container__feedback--likes">
                <a class="btn comment_like" id="${comment.id}" role="button">
                  <img id="comment_img_${comment.id}" src="../../images/icons/${(comment.verify_like == null) ? "nolike" : "like"}.png" width="22px" alt="like_icon">
                  <span id="comment_likes_${comment.id}">${comment.cant_likes}</span>
                </a>
              </div>`;
          if (data_comments.user_logged_id == comment.user_id) {
            code_html += `
              <div class='container__delete-recipe'>
                <a class='btn btn-danger p-1 comment_delete' id="${comment.id}">Eliminar</a>
              </div>`;
          } else {
            code_html += `
            <div class="container__feedback--report">
              <a class="btn" data-bs-toggle="modal" data-bs-target="#modal-report_${comment.id}"><i class="bi bi-flag"></i></a>           
            </div>
            
            <div id="modal-report_${comment.id}" class="modal fade form-report" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <form method="POST" id="form-report_${comment.id}" class="modal-report-comments">
                  <div class="modal-header">
                    <h5 class="modal-title" >Denunciar receta</h5>
                    <button class="btn-close" type="reset" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <div class="radio">
                        <input type="radio" name="rep_why" id="cont_sex" value="cont_sex" checked>
                        <label for="cont_sex">Contenido sexual</label><br>
                        <input type="radio" name="rep_why" id="abus_men" value="abus_men">
                        <label for="abus_men">Abuso de menores</label><br>
                        <input type="radio" name="rep_why" id="fomen_terr" value="fomen_terr">
                        <label for="fomen_terr">Fomenta el terrorismo</label><br>
                        <input type="radio" name="rep_why" id="cont_copi" value="cont_copi">
                        <label for="cont_copi">Contenido plagiado</label><br>
                        <input type="radio" name="rep_why" id="inf_err" value="inf_err">
                        <label for="inf_err">Informacion errónea</label><br>
                        <input type="radio" name="rep_why" id="cont_ofens" value="cont_ofens">
                        <label for="cont_ofens">Contenido ofensivo</label><br>
                        <textarea id="comment-report-description_${comment.id}" required cols="30" rows="10" class="modal_form_textarea" placeholder="Agregar descripcion especifica de la infraccion" maxlength="500"></textarea>
                      </div>
                  </div>
                  <div class="modal-footer">
                    <div class="container-buttons">
                        <button class="btn" type="reset" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                    
                    <div class="container-buttons">
                        <button id="btn_submit_report" class="btn" type="submit" >Siguiente</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          `;
          }
        }

        code_html += `
            </div>
          </div>`;

        $('#container__comments').append(code_html);
      });

      num_page++;
    }
  });
}


// Validaciones y posteo de comentario
window.addEventListener('load', () => {
  const comment = document.getElementById('comment');

  form.addEventListener('submit', (e) => {
    e.preventDefault()
    validaCampos()
  })
  const validaCampos = () => {
    //caputrar los valores ingresados :)
    const commentvalue = comment.value.trim()
    var habilitar = 0;
    //validacion de comentario
    if (!commentvalue) {
      validafalla(comment, 'Ingrese un comentario')
    }
    else if (commentvalue.length > 1000) {
      validafalla(comment, 'Comentario demasiado largo')
    }
    else {
      validaOk(comment)
      habilitar++;
    }
    // validación para enviar el form
    if (habilitar == 1) {
      $.ajax({
        url: '../api/comments/post.php',
        type: 'POST',
        data: { recipe_id: recipe_id, comment: commentvalue },
        dataType: 'JSON',
        success: function (data) {
          console.log(data.message);
          if (data.message == "Se ha publicado correctamente el comentario") {
            // Insertar codigo html dentro del div con id = 'container__comments' antes de su primer hijo, es decir, al principio
            var code_html = `
              <div class="container-v3" id="comment_${data.id}">
                <div class="container__user">
                  <div class="container__user--profilepicture">
                    <a href="profile.php?id=${data.user_logged_id}">
                      <img src="${data.profile_pic}" alt="foto perfil">
                    </a>
                  </div>
                  <div class="container__user--name-date">
                    <div class="container__user--username">
                      <a href="profile.php?id=${data.user_logged_id}">${data.username}</a>
                    </div>
                    <div class="container__user--separator">
                      <span>•</span>
                    </div>
                    <div class="container__user--date">
                      <span for="dateUp">
                        ${data.created_at}
                      </span>
                    </div>
                  </div>
                </div>
                <div class="container__comment">
                  <span>${data.comment}</span>
                </div>
                <div class="container__feedback">
                  <!--- Verificar si le dio o no like -->
                  <div class="container__feedback--likes">
                    <a class="btn comment_like" id="${data.id}" role="button">
                      <img id="comment_img_${data.id}" src="../../images/icons/nolike.png" width="22px" alt="like_icon">
                      <span id="comment_likes_${data.id}">0</span>
                    </a>
                  </div>
                  <div class="container__delete-recipe">
                    <a class="btn btn-danger p-1 comment_delete" id="${data.id}">Eliminar</a>
                  </div>
                </div>
              </div>`;
            document.getElementById('container__comments').insertAdjacentHTML("afterbegin", code_html);
            document.getElementById('comment').value = "";

          } else {
            if (data.error_comment != null) {
              validafalla(comment, data.error_comment);
            }
          }
        }
      });
    }
  }
  const validafalla = (input, msje) => {
    const form = input.parentElement
    const warning = form.querySelector('p')
    warning.innerText = msje
    form.classList = 'container__textarea-comment fail'
  }
  const validaOk = (input, msje) => {
    const form = input.parentElement
    const warning = form.querySelector('p')
    warning.innerText = "";
    form.classList = 'container__textarea-comment success'
  }
});
