// ES IGUAL QUE RIGSTER.JS, PERO SIN PASSWORD Y CONFIRM PASSWORD

window.addEventListener('load', () => {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const username = document.getElementById("username");
    const biography = document.getElementById('biography')
    const form = document.getElementById("form");

    form.addEventListener('submit', (e) => {
        e.preventDefault()
        validaCampos()
    })
    const validaCampos = () => {
        //caputrar los valores ingresados :)
        const usernameValue = username.value.trim()
        const nameValue = name.value.trim()
        const emailvalue = email.value.trim()
        const bioValue = biography.value.trim()
        var expresiones =  /[^\x20\x2D0-9A-z\x5Fa-z\xC0-\xD6/xD8-\xF6\xF8-\xFF]/g;
        habilitar = 0;

        //validación de la biografia
        if(bioValue.length > 300){
            validafalla(biography, 'La biografia demasiado larga')
        }
        else{
            validaOk(biography)
            habilitar++;
        }


        //Validacion de username
        if (!usernameValue || usernameValue.match(expresiones)) {
            validafalla(username, 'Por favor ingrese un nombre de usuario sin caracteres especiales')
        }
        else if(usernameValue.length > 30 ){
            validafalla(username, 'Nombre de usuario demasiado largo')
        }
        else {
            validaOk(username)
            habilitar++;
        }

        //Validar email
        if (!emailvalue || !validaEmail(emailvalue)) {
            validafalla(email, 'Por favor ingrese un correo electronico valido')
        } else if(emailvalue.length > 300){
            validafalla(email, 'Correo demasiado largo')
           }
        else {
            validaOk(email)
            habilitar++;
        }

        //Validacion del nombre
        if (!nameValue || nameValue.match(expresiones)) {
            validafalla(name, 'Por favor ingrese un nombre sin caracteres especiales')
        }
        else if(nameValue.length > 50){
            validafalla(name, 'Nombre demasiado largo')
        }
        else {
            validaOk(name)
            habilitar++;
        }
    // validación para enviar el form
        if (habilitar == 4) {
            document.getElementById("form").submit()
        }
    }
    const validafalla = (input, msje) => {
        const form = input.parentElement
        const warning = form.querySelector('p')
        warning.innerText = msje
        form.classList = 'form__container--content fail'
    }
    const validaOk = (input, msje) => {
        const form = input.parentElement
        const warning = form.querySelector('p')
        form.classList = 'form__container--content success'
    }

    const validaEmail = (email) => {
        return /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,3}$/i.test(email);
    }
})