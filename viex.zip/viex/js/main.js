// Conseguir la pagina en la que se encuentra
var rutaRelativa = location.href.split("/").pop();

// Pintar de negro la pagina en la que estas (si esta se encuentra en la navbar)
if (rutaRelativa == "home.php") {
  document.getElementById("home").classList = 'bi bi-house-door-fill px-2'
} else if (rutaRelativa == "recipes_followed.php") {
  document.getElementById("recipes_followed").classList = 'bi bi-people-fill px-2'
} else if (rutaRelativa == "post_recipe.php") {
  document.getElementById("post_recipe").classList = 'bi bi-plus-circle-fill px-2'
}


$(document).ready(function () {

  // Dropdowns de toda la pagina
  $("body").on("click", ".dropbtn", function () {
    var dropdown_id = this.id.split("_")[1];
    //document.getElementById(`dropdown_${dropdown_id}`).classList.toggle("show");
    $(`#dropdown_${dropdown_id}`).toggle("fast")
  })


  // Close the dropdown menu if the user clicks outside of it
  window.onclick = function (event) {
    if (!event.target.matches(".dropbtn") && !event.target.parentNode.matches(".dropbtn")) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];

        if ($(openDropdown).css("display") == "block") {
          $(openDropdown).toggle("fast")
        }
      }
    }
  };


  //Boton scroll-up
  document.getElementById("scroll-up").addEventListener("click", scrollUp);

  function scrollUp() {
    var currentScroll = document.documentElement.scrollTop || document.body.scrollTop;

    if (currentScroll > 0) {
      window.requestAnimationFrame(scrollUp);
      window.scrollTo(0, currentScroll - (currentScroll / 7))
    }
  }

  window.onscroll = function () {
    var scroll = document.documentElement.scrollTop;

    if (scroll > 500) {
      document.getElementById("scroll-up").style.transform = "scale(1)";
    } else if (scroll < 500) {
      document.getElementById("scroll-up").style.transform = "scale(0)";
    }
  }

})
