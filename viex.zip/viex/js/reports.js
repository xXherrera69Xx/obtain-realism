$(document).ready(function () {

  $("#container__recipes").on("submit", ".modal-report-recipes", function (e) {
    e.preventDefault();
    var recipe_reported_id = this.id.split("_")[1];
    var rep_why = $('input[name=rep_why]:checked').val();
    var justification = $(`#recipe-report-description_${recipe_reported_id}`).val();

    $.ajax({
      url: '../api/recipes/reports.php',
      type: 'POST',
      data: { recipe_reported_id: recipe_reported_id, rep_why: rep_why, justification: justification },
      dataType: 'JSON',
      success: function (data) {
        console.log(data);
        $(`#form-report_${recipe_reported_id}`)[0].reset()
        $(`#modal-report_${recipe_reported_id}`).modal('hide')
      }
    })

  });

  $("#container__comments").on("submit", ".modal-report-comments", function (e) {
    e.preventDefault();
    var comment_reported_id = this.id.split("_")[1]; 
    var rep_why = $('input[name=rep_why]:checked').val();
    var justification = $(`#comment-report-description_${comment_reported_id}`).val();

    $.ajax({
      url: '../api/comments/reports.php',
      type: 'POST',
      data: { comment_reported_id: comment_reported_id, rep_why: rep_why, justification: justification },
      dataType: 'JSON',
      success: function (data) {
        console.log(data);
        $(`#form-report_${comment_reported_id}`)[0].reset()
        $(`#modal-report_${comment_reported_id}`).modal('hide')
      }
    })

  });

  $("#container__profiles").on("submit", ".modal-report-profile", function (e) {
    e.preventDefault();
    var profile_reported_id = this.id.split("_")[1]; 
    var rep_why = $('input[name=rep_why]:checked').val();
    var justification = $(`#profile-report-description_${profile_reported_id}`).val();

    $.ajax({
      url: '../api/users/reports.php',
      type: 'POST',
      data: { profile_reported_id: profile_reported_id, rep_why: rep_why, justification: justification },
      dataType: 'JSON',
      success: function (data) {
        console.log(data);
        $(`#form-report_${profile_reported_id}`)[0].reset()
        $(`#modal-report_${profile_reported_id}`).modal('hide')
      }
    })

  });
});
