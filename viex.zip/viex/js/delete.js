window.addEventListener('load', function () {
  $("#container__recipes").on("click", ".recipe_delete", function () {
    var id = this.id;

    $.ajax({
      url: '../api/recipes/disable.php',
      type: 'POST',
      data: { id: id },
      dataType: 'JSON',
      success: function (data) {
        if (data['estado'] == 'borrado') {
          if (data['aux'] == 'publication') {
            window.history.back();
          }
          $(`#recipe_${id}`).remove();
        }
      }
    });

  });

  $("#container__comments").on("click", ".comment_delete", function () {
    var id = this.id;

    $.ajax({
      url: '../api/comments/disable.php',
      type: 'POST',
      data: { id: id },
      dataType: 'JSON',
      success: function (data) {
        if (data['estado'] == 'borrado') {
          $(`#comment_${id}`).remove();
        }
      }
    });

  })
});