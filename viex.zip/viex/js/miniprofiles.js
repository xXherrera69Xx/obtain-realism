var num_page = 1;
var miniprofiles;
var rutaAbsoluta = location.href;
var rutaRelativa = rutaAbsoluta.split("/").pop();
var forWhat = rutaRelativa.split(".")[0];
var profile_id = rutaRelativa.split("=")[1];

if (forWhat == "searches") {
  // Consigo el valor de lo que quiere buscar
  var search = $('#principal__seeker--search').val();

  $("#principal__seeker").submit(function (event) {
    event.preventDefault()

    // Reestablesco valores del numero de paginas y vacio al contenedor
    num_page = 1;
    $('#container__profiles').html("")

    // Nuevo valor de busqueda 
    search = $('#principal__seeker--search').val();

    // Cambio parametros de la url
    window.history.pushState(null, null, `?search=${search}&for=user`);

    // Cambio href de los botones del submenu
    $("#item__submenu--accounts").attr('href', `../web/searches.php?search=${search}&for=user`);
    $("#item__submenu--recipes").attr('href', `../web/searches.php?search=${search}`);

    loadMiniProfiles();

  })
}

loadMiniProfiles();

$(window).on("scroll", function () {
  var scrollHeight = $(document).height();
  var scrollPosition = $(window).height() + $(window).scrollTop();
  if ((scrollHeight - scrollPosition) / scrollHeight === 0) {
    if (data_miniprofiles.amt_accounts_page >= num_page) {
      loadMiniProfiles();
    }

  }
});

var data_miniprofiles;
function loadMiniProfiles() {
  $.ajax({
    url: `../api/users/show.php`,
    type: 'POST',
    data: { page: num_page, for: forWhat, profile_id: profile_id, search: search },
    dataType: 'JSON',
    success: function (data) {
      data_miniprofiles = data;
      accounts = data_miniprofiles.accounts
      let code_html = ""
      console.log(data)

      if (typeof search != 'undefined') {
        code_html += `
          <p class="resultmessage">${data_miniprofiles.amt_total_reg} Resultados para la busqueda "${search}"</p>`
      }

      accounts.forEach(account => {
        code_html += `
          <div class="container-v3">
            <div class="container-all">
              <div class="container__img">
                <a href="profile.php?id=${account.id}">
                  <img src="${account.profile_pic}" alt="foto perfil">
                </a>
              </div>
              <div class="container__userdata">
                <div class="container__userdata--username">
                  <a href="profile.php?id=${account.id}">${account.username}</a>
                </div>`;

        if (account.biography != null) {
          code_html +=
            `<div class="container__userdata--description">
                  <span>${account.biography}</span>
                </div>`
        }

        code_html += `
              </div>`;

        if (data_miniprofiles.user_logged_id != null) {
          if (data_miniprofiles.user_logged_id != account.id) {
            code_html += `
              <!--- Verificar si lo sigue o no -->
              <div id="container-follow_${account.id}" class="user_follow container__user--${(account.verify_follow == null) ? "follow" : "unfollow"}">
                <a id="user_follow_${account.id}" class="btn btn-dark" role="button">${(account.verify_follow == null) ? "Seguir" : "Dejar de Seguir"}</a>
              </div>`;
          }
        } else {
          code_html += `
              <div class="container__user--follow">
                <a class="btn btn-dark" href="login.php" role="button">Seguir</a>
              </div>`;
        }

        code_html += `
            </div>
          </div>`;

        });
        
      $('#container__profiles').append(code_html);
      num_page++;
    }
  });
}

