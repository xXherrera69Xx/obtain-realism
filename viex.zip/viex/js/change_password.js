window.addEventListener('load', () => {
    const oldpass = document.getElementById("oldpass");
    const newpass = document.getElementById("newpass");
    const cnewpass = document.getElementById("cnewpass");
    const form = document.getElementById("form");

    // Capto el evento submit y prevengo su evento por defecto, luego llamo a la funcion que valida los campos
    form.addEventListener('submit', (e) => {
        e.preventDefault()
        validaCampos()
    })
    const validaCampos = () => {
        //caputrar los valores ingresados :)
        const oldpassValue = oldpass.value.trim()
        const newpassValue = newpass.value.trim()
        const cnewpassValue = cnewpass.value.trim()
        var expresiones =  /[^\x20\x2D0-9A-z\x5Fa-z\xC0-\xD6/xD8-\xF6\xF8-\xFF]/g;
        habilitar = 0;

        if (!oldpassValue) {
            validafalla(oldpass, 'Por favor ingrese su contraseña actual')
        } else {
            validaOk(oldpass)
            habilitar++;
        }
        //validar newpass
        if (!newpassValue || newpassValue.length < 8 || newpassValue.match(expresiones)) {
            validafalla(newpass, 'Ingrese una combinacion con al menos ocho caracteres y sin caracteres especiales')
        } else {
            validaOk(newpass)
            habilitar++;
        }
        //validar cnewpassacion
        if (!cnewpassValue) {
            validafalla(cnewpass, 'Por favor confirme su nueva contraseña')
        } else if (newpassValue != cnewpassValue) {
            validafalla(cnewpass, 'Asegurate de que ambas contraseñas coincidan.')
        } else {
            validaOk(cnewpass)
            habilitar++;
        }

        // Hago submit si todo salio bien
        if (habilitar == 3) {
            document.getElementById("form").submit()
        }
    }
    const validafalla = (input, msje) => {
        const form = input.parentElement
        const warning = form.querySelector('p')
        warning.innerText = msje
        form.classList = 'form__container--content  fail'
    }
    const validaOk = (input, msje) => {
        const form = input.parentElement
        const warning = form.querySelector('p')
        form.classList = 'form__container--content success'
    }
})