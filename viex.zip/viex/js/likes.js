window.addEventListener('load', function () {
  $("#container__recipes").on("click", ".recipe_like", function () {
    var id = this.id;

    $.ajax({
      url: '../api/recipes/likes.php',
      type: 'POST',
      data: { id: id },
      dataType: 'JSON',
      success: function (data) {
        var likes = data['like'];
        var cant_likes = $(`#recipe_likes_${id}`).text();
        if (likes == 'sumar') {
          $(`#recipe_likes_${id}`).html(parseInt(cant_likes) + 1);
          $(`#recipe_img_${id}`).attr("src", "../../images/icons/like.png");
        } else if (likes == 'restar') {
          $(`#recipe_likes_${id}`).html(parseInt(cant_likes) - 1);
          $(`#recipe_img_${id}`).attr("src", "../../images/icons/nolike.png");
        }
      }
    });

  });

  $("#container__comments").on("click", ".comment_like", function () {
    var id = this.id;

    $.ajax({
      url: '../api/comments/likes.php',
      type: 'POST',
      data: { id: id },
      dataType: 'JSON',
      success: function (data) {
        var likes = data['like'];
        var cant_likes = $(`#comment_likes_${id}`).text();
        if (likes == 'sumar') {
          $(`#comment_likes_${id}`).html(parseInt(cant_likes) + 1);
          $(`#comment_img_${id}`).attr("src", "../../images/icons/like.png");
        } else if (likes == 'restar') {
          $(`#comment_likes_${id}`).html(parseInt(cant_likes) - 1);
          $(`#comment_img_${id}`).attr("src", "../../images/icons/nolike.png");
        }
      }
    });

  })
});
