<?php
    require_once "includes/config.php";

    $section_login = "login-error";

    require_once "views/layout-login.php";
?>