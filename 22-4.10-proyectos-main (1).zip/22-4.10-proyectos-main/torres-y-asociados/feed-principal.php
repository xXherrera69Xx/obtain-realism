<?php
    require_once "includes/config.php";
    
    require_once "modelos/usuario-actual.php";

    require_once "modelos/feed-principal.php";

    $section = "feed-principal";
    
    require_once "views/layout.php";

?>