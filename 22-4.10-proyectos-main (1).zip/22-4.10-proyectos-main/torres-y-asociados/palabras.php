<h1>Palabras Prohibidas</h1>

<?php
    $palabras = file('listaasdasd.txt');

    print_r($palabras);
    
    echo "<br>Cantidad de palabras: ".count($palabras).'<br>';
    $comentario = trim("Son unos imbeciles");
    $comentario_separado = explode(' ', $comentario);
    echo "Comentario Original: ".$comentario.'<br>';
    print_r($comentario_separado);
    echo "<br>";
    $censorAjus = true;
    if($censorAjus){
        echo "Censurar: Si<br>";
    }else{
        echo "Censurar: No<br>";
    }
    
    function censComent($forbidenWords, $arrayComentario){
        /*foreach($wordsForbident as $wordForbident){
            //echo $wordForbident.'<br>';
            //for($i = 0; $i < $arrayComentario; $i++){
            foreach($arrayComentario as $arrayPalabra){

                if($wordForbident == $arrayPalabra){
                    echo " - Censura";
                }
            }//}
        }*/

        /*foreach($arrayComentario as $arrayPalabra){
            foreach($wordsForbident as $wordForbident){
                if($wordForbident == $arrayPalabra){
                    return true;
                }
            }
        }*/

        foreach($forbidenWords as $forbidenWord){
            echo $forbidenWord . '<br>';
            foreach($arrayComentario as $arrayPalabra){
                /*if($arrayPalabra == $forbidenWord){
                    echo "HOOOOOOOOOOOOOOOLAAAAAAAAAAAAAAAAAA";
                }*/

                switch($arrayPalabra){
                    case $forbidenWord:
                        return true;
                    default:
                        echo $forbidenWord;
                }
            }
        }
    }

    echo "Comentario Final: ";
    // Verifica si en los ajustes puso para censurar
    // En el caso de que puso para censurar
    if($censorAjus){
        $arrComentario = /*count($comentario_separado);*/ $comentario_separado;
        $comentarioFinal = false;
        $comentarioFinal = censComent($palabras, $arrComentario);
        if($comentarioFinal){
            echo "Este comentario ha sido censurado";
        }else{
            echo $comentario;
        }
    }
    // En el caso de que puso para NO censurar
    else{
        echo $comentario;
    }
    
?>