<?php
    require_once "includes/config.php";

    require_once "modelos/usuario-actual.php";

    $section = "ajustes-de-cuenta";
    
    require_once "views/layout.php";
?>