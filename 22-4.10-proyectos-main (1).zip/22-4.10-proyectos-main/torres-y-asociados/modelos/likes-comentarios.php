<?php 
    session_start();

    require_once "../includes/config.php";

    $comentarios = $_GET['idP'];

    $destinatario = $_GET['idD'];

    $comentario_like = $_GET['id'];
    
    $like_usuario = $_SESSION['usuario_id'];

    $respuesta_comentario = $_GET['idCom'];

    $idR = $_GET['idR'];

    $consulta1 = "SELECT * FROM comentarios_likes WHERE usuario_id = $like_usuario AND comentarios_id = $comentario_like";
    $validar_like = mysqli_query($conn, $consulta1);
    if(!$validar_like){
        die(mysqli_error($conn));
    }

    if(mysqli_num_rows($validar_like) == 1){
        $borrar_like = "DELETE FROM comentarios_likes WHERE comentarios_id = $comentario_like AND usuario_id = $like_usuario";
        if(!mysqli_query($conn, $borrar_like)){
            die(mysqli_error($conn));
        }

        /* Eliminar notificacion comentarios */
        $delete_notif = "DELETE FROM notificaciones WHERE comentarios_likes_id = $comentario_like AND usuario_id = $like_usuario";
        if(!mysqli_query($conn, $delete_notif)){
            die(mysqli_error($conn));
        }
    }

    else if (mysqli_num_rows($validar_like) == 0){

        $consulta2 = "INSERT INTO comentarios_likes (usuario_id, comentarios_id) VALUES ($like_usuario, $comentario_like)";
        if(!mysqli_query($conn, $consulta2)){
            die(mysqli_error($conn));
        }
        

        /*  Notificaciones comentarios  */
        $consulta3 = "INSERT INTO notificaciones VALUES (NULL,'Alguien le dio like a tu comentario', $like_usuario, $comentario_like, NULL, NOW(), $destinatario, NULL)";
        $query = mysqli_query($conn, $consulta3);
        if(!$query){
            die(mysqli_error($conn));
        }
    }

    // Respuestas likes //

    $sqlR = "SELECT * FROM respuestas_comentarios_likes WHERE usuario_id = $like_usuario AND respuestasComentarios_id = $idR";
    $queryR = mysqli_query($conn, $sqlR);
    if(!$query){
        die(mysqli_error($conn));
    }

    if(mysqli_num_rows($queryR) == 1){
        $delete_Rl = "DELETE FROM respuestas_comentarios_likes WHERE usuario_id = $like_usuario AND respuestasComentarios_id = $idR";
        if(!mysqli_query($conn, $delete_Rl)){
            die(mysqli_error($conn));
        }
    }

    else if (mysqli_num_rows($queryR) == 0){
        $add_rlike = "INSERT INTO respuestas_comentarios_likes VALUES (NULL, $like_usuario, $idR)";
        if(!mysqli_query($conn, $add_rlike)){
            die(mysqli_error($conn));
        }
    }
    
    if($respuesta_comentario != 0){
        header("Location: ../respuesta-comentarios.php?idCom=".$respuesta_comentario."&id=".$comentarios."&idR=".$idR);
    }
    else{
        header("Location: ../comentarios.php?id=".$comentarios."&idCom=0");
    }
?>