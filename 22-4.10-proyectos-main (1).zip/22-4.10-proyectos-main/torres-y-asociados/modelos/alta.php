<?php
    session_start();
    
    require_once "../includes/config.php";

    $nombreUsuario = $_POST['nombreUsuario'];
    $fechaNacimiento = $_POST['fechaNacimiento'];
    $genero_id = $_POST['genero_id'];
    $email = $_POST['email'];
    $clave = $_POST['clave'];
    /*$descripcion = "Ingrese una descripcion";*/
    $fotoPerfil = "img/foto-perfil-default.jpg";

    if (!empty($_POST)) {
        $sql = "INSERT INTO usuarios VALUES (
            null,
            '$nombreUsuario',
            '$fechaNacimiento',
            '$genero_id',
            '$email',
            '$clave',
            null,
            '$fotoPerfil',
            '1',
            '3',
            NOW(),
            null)";
        if (mysqli_query($conn, $sql)) {
            $result = mysqli_query($conn, "SELECT * FROM usuarios WHERE email = '$email'");
            if(!$result){
                die(mysqli_error($conn));
            }
            $actUser = mysqli_fetch_assoc($result);
            $_SESSION['usuario_id'] = $actUser['id'];
            header('Location: ../feed-principal.php');
        } else {
            die('Error de Consulta' . mysqli_error($conn));
        }
    }
?>