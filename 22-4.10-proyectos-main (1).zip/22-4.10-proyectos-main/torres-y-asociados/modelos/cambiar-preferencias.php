<?php
    // Va a comparar las distintas posibilidades de preferencias con las seleccionadas en el form
    require_once "../includes/config.php";
    require_once "usuario-actual.php";

    $temaSelect = $_POST['switch-cambiar-tema'] ?? 'off';
    $censMemeSelect = $_POST['switch-cens-meme'] ?? 'off';
    $censComentsSelect = $_POST['switch-cens-comentarios'] ?? 'off';
    $idiomaSelect = $_POST['select-language'];

    $query = "SELECT *, preferencias.id AS 'prefId' FROM preferencias
              INNER JOIN tema ON preferencias.tema_id=tema.id
              INNER JOIN censura_memes ON preferencias.censuraMemes_id=censura_memes.id
              INNER JOIN censura_comentarios ON preferencias.censuraComentarios_id=censura_comentarios.id
              INNER JOIN idioma ON preferencias.idioma_id=idioma.id
    ";
    $resultQuery = mysqli_query($conn, $query);
    if(!$resultQuery){
        die(mysqli_error($conn));
    }

    while($rowPrefs = mysqli_fetch_assoc($resultQuery)){
        $prefsOptions[] = $rowPrefs;
    }

    foreach($prefsOptions as $prefsOption){
        if($prefsOption['nombreTema'] == $temaSelect &&
            $prefsOption['estadoCensuraMeme'] == $censMemeSelect &&
            $prefsOption['estadoCensuraComentarios'] == $censComentsSelect &&
            $prefsOption['nombreIdioma'] == $idiomaSelect
        ){
            $updateIdPref = "UPDATE usuarios SET preferencias_id='".$prefsOption['prefId']."' WHERE id=".$user['id'];
            if(!mysqli_query($conn, $updateIdPref)){
                die(mysqli_error($conn));
            }
            break;
        }
    }

    header("Location: ../preferencias.php");
?>