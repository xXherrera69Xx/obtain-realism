<?php 
    $query = 'SELECT * FROM `usuarios` WHERE usuarios.id = '. $user["id"];
    $privilegios = mysqli_query($conn, $query);
    if(!$privilegios){
        die(mysqli_error($conn));
    }
    $privilegio = mysqli_fetch_assoc($privilegios);
    if($privilegio['privilegios_id'] == 1){
        echo('<div class="lista-usuarios-boton"><a class="link-lista-usuarios" href="'.RUTA.'/lista.php">' . $language['nav-bar']['btn-admin'] . '</a></div>');
        echo('<div class="home-boton" style="left: 155px;"><a class="link-lista-usuarios" href="#">' . $language['nav-bar']['btn-up'] . '</a></div>');
    }elseif($privilegio['privilegios_id'] == 2){
        echo('<div class="moderador-boton"><a class="link-lista-usuarios" href="#">' . $language['nav-bar']['btn-mod'] . '</a></div>');
        echo('<div class="home-boton" style="left: 150px;"><a class="link-lista-usuarios" href="#">' . $language['nav-bar']['btn-up'] . '</a></div>');
    }else{
        echo('<div class="home-boton" style="left: 105px;"><a class="link-lista-usuarios" href="#">' . $language['nav-bar']['btn-up'] . '</a></div>');
    }
?>