<?php
    $query = 'SELECT COUNT(*) FROM respuestas_comentarios_likes WHERE respuestasComentarios_id = '.$user_respuesta['re_id'].'';
    $likesR = mysqli_query($conn, $query);
    if(!$likesR){
        die(mysqli_error($conn));
    }

    if($likesCR = mysqli_fetch_assoc($likesR)){
        foreach($likesCR as $likes_amount){
            echo $likes_amount . " ";
        }
    }
?>