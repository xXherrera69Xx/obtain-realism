<?php 
    $query = 'SELECT COUNT(comentarios_id) FROM comentarios_likes WHERE comentarios_id = '. $user_comentario['com_id'] .'';
    $likes_amount = mysqli_query($conn, $query);
    if(!$likes_amount){
        die(mysqli_error($conn));
    }

    if($likes = mysqli_fetch_assoc($likes_amount)){
        foreach ($likes as $like_publicacion){
            if($like_publicacion == 0){
                echo "0 ";
            }
            else{
                echo $like_publicacion . " ";
            }
            
        }
    
    }
    
?>