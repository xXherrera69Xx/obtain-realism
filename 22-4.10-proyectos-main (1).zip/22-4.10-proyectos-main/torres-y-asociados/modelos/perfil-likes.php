<?php
    $multiquery = "SELECT COUNT(*) FROM publicaciones_likes INNER JOIN publicaciones ON publicaciones.id = publicaciones_likes.publicacion_id WHERE publicaciones.usuario_id = ". $user['id'] .";";
    $multiquery .= "SELECT COUNT(*) FROM comentarios_likes INNER JOIN comentarios ON comentarios.id = comentarios_likes.comentarios_id WHERE comentarios.usuario_id = ". $user['id'] .";";
    $multiquery .= "SELECT 	COUNT(*) FROM respuestas_comentarios_likes INNER JOIN respuestas_comentarios ON respuestas_comentarios.id = respuestas_comentarios_likes.respuestasComentarios_id WHERE respuestas_comentarios.usuario_id = ". $user['id'] .";";
    $likes = 0;
    if (mysqli_multi_query($conn, $multiquery)) {
        do {
            if ($resultLik = mysqli_store_result($conn)) {
                while ($row = mysqli_fetch_row($resultLik)) {
                $likes = $likes + $row[0];     
                }
            }
        } while (mysqli_next_result($conn));
    }
?>
