<?php
    session_start();

    $conn = mysqli_connect('localhost', 'root', '', 'memingos');

    if (isset($_SESSION['usuario_id'])) {
        $consultaUsur = "SELECT * FROM usuarios WHERE id = " . $_SESSION['usuario_id'] . ";";
        $resultUsur = mysqli_query($conn, $consultaUsur);
        if(!$resultUsur){
            die(mysqli_error($conn));
        }

        if (mysqli_num_rows($resultUsur) > 0) {
            $usu_info = mysqli_fetch_assoc($resultUsur);
            $user = $usu_info;
        }
    }else{
        header("Location: login.php");
    }

    /* --Notificaciones-- */

    //DESACTIVO ESTO TEMPORALMENTE
    
    $sqlU = 'SELECT * FROM `notificaciones` INNER JOIN usuarios ON usuarios.id = notificaciones.usuario_id AND destinatario = ' . $user['id'] .' LEFT JOIN comentarios ON comentarios.id = notificaciones.comentarios_likes_id OR comentarios.id = notificaciones.respuestasComentarios_id';
    $queryU = mysqli_query($conn, $sqlU);
    if(!$queryU){
        die(mysqli_error($conn));
    }

    while($rows_notif = mysqli_fetch_assoc($queryU)){
        $notificaciones[] = $rows_notif;
        // Establezco fecha de notificacion
        $send_date = $rows_notif['fechaNotificacion'];
        $current_date = date('Y-m-d'); 
        $datetime1U = date_create($send_date);
        $datetime2U = date_create($current_date);
        $counter = date_diff($datetime1U, $datetime2U);
        $differenceFormatU = '%a';
        $actual_date = $counter->format($differenceFormatU);
    }


    /* --Preferencias-- */

    $sqlPreferencias = "SELECT * FROM preferencias INNER JOIN usuarios ON usuarios.preferencias_id = preferencias.id WHERE usuarios.id ='" . $user['id'] . "'";
    $resultPreferencias = mysqli_query($conn, $sqlPreferencias);
    if(!$resultPreferencias){
        die(mysqli_error($conn));
    }

    while($rowPreferencias = mysqli_fetch_assoc($resultPreferencias)){
        $preferences[] = $rowPreferencias;
    }

    foreach($preferences as $preference){
        if($preference['tema_id'] == '2'){
            $clase = "dark"; // Tema Oscuro
        }else{
            $clase = ""; // Tema Claro
        }

        if($preference['censuraComentarios_id'] == '2'){
            $censuraComent = false; // No Censurar Coments
        }else{
            $censuraComent = true; // Censurar Coments
        }

        if($preference['idioma_id'] == '2'){
            $lang = 'english'; // Ingles
        }else{
            $lang = 'spanish'; // Espanol
        }

        if($preference['censuraMemes_id'] == '2'){
            $censuraMeme = false; // No censurar Memes
        }else{
            $censuraMeme = true; // Censurar Memes
        }
    }

    // PREFERENCIAS - Language
    $language = parse_ini_file("languages/$lang.ini", true);
?>