<?php
    // Usuario al que queremos seleccionar para ver su perfil
    $id=$_GET["id"];
    $query="SELECT * FROM usuarios WHERE id =" .$id;
    $result = mysqli_query($conn,$query);
    if(!$result){
        die(mysqli_error($conn));
    }
    $userFor = mysqli_fetch_assoc($result);

    // Cantidad de publicaciones del usuario
    $query2 = "SELECT * FROM publicaciones WHERE usuario_id = ". $id ." ORDER BY id DESC LIMIT 6";
    $result2 = mysqli_query($conn,$query2);
    if(!$result2){
        die(mysqli_error($conn));
    }
    $publicaciones = mysqli_fetch_assoc($result2);
    $cantPublicaciones = mysqli_num_rows($result2);
?>
   