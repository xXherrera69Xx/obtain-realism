<?php
    $like_comentario = $_GET["id"];
    $publicacion = $_GET["id"];
    $query = "SELECT *, comentarios.id as com_id FROM comentarios INNER JOIN usuarios ON comentarios.usuario_id = usuarios.id AND comentarios.publicacion_id = '$publicacion'";
    $result = mysqli_query($conn, $query);
    

    if(!$result){
        die('Error de Consulta' . mysqli_error($conn));
    }

    while ($comentarios = mysqli_fetch_assoc($result)) {
        $user_comentarios[] = $comentarios;
        $fechaEnvio = $comentarios['fechaComentario'];
        $fechaActual = date('Y-m-d');
        $datetime1 = date_create($fechaEnvio);
        $datetime2 = date_create($fechaActual);
        $contador = date_diff($datetime1, $datetime2);
        $differenceFormat = '%a';
        $fechaPublicado = $contador->format($differenceFormat);
    }

    /* --Respuestas Comentarios-- */

    $query2 = "SELECT *, respuestas_comentarios.id as re_id FROM respuestas_comentarios INNER JOIN usuarios ON respuestas_comentarios.usuario_id = usuarios.id WHERE publicacion_id = '$publicacion'";
    $result2 = mysqli_query($conn, $query2);
    if(!$result2){
        die(mysqli_error($conn));
    }

    while ($respuestasComentarios = mysqli_fetch_assoc($result2)){
        $user_respuestas[] = $respuestasComentarios;
        $fechaEnvio2 = $respuestasComentarios['fechaRespuesta'];
        $fechaActual2 = date('Y-m-d');
        $datetime2_1 = date_create($fechaEnvio2);
        $datetime2_2 = date_create($fechaActual2);
        $contador = date_diff($datetime2_1, $datetime2_2);
        $differenceFormat2 = '%a';
        $fechaResPublicado = $contador->format($differenceFormat2);
    }
?>