<?php 

    // Codigo desechable para producto final //
    if($user_respuesta['destinatario'] == NULL){
        echo $user_comentario['nombreUsuario'];
    }
    ///////////////////////////////////////////
    else{
    $nick_query = 'SELECT * FROM `respuestas_comentarios` INNER JOIN usuarios ON usuarios.id = respuestas_comentarios.destinatario AND destinatario = '.$user_respuesta['destinatario'].'';
    $nick = mysqli_query($conn, $nick_query);

    if(!$nick){
        die(mysqli_error($conn));
    }
    
    $nickname = mysqli_fetch_assoc($nick);
        
    echo $nickname['nombreUsuario'];
}
?>