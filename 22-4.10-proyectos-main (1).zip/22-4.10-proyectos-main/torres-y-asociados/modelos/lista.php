<?php

   $sql = "SELECT * FROM usuarios";
   $res = mysqli_query($conn, $sql);

   if(!$res){
       die('Error de Consulta' . mysqli_error($conn));
   }

   while($fila = mysqli_fetch_assoc($res)){
       $usuarios[] = $fila;
   }
   
   $sql2 = "SELECT * FROM publicaciones";
   $res2 = mysqli_query($conn, $sql2);

   if(!$res2){
       die('Error de Consulta' . mysqli_error($conn));
   }

   while($fila2 = mysqli_fetch_assoc($res2)){
       $publicaciones[] = $fila2;
   }

   $sql3 = "SELECT * FROM comentarios";
   $res3 = mysqli_query($conn, $sql3);

   if(!$res3){
    die('Error de Consulta' . mysqli_error($conn));
    }
    
    while($fila3 = mysqli_fetch_assoc($res3)){
        $comentarios[] = $fila3;
    }
    
    /* Likes de publicacion */

    $sql4 = "SELECT * FROM publicaciones_likes";
    $res4 = mysqli_query($conn, $sql4);
    if(!$res4){
        die(mysqli_error($conn));
    }
    
?>