<?php
    
    $actComentario = $_GET['idCom'];

    $sqlCom = "SELECT * FROM comentarios INNER JOIN usuarios ON comentarios.usuario_id = usuarios.id WHERE comentarios.id ='" . $actComentario . "'";

    $resultCom = mysqli_query($conn, $sqlCom);

    if(!$resultCom){
        die('Error de Consulta' . mysqli_error($conn));
    }

    while($comentarioResponder = mysqli_fetch_assoc($resultCom)){
        $comRespon[] = $comentarioResponder;
    }
        
    $actRcomentario = $_GET['idR'];

    $queryR = "SELECT * FROM respuestas_comentarios INNER JOIN usuarios ON respuestas_comentarios.usuario_id = usuarios.id AND respuestas_comentarios.id = '". $actRcomentario . "'";

    $resultRcom = mysqli_query($conn, $queryR);

    if(!$resultRcom){
        die('Error de Consulta' . mysqli_error($conn));
    }

    while($responderR = mysqli_fetch_assoc($resultRcom)){
        $responder[] = $responderR;
    }
    
?> 