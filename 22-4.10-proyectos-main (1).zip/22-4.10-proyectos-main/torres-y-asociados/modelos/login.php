<?php
    session_start();
    
    require_once '../includes/config.php';

    $emailInicio = $_POST['emailInicio'];
    $claveInicio = $_POST['claveInicio'];

    $validar_login = mysqli_query($conn, "SELECT * FROM usuarios WHERE email='$emailInicio' AND clave='$claveInicio'");
    if(!$validar_login){
        die(mysqli_error($conn));
    }
    if(mysqli_num_rows($validar_login) > 0){
        $actUser = mysqli_fetch_assoc($validar_login);
        $_SESSION['usuario_id'] = $actUser['id'];
        header("Location: ../feed-principal.php");
    }
    else{
        header("Location: ../login-error.php");
    }
?>