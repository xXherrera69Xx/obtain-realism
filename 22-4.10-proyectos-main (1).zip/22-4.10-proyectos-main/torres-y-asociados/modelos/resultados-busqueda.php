<?php
    $categ_buscada = $_POST['busqueda'];

    $query = "SELECT * FROM usuarios
        INNER JOIN publicaciones
        ON usuarios.id = publicaciones.usuario_id
        INNER JOIN publicaciones_categorias 
        ON publicaciones.id = publicaciones_categorias.publicacion_id 
        WHERE categoria1_nombre = '$categ_buscada'
        OR categoria2_nombre = '$categ_buscada'
        OR categoria3_nombre = '$categ_buscada'
        OR categoria4_nombre = '$categ_buscada'
        OR categoria5_nombre = '$categ_buscada'
        OR categoria6_nombre = '$categ_buscada'
        OR categoria7_nombre = '$categ_buscada'
        OR categoria8_nombre = '$categ_buscada'
        OR categoria9_nombre = '$categ_buscada'
        OR categoria10_nombre = '$categ_buscada'
        ORDER BY publicaciones.id DESC
    ";
    
    $res = mysqli_query($conn, $query);

    if(!$res){
        die('Error de Consulta' . mysqli_error($conn));
    }

    while($res_busqueda = mysqli_fetch_assoc($res)){
        $results_busqueda[] = $res_busqueda;
    }
?>