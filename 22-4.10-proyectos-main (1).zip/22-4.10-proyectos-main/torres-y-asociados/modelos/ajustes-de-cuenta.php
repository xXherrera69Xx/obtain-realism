<?php 
    require_once "../includes/config.php";
    require_once "../modelos/usuario-actual.php";


    $nombre=$_POST["nuevo-nombre"];

    if($nombre==""){
        $nombre=$user["nombreUsuario"];
    }
    
    $descripcion=$_POST["descripcion-usuario"];

    if($descripcion==""){
        $descripcion=$user["descripcion"];
    }

    $correo=$_POST["nuevo-correo"];

    if($correo==""){
        $correo=$user["email"];
    }

    $password=$_POST["password2"];

    if($password==""){
        $password=$user["clave"];
    }

    /*
        var_dump($nombre);
        var_dump($descripcion);
        var_dump($correo);
        var_dump($password);

    */

    //var_dump($_FILES["cambiar-foto"]);

   
    
    if($_FILES["cambiar-foto"]["error"]!=4){
        $nombre_archivo=$_FILES["cambiar-foto"]["name"];
        $ruta_foto="../users/" . $user['id'] . "/";
        $ruta_foto_db="users/" . $user['id'] . "/";
        
        //echo "estoy dentro";
        /*
        if(file_exists($ruta_foto . "foto-perfil.jpg")){
            unlink($ruta_foto . "foto-perfil.jpg");
            
        }*/

        $files = glob($ruta_foto . "*"); //obtenemos todos los nombres de los ficheros
        foreach($files as $file){
            if(is_file($file))
                unlink($file); //elimino el fichero

        }
        
        @mkdir($ruta_foto);

        if(!file_exists($ruta_foto)){
           @mkdir($ruta_foto, 0777, true);
        }

        $ruta_imagen=$ruta_foto . $nombre_archivo;
        $ruta_imagen_db=$ruta_foto_db . $nombre_archivo;
        $imagenValida=false;

        if (move_uploaded_file($_FILES['cambiar-foto']['tmp_name'], $ruta_imagen)) {
            $imagenValida = true;
        }
        
        if($imagenValida){
            
            $query_foto="UPDATE usuarios SET fotoPerfil='" . $ruta_imagen_db . "' WHERE id='" . $user["id"] . "'";
            
            if(!mysqli_query($conn, $query_foto)){
                die("Error de consulta: " . mysqli_error($conn));
            }
                


        }else{
            die("error al mover imagen, no seas matias monzon");
        } 
    }

    $query_info="UPDATE usuarios SET nombreUsuario='" . $nombre . "', descripcion='" . $descripcion . "', email='" . $correo . "', clave='" . $password . "' WHERE id='" . $user['id'] . "'";
    if(!mysqli_query($conn, $query_info)){
        die("Error de consulta: " . mysqli_error($conn));
    }

    header("Location: ../ajustes-de-cuenta.php");

?>