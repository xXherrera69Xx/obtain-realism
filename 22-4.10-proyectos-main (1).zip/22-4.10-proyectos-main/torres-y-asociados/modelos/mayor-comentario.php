<?php
$sqlCom = "SELECT COUNT(comentarios_id) AS cantLikesC, comentarios_id AS idCom,comentarios.contenidoComentario, usuarios.nombreUsuario,comentarios.usuario_id,usuarios.fotoPerfil,comentarios.publicacion_id FROM comentarios_likes INNER JOIN comentarios ON comentarios_likes.comentarios_id = comentarios.id INNER JOIN usuarios ON comentarios.usuario_id = usuarios.id GROUP BY comentarios_id ORDER BY COUNT(comentarios_id) DESC LIMIT 3;";
$res = mysqli_query($conn, $sqlCom);
if (!$res) {
    die('error de consulta');
}
while ($resultado = mysqli_fetch_assoc($res)) {
    $mayorCom[] = $resultado;
}
