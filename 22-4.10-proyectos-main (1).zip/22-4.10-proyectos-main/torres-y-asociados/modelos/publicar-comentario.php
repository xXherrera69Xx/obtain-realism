<?php
    session_start();

    include "../includes/config.php";

    $comentario = $_POST["comentar"];
    $publicacion = $_GET["id"];
    /* el id del usuario fue declarado en el archivo 'usuario-actual.php'*/
    $query = "INSERT INTO comentarios(usuario_id, publicacion_id, fechaComentario, contenidoComentario, tieneRespuesta) VALUES ('" .$_SESSION['usuario_id'] . "', '$publicacion', NOW(),'$comentario', 'NO')";
    
    if(!mysqli_query($conn, $query)){
        die(mysqli_error($conn));
    }
    
    header('Location:../comentarios.php?id='. $_GET["id"] .'&idCom=0');
?>