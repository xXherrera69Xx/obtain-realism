<?php

   $sql = "SELECT * FROM usuarios INNER JOIN publicaciones ON usuarios.id=publicaciones.usuario_id ORDER BY publicaciones.id DESC";
   $res = mysqli_query($conn, $sql);

   if(!$res){
       die('Error de Consulta' . mysqli_error($conn));
   }

   while($registro = mysqli_fetch_assoc($res)){
       $publicaciones[] = $registro;
   }
   
?>