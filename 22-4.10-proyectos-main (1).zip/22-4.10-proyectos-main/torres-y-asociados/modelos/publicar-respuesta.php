<?php
    require_once "usuario-actual.php";
    include "../includes/config.php";

    $respuesta = $_POST['respuesta'];
    $comentario = $_GET['idCom'];
    $publicacion = $_GET["id"];
    $destinatario = $_GET['idD'];

    /* el id del usuario fue declarado en el archivo 'usuario-actual.php'*/
    $usuario_actual = $user['id'];

    $query = "INSERT INTO respuestas_comentarios VALUES (
        NULL,
        $usuario_actual,
        '$comentario',
        '$publicacion',
        '$respuesta',
        NOW(),
        $destinatario)"
    ;

    if(!mysqli_query($conn, $query)){
        die('Error de Consulta' . mysqli_error($conexion));
    }

    $query2 = "UPDATE comentarios SET tieneRespuesta = 'SI' WHERE id = '$comentario'";
    if(!mysqli_query($conn, $query2)){
        die('Error de Consulta' . mysqli_error($conexion));
    }

    /* Notificaciones Respuestas */
    
    $notif_query = "INSERT INTO notificaciones VALUES (NULL, 'Alguien respondio tu comentario', $usuario_actual, NULL, NULL, NOW(), $destinatario, $comentario)";
    if(!mysqli_query($conn, $notif_query)){
        die('Error de Consulta' . mysqli_error($conexion));
    }

    header('Location:../comentarios.php?id='. $_GET["id"] .'&idCom=0');
?> 