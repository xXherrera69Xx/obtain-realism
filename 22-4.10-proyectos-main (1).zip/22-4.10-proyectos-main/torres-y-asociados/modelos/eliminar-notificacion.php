<?php
    require_once "../includes/config.php";
    
    /* Debido a que los comentarios dependen del id de la publicacion, traigo el idP desde el nav-bar */
    $publicacion_id = $_GET['idP'];
    $notificacion = $_GET['id'];
    $section = $_GET['section'];
    $comentario_id = $_GET['idCom'];

    $sql = "DELETE FROM notificaciones WHERE id_N = '".$notificacion."'";
    if(!mysqli_query($conn, $sql)){
        die(mysqli_error($conn));
    }
    if($section == "comentarios"){
        header("Location: ../" . $section . ".php?id=" . $publicacion_id . "&idCom=0"); 
    }
    else if($section == "respuesta-comentarios"){
        header('Location: ../' . $section . '.php?idCom=' . $comentario_id . '&id=' . $publicacion_id);
    }
    
    else{
        header('Location: ../'.$section.'.php');
    }
?>