<?php
    $sqlPref = "SELECT * FROM preferencias WHERE id='" . $user['preferencias_id'] . "'";
    $resultPref = mysqli_query($conn, $sqlPref);

    if(!$resultPref){
        die('Error de Consulta' . mysqli_error($conn));
    }

    while($preferencias = mysqli_fetch_assoc($resultPref)){
        $user_prefs[] = $preferencias;
    }

    foreach($user_prefs as $user_pref){
        /* --Idioma-- */
        if($user_pref['idioma_id'] == '1'){
            $idioma1 = "selected"; //spanish
            $idioma2 = ""; //english
        }else if($user_pref['idioma_id'] == '2'){
            $idioma2 = "selected"; //english
            $idioma1 = ""; //spanish
        }
        
        /* --Tema-- */
        if($user_pref['tema_id'] == '1'){
            $tema = "";
        }else if($user_pref['tema_id'] == '2'){
            $tema = "checked";
        }

        /* --Censura Comentarios-- */
        if($user_pref['censuraComentarios_id'] == '1'){
            $censComen = "checked";
        }else if($user_pref['censuraComentarios_id'] == '2'){
            $censComen = "";
        }

        /* --Censura Memes-- */
        if($user_pref['censuraMemes_id'] == '1'){
            $censMeme = "checked";
        }else if($user_pref['censuraMemes_id'] == '2'){
            $censMeme = "";
        }
    }
?>