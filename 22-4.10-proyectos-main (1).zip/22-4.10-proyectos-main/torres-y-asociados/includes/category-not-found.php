<section class="conteiner-categoria-no-encontrada">
    <div class="titulo-categoria-no-encontrada">
        <img src="<?php echo RUTA ?>/img/alert.png" class="alerta">
        <h2 class="texto-titulo">CATEGORIA NO ENCONTRADA</h2>
    </div>
    <img src="<?php echo RUTA ?>/img/capture.png" class="meme-categoria-no-encontrada">
    
    <p class="explicacion">La categoría que buscaste no existe por algunas de estas razones:</p>
    <ul class="lista-motivos">
        <li>Nadie creó esta categoría.</li>
        <li>La categoría no cumple con las normas de la página.</li>
    </ul>
</section>