<html>

<body>
    <form method="POST" action="modelo.php">
        <input name="mailU" type="text">
        <input type="text" name="Usu">
        <input type="submit">
    </form>
</body>

</html>