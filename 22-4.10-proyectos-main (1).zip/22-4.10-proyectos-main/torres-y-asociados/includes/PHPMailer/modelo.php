<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'Exception.php';
require 'PHPMailer.php';
require 'SMTP.php';

$mailU = $_POST["mailU"];
$Usuario = $_POST["Usu"];
$clave = random_int(100000, 999999);
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'memingos.etn26@gmail.com';                     //SMTP username
    $mail->Password   = 'tlhgpdlmolgxzjuu';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('memingos.etn26@gmail.com', 'Torres Y Asociados');
    $mail->addAddress($mailU, $Usuario);     //Add a recipient

    //Attachments
    //$mail->addAttachment('../../img/logo.png',);    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = "Restablecer Clave de Memingos" . "\r\n";
    $mail->Body    = '<html><body<div style="
    position: absolute; 
    left:30%; 
    font-family: "calibri";
    background-color: #070707cc;
    border: 1px solid #070707;
    border-radius:10px;
    padding:10px;
    color:white;
    ">
    <img src="https://i.pinimg.com/564x/89/f4/d1/89f4d1502091dd469e385bb3d4117e9c.jpg" width="100px" height="100px">
    <h3>Hola'.$Usuario.'<br>
    <br>
    Recibimos una solicitud para restablecer tu clave de Memingos.<br>
    Ingresa el siguiente codigo para restablecer la clave:<br>
    <br>
    <span style="border: 1px solid #00bbff;background-color:#00bbff38;padding:10px 20px; border-radius: 10px;">'.$clave.'</span>
    </h3>Si no quieres cambiar la clave, simplemente ignore este correo.<br>Atte.: <b>Torres y Asociados<b></div></body></html>';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}