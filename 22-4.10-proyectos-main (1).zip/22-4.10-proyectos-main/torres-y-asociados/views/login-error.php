<!-- Inicio de Sesion -->

<div class="container-index">
    <div class="forms-index">
        <form class="iniciar-sesion" method="POST" autocomplete="off" action="<?php echo RUTA ?>/modelos/login.php">
            <div class="logo-index"><img src="img/logoMemingos.png"></div>
            <div class="input-login">
                <input type="email" placeholder="Correo Electronico" class="input-index" name="emailInicio" style="border: 3px solid #cb1a1a" required>
                <input type="password" placeholder="Contraseña" class="input-index" name="claveInicio" style="border: 3px solid #cb1a1a" required>
                <div class="msg-error-inicio">
                    <p>Los datos ingresados son incorrectos</p>
                </div>
            </div>
            <a href="recuperacion-de-cuentas.php" class="link-recuperar-cuenta">¿Olvidaste tu contraseña?</a>
            <input type="submit" value="Iniciar Sesion" class="login-index">
        </form>

        <!-- Registro De Usuario -->
        <div class="register-index"><input type="checkbox" id="bts-modal">
            <label for="bts-modal" class="crear-cuenta">Crear nueva cuenta</label>
            <div class="modal">
                <div class="contenedor" id="cont">
                    <label for="bts-modal" id="cerrar" class="cerrar">X</label>
                    <div class="contenido-regis-cuenta">
                        <img src="img/logoMemingos.png" id="im2">
                        <form method="POST" action="<?php echo RUTA ?>/usuarios/alta.php" name="formulario_regis" id="formulario_regis" autocomplete="off">
                            <div class="usuario" id="usuario">
                                <input type="text" placeholder="Usuario" id="usu" name="nombreUsuario">
                            </div>

                            <div class="usuario" id="usuario">
                                <input type="text" placeholder="Email" id="mail" name="email">
                            </div>

                            <div class="usuario" id="usuario">
                                <input type="password" placeholder="Contrasena" id="clave" name="clave">
                            </div>

                            <div class="usuario" id="usuario">
                                <input type="password" placeholder="Confirmar Contrasena" id="clave2" name="clave2">
                            </div>

                            <p class="fecha">Fecha de Nacimiento:</p>
                            <div class="nacimiento">
                                <input type="date" id="nac" name="fechaNacimiento">
                            </div>

                            <div class="registro"><a href="javascript:registrarse()">Registrarse</a></div>

                            <p class="genero">Genero:</p>
                            <div class="radio">
                                <input type="radio" name="genero_id" id="hombre" value="1">
                                <label for="hombre">Hombre</label>
                                <input type="radio" name="genero_id" id="mujer" value="2">
                                <label for="mujer">Mujer</label>
                                <input type="radio" name="genero_id" id="personalizado" value="3">
                                <label for="personalizado">Personalizado</label>
                            </div>

                            <!-- Informacion de Datos Validos -->
                            <input type="checkbox" id="bts-modal-datos-val">
                            <label class="btn-datos-validos-info" for="bts-modal-datos-val"><span class="btn-datos-val-icon">?</span> Datos válidos</label>

                            <div class="modal-datos-val">
                                <div class="div-datos-val">
                                    <div class="encabezado">
                                        <h3 class="title-datos-val">Datos válidos</h3>
                                        <label for="bts-modal-datos-val" id="btn-cerrar-datos-val" class="btn-cerrar-datos-val">X</label>
                                    </div>

                                    <p class="p-datos-val">
                                        Nombre de Usuario: Maximo 15 caracteres alfanumericos y especiales.<br><br>
                                        Email: El correo electronico tiene que ser de Gmail.<br><br>
                                        Contraseña: Maximo 8 caracteres alfanumericos y especiales.<br><br>
                                        Edad: Tiene que ser entre 13 y 18 años.
                                    </p>
                                </div>
                            </div>
                            <div class="msg-error" id="msg-error">
                                <p>Los datos ingresados son incorrectos</p>
                            </div>
                            <div class="msg-correct" id="msg-correct">
                                <p>Los datos ingresados son correctos</p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>