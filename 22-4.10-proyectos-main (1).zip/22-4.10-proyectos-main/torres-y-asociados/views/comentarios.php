<section class="conteiner">
    <div class="div-comentarios">
        <!-- Obtengo todos los comentarios -->
        <?php require_once ('views/selector-comentarios.php');?>
    </div>
    <div class="acciones">
        <a href="<?php echo RUTA ?>/feed-principal.php#<?php echo $_GET['id'] ?>"><img src="<?php echo RUTA ?>/img/flecha.png" class="atras"></a>
        <img src="<?php echo $user['fotoPerfil']?>" class="img-usuario-comentarios">
        <form action="<?php echo RUTA ?>/modelos/publicar-comentario.php?id=<?php echo ($_GET['id'])?>&idR=<?php if(isset($_GET['idR'])){echo $_GET['idR'];}?>" method="POST" id="form_com">
            <input type="text" placeholder="Agregar un comentario..." class="input-comentario" name="comentar" maxlength="150" autocomplete="off" required>
            <input type="submit" class="enviar-comentario" value="">
        </form>
    </div>
</section>