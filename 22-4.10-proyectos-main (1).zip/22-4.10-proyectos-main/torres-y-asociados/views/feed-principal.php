<?php foreach ($publicaciones as $publicacion) { ?>
    <section class="conteiner-principal" id="<?php echo $publicacion['id']?>">
        <div class="persona">
            <img src="<?php echo $publicacion['fotoPerfil'] ?>" class="foto-perfil-publicacion">
            <a href="#" class="nombre-usuario"><?php echo $publicacion['nombreUsuario'] ?></a>
        </div>

        <div class="meme"> 
            <?php 
            if($censuraMeme == true && $publicacion['censura'] == 'on'){
                if($lang == 'spanish'){
                    echo "<img src='". RUTA . "/img/censored-ES.png'>";
                }else{
                    echo "<img src='". RUTA . "/img/censored-ENG.png'>";
                }
            }else{
                echo "<img src='".$publicacion['rutaImagen']."'>";
            }
            ?>
        </div>
        
        <div class="like-comentar">
            <div class="like">
                <a href="modelos/likes-publicacion.php?idP=<?php echo $publicacion['id']?>&id=<?php echo $publicacion['usuario_id']?>"><img src="<?php echo RUTA ?>/img/corazonvacio.png" width="60" height="60" align="right"
                    style="border-radius:10px; display: block;" id="corazon-vacio"></a>
                <a href="javascript:like_function()"><img src="<?php echo RUTA ?>/img/corazon.png" width="60" height="60" align="right"
                    style="border-radius:10px; display: none;" id="corazon"></a>
                <a href="javascript:like_function()" class="like-text" id="like-text"><?php require "modelos/cant-likes-publicacion.php"?></a>
            </div>
            
            <a href="<?php echo RUTA ?>/comentarios.php?id=<?php echo $publicacion['id']?>&idCom=0&idR=0" class="link-boton-comentar">
                <input type="button" class="boton-comentar" value="COMENTARIOS">
            </a>
        </div>
    </section>
<?php } ?>