<div class="tabla-usuarios-container">
    <table border="1" class="tabla-usuarios">
        <tr>
            <th>Nombre</th>
            <th>Fecha de Nacimiento</th>
            <th>Email</th>
            <th>Descripcion</th>
            <th>Borrar</th>
        </tr>

        <?php foreach ($usuarios as $usuario) { ?>
            <tr>
                <td><?php echo $usuario['nombreUsuario'] ?></td>
                <td><?php echo $usuario['fechaNacimiento'] ?></td>
                <td><?php echo $usuario['email'] ?></td>
                <td><?php echo $usuario['descripcion'] ?></td>
                <td><a href="modelos/eliminar.php?id=<?php echo $usuario['id'] ?>">Eliminar</a></td>
            </tr>
        <?php } ?>
    </table>
</div>

<div class="tabla-usuarios-container">
    <table border="1" class="tabla-usuarios">
        <tr>
            <th>Meme</th>
            <th>Fecha</th>
            <th>Eliminar publicacion</th>
        </tr>
        <?php foreach ($publicaciones as $publicacion) { ?>
        <tr>
                <td><?php echo $publicacion['rutaImagen'] ?></td>
                <td><?php echo $publicacion['fechaPublicacion'] ?></td>
                <td><a href="modelos/eliminar.php?id=<?php echo $usuario['id'] ?>">Eliminar</a></td>
            </tr>
        <?php } ?>
    </table>
</div>

<div class="tabla-usuarios-container">
    <table border="1" class="tabla-usuarios">
        <tr>
            <th>Id de Publicacion</th>
            <th>Fecha de publicacion</th>
            <th>Contenido</th>
            <th>Eliminar Comentario</th>
        </tr>
        <?php foreach ($comentarios as $comentario) {?>
            <tr>
                <td><?php echo $comentario['publicacion_id']?></td>
                <td><?php echo $comentario['fechaComentario']?></td>
                <td><?php echo $comentario['contenidoComentario']?></td>
                <td><a href="modelos/eliminar.php?id=<?php echo $comentario['id'] ?>">Eliminar</td>
            </tr>
        <?php } ?>
    </table>
</div>

<div class="tabla-usuarios-container">
    <table border="1" class="tabla-usuarios">
        <tr>
            <th>Id de publicacion</th>
            <th>Id del usuario</th>
            <th>Eliminar</th>
        </tr>
        <?php foreach ($comentarios as $comentario) {?>
            <tr>
                <td><?php echo $comentario['publicacion_id']?></td>
                <td><?php echo $comentario['fechaComentario']?></td>
                <td><?php echo $comentario['contenidoComentario']?></td>
                <td><a href="modelos/eliminar.php?id=<?php echo $comentario['id'] ?>">Eliminar</td>
            </tr>
        <?php } ?>
    </table>
</div>