<form action="modelos/cambiar-password-recup.php" method="POST" autocomplete="off">
    <div class="contenedor-cambiar-pass-recup">
        <div class="decor-recup-cuenta">
            <p class="title-recup-cuenta">Recuperar Cuenta</p>
            <img class="logo-recup-cuenta" src="img/logoMemingos.png">
        </div>
        <div class="contenido">
            <input type="password" class="input-cambiar-pass1" name="password" placeholder="Contraseña nueva" required>
            <input type="password" class="input-cambiar-pass2" name="confirm-password" placeholder="Confirmar Contraseña nueva" required>
            <input type="submit" class="btn-enviar-correo-recup-cuenta" value="Cambiar Contraseña">
        </div>
    </div>
</form>