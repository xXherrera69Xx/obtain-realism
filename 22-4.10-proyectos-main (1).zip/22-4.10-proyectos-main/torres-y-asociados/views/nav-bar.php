<header class="header">
    <div class="div-anim-clasificacion">
        <div class="boton-clasificacion">
            <a class="link-clasificacion" href="<?php echo RUTA ?>/clasificacion.php"><img src="<?php echo RUTA ?>/img/clasificacion-imagen.png" class="clasif-nav-bar"></a>
        </div>
    </div>

    <ul class="nav">
        <li class="nav-item i1"><a class="link-nav-opcion" style="cursor: pointer;"><img src="<?php echo RUTA ?>/img/icon-menu.png" class="img-nav-bar"></a>
            <div class="menu-conteiner">
                <ul class="list-conteiner">
                    <li class="menu-item"><a href="<?php echo RUTA ?>/perfil.php" class="link-nav-opcion"><i class="fa-solid fa-circle-user"></i> <?php echo $language['nav-bar']['btn-perfil'] ?></a></li>
                    <li class="menu-item"><a href="<?php echo RUTA ?>/ajustes-de-cuenta.php" class="link-nav-opcion"><i class="fa-solid fa-gear"></i> <?php echo $language['nav-bar']['btn-ajustesCuenta'] ?></a></li>
                    <li class="menu-item"><a href="<?php echo RUTA ?>/preferencias.php" class="link-nav-opcion"><i class="fa-solid fa-star"></i> <?php echo $language['nav-bar']['btn-preferencias'] ?></a></li>
                    <?php
                        if($section != "feed-principal" && $section != "comentarios" && $section != "respuesta-comentarios"){
                            echo ("<li class='menu-item'><a href='" . RUTA . "'/feed-principal.php' class='link-nav-opcion'><i class='fa-solid fa-circle-arrow-left'></i> ".$language['nav-bar']['btn-feedPrincipal']."</a></li>");
                        }
                    ?>
                </ul>
            </div>
        </li>
        <li class="nav-item i2">
            <form method="POST" action="resultados-busqueda.php">
                <input type="text" class="buscador" name="busqueda" autocomplete="off" required placeholder="&#128269; <?php echo $language['nav-bar']['buscador'] ?>">
                <input type="submit" style="display: none;">
            </form>    
        </li>
        <li class="nav-item i3">
            <input type="checkbox" id="bts-modal-publicar">
            <label for="bts-modal-publicar" class="nav-boton-publicar"><img src="<?php echo RUTA ?>/img/publicar.png" class="img-nav-bar"></label>
            <div class="modal-publicar">   
                <div id="container-subir-meme" class="container-subir-meme">
                    <form method="POST" action="modelos/publicar-meme.php" enctype="multipart/form-data">
                        <div class="opciones-meme">
                            <label class="p-input" style="cursor: pointer;" for="subir-meme"><?php echo $language['nav-bar']['btn-ingresarMeme'] ?></label>
                            <input type="file" id="subir-meme" name="meme" style="display: none;" accept="image/*, .gif" required>
                            <!-- <p class="p-input">e</p> -->
                            <input type="text" class="p-input" name="categorias" autocomplete="off" placeholder="<?php echo $language['nav-bar']['inp-ingresarCateg'] ?>" required>
                            <p class="categorias"><?php echo $language['nav-bar']['adv-categ'] ?></p>
                            <div class="censura-opts">
                                <input type="checkbox" name="btn-censurar" id="btn-censurar">
                                <label for="btn-censurar">Censurar</label>
                            </div>
                            
                        </div> 
                        <div class="publicar-buttons">
                            <label for="bts-modal-publicar" id="cerrar" class="close-publicar-button"><?php echo $language['nav-bar']['btn-descartar'] ?></label>
                            <input type="submit" value="<?php echo $language['nav-bar']['btn-publicar'] ?>" class="subir-meme-button">
                        </div>
                    </form>
                </div>
            </div>
        </li>
        <li class="nav-item i4"><a class="link-nav-opcion img-campana" style="cursor: pointer;"><img src="<?php echo RUTA ?>/img/campana.png" class="img-nav-bar"></a>
            <ul class="notificaciones-container">
                <?php if (isset($notificaciones)) {?>
                        <?php foreach ($notificaciones as $notificacion) {?>
                        <li class="notificacion">
                            <img src="<?php echo $notificacion['fotoPerfil'];?>" class="foto-usuario-not">
                            <?php if(isset($notificacion['publicaciones_likes_id'])){ ?>
                                <p class="mensaje-notificacion"><a href="feed-principal.php#<?php echo $notificacion['publicaciones_likes_id']?>"><?php echo $notificacion['contenidoNotificacion_id']?></a></p>
                            <?php } else if (isset($notificacion['comentarios_likes_id'])){?>
                                <p class="mensaje-notificacion"><a href="comentarios.php?id=<?php echo $notificacion['publicacion_id']?>&idCom=0"><?php echo $notificacion['contenidoNotificacion_id'];?></a></p>
                            <?php }else if(isset($notificacion['respuestasComentarios_id'])){?>
                                <p class="mensaje-notificacion"><a href="comentarios.php?id=<?php echo $notificacion['publicacion_id']?>&idCom=0"><?php echo $notificacion['contenidoNotificacion_id'];?></a></p>
                            <?php } ?>
                            <p class="fecha-notificacion"><?php echo $actual_date . 'd'?></p>
                            <div class="div-borrar-not"><a href="modelos/eliminar-notificacion.php?id=<?php echo $notificacion['id_N']?>&section=<?php echo $section?>&idP=<?php if(!isset($_GET['id'])){echo 0;}else{echo $_GET['id'];}?>&idCom=<?php if($section == 'respuesta-comentarios'){echo $_GET['idCom'];}?>" class="borrar-notificacion"><img src="<?php echo RUTA ?>/img/basura.png"></a></div>
                        </li>
                <?php } }  else {?>
                        <p class="notif-empty"><?php echo $language['nav-bar']['adv-notificaciones'] ?></p>
                <?php } ?>
            </ul>
        </li>
    </ul>
</header>
<?php if($section == "feed-principal"){
    include "carousel.php";
}?>
<?php require "modelos/privilegios.php" ?>