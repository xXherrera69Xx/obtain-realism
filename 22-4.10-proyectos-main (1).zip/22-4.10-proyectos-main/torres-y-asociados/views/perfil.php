<section class="contenedor">
    <div class="info-perfil">
        <div><img src="<?php echo $user['fotoPerfil']?>" class="foto-perfil-usuario"></div>
        <div><p class="info-puesto">&#9733; <?php echo $language['perfil']['adv-puesto'] ?> 1</p></div>
        <div><p class="info-nombre-usuario"><?php echo $user['nombreUsuario']?></p></div>
        <div><p class="info-likes">&#9829; <?php echo $likes?></p></div>
    </div>
    <p class="area-desc"><?php echo $user['descripcion']?></p>
    <div class="contenerdor-publicaciones">
        <p class="contador-publicaciones"><?php echo($cantPublicaciones." ".$language['perfil']['adv-publicaciones']) ?></p>
        <div class="publicaciones">
            <?php
                if(isset($publicaciones)){
                    do{?>
                        <article class="publicacion"><a href="#"><img src="<?php echo(RUTA ."/". $publicaciones["rutaImagen"])?>" class="img-publicacion"></a></article>
            <?php   }while($publicaciones = mysqli_fetch_assoc($result));
                } ?>
        </div>
    </div>
</section>