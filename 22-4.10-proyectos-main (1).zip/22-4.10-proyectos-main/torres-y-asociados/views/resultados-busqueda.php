<?php 
    if(isset($results_busqueda)){
        foreach ($results_busqueda as $result_busqueda) { ?>
            <section class="conteiner-principal">
                <div class="persona">
                    <img src="<?php echo $result_busqueda['fotoPerfil'] ?>" class="foto-perfil-publicacion">
                    <a href="#" class="nombre-usuario"><?php echo $result_busqueda['nombreUsuario'] ?></a>
                </div>

                <div class="meme">
                    <img src="<?php echo $result_busqueda['rutaImagen'] ?>">
                </div>
                
                <div class="like-comentar">
                    <div class="like">
                        <a href="javascript:like_function()"><img src="<?php echo RUTA ?>/img/corazonvacio.png" width="60" height="60" align="right"
                            style="border-radius:10px; display: block;" id="corazon-vacio"></a>
                        <a href="javascript:like_function()"><img src="<?php echo RUTA ?>/img/corazon.png" width="60" height="60" align="right"
                            style="border-radius:10px; display: none;" id="corazon"></a>
                        <a href="javascript:like_function()" class="like-text" id="like-text">Like</a>
                    </div>
                    
                    <a href="<?php echo RUTA ?>/comentarios.php?id=<?php echo $result_busqueda['id'] ?>" class="link-boton-comentar">
                        <input type="button" class="boton-comentar" value="COMENTARIOS">
                    </a>
                </div>
            </section>
        <?php }
    }else{
        include "includes/category-not-found.php";
    }   
?>