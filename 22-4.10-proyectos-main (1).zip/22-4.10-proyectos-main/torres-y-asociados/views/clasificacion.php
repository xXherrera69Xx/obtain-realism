<div class="contenedor-top">
    <div class="fila">
        <div class="columnas" style="width: 34%; border-radius:0px;">Puesto</div>
        <div class="columnas" style="width: 33%; border-radius:0px;">Usuario</div>
        <div class="columnas" style="width: 34%; border-radius:0px;">Me gustas</div>
    </div>
    
    <!-- *No Tocar >:(*
    <?php
        /*for($i=1; $i<11; $i++){ ?>
            <div class="fila">
                <div class="puesto-contenedor"><div class="puesto" style="color: gold;"><?php echo $i; ?></div></div>
                <div class="user-top-container">
                    <div class="prolife-image-top" style="color: gold;"><img src="images/quepro.jpg"></div>
                    <p class="username-top" style="color: gold;">pepe</p>
                </div>
                <div class="likes-contenedor" >
                    <div class="likes-image"><img src="images/corazon.png"></div>
                    <p class="likes-cantidad" style="color: gold;">120</p>
                </div>
            </div>
    <?php
        }*/
    ?> -->
    
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">1</div><abbr title="Estas en el 1° puesto!!!"><img src="img/medalladeoro.png"class="medallas"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top" style="color: gold;"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="oroLetra">pepe</p>
        </div>
        <div class="likes-contenedor" >
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad" style="color: gold;text-shadow: 0 0 1px black;">120</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">2</div><abbr title="Estas en el 2° puesto!!"><img src="img/medalladeplata.png"class="medallas"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top" style="border-color:darkgray;"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="plataLetra">francisco</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad" style="color:#1a1a1a;text-shadow: 0 0 1px black;">101</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">3</div><abbr title="Estas en el 3° puesto!"><img src="img/medalladebronce.png"class="medallas"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="bronceLetra">paul</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad" style="color:brown;text-shadow: 0 0 1px black;">98</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">4</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">torres</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">90</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">5</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">michael</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">87</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">6</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">federicasdaseo</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">85</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">7</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">matias</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">78</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">8</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">sebastian</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">73</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">9</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">diego</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">66</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">10</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">asociados</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">34</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">10</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">asociados</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">34</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">10</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">asociados</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">34</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">10</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">asociados</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">34</p>
        </div>
    </div>
    <div class="fila">
        <div class="puesto-contenedor"><div class="puesto-clasificacion">10</div><abbr title="Sube memes y consigue likes para subir de posición"><img src="img/medallanuv.png"class="medallasnuv"></abbr></div>
        <div class="user-top-container">
            <div class="prolife-image-top"><img src="<?php echo RUTA ?>/img/quepro.jpg"></div>
            <p class="username-top">asociados</p>
        </div>
        <div class="likes-contenedor">
            <div class="likes-image"><img src="<?php echo RUTA ?>/img/corazon.png"></div>
            <p class="likes-cantidad">34</p>
        </div>
    </div>
    <div class="filaF">
        <img src="<?php echo RUTA ?>/img/final-clas.png">
        <p>Final de la Clasificacion</p>
        <img src="<?php echo RUTA ?>/img/final-clas.png">
    </div>
</div>