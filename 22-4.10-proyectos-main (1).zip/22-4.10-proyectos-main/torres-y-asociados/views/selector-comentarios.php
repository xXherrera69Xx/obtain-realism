<?php
/* Aqui estan todos los comentarios */
if(isset($user_comentarios)){
    foreach ($user_comentarios as $user_comentario) { ?> 
        <div class="comentario">
            <a href="<?php echo RUTA ."/perfil-foraneo.php?id=" . $user_comentario['id'];?>" class="link-perfil"><img src="<?php echo RUTA ?>/<?php echo ($user_comentario['fotoPerfil']) ?>" class="img-usuario-comentarios"></a>
            <p class="text-comentario">
                <a href="<?php echo RUTA ."/perfil-foraneo.php?id=" . $user_comentario['id'];?>" class="link-nombre-perfil"><?php echo ($user_comentario['nombreUsuario']) ?></a>
                <?php
                    $palabras = file('includes/lista.txt');
                    if($censuraComent){
                        foreach($palabras as $palabra){
                            if($existWord = str_contains(strtolower($user_comentario['contenidoComentario']), trim($palabra))){
                                echo "<i>*Este comentario ha sido censurado*</i>";
                                break;
                            }
                        }
                        if(!$existWord){
                            echo ($user_comentario['contenidoComentario']);
                        }
                    }else{
                        echo ($user_comentario['contenidoComentario']);
                    }
                ?>
            </p>
            <?php
                if($fechaPublicado == 0){
                    echo('<p class="dia-comentario">Hoy</p>');
                }else{
                    echo('<p class="dia-comentario">'. $fechaPublicado .'d</p>');
                }
            ?>
            <p class="cant-likes"><?php require "modelos/cant-likes-comentarios.php"?>Me gusta</p>
            <a href="respuesta-comentarios.php?idCom=<?php echo $user_comentario['com_id']?>&id=<?php echo ($_GET['id'])?>&idR=0" class="btn-responder-comentario">Responder</a>
            <a href="modelos/likes-comentarios.php?id=<?php echo $user_comentario['com_id']?>&idP=<?php echo ($_GET['id'])?>&idD=<?php echo $user_comentario['usuario_id']?>&idCom=<?php echo ($user_comentario['com_id'])?>&idR=<?php echo $_GET['idR']?>" class="like-comentario"><img src="<?php echo RUTA ?>/img/corazonvacio.png" id="corazon-vacio" style="display: block;" class="img-like-comentario"></a>
            <a href="javascript:like_function()" class="like-comentario"><img src="<?php echo RUTA ?>/img/corazon.png" id="corazon" style="display: none;" class="img-like-comentario"></a>
        </div>
        <?php if($user_comentario['tieneRespuesta'] == 'SI') {?>
                <div class="div-respuestas">
                    <div class="flecha-btn-mostrar-respuesta"></div>
                    <input type="checkbox" id="<?php echo ($user_comentario['com_id']) ?>" class="btn-respuestas" style="display: none;" <?php if($_GET["idCom"] == $user_comentario['com_id']){echo "checked";}?>>
                    <label for="<?php echo ($user_comentario['com_id']) ?>" class="txt-mostrar-respuestas">Mostrar Respuestas</label>
                    <?php foreach ($user_respuestas as $user_respuesta) {
                            if($user_respuesta['comentario_id'] === $user_comentario['com_id']) {?>
                                <div class="conteiner-respuestas" id="<?php echo $user_respuesta['re_id']?>">
                                    <div class="respuestas">
                                        <a href="<?php echo RUTA ."/perfil-foraneo.php?id=" . $user_respuesta["id"];?>" class="link-perfil"><img src="<?php echo RUTA ?>/<?php echo ($user_respuesta['fotoPerfil']) ?>" class="img-usuario-comentarios"></a>
                                        <p class="text-comentario">
                                            <a href="<?php echo RUTA ."/perfil-foraneo.php?id=" . $user_respuesta["id"];?>" class="link-nombre-perfil"><?php echo ($user_respuesta['nombreUsuario']) ?></a>
                                            <a href="#" class="tag-user-res">@<?php str_replace(" ", "_", require "modelos/nickname-respuesta.php")?></a>
                                            <?php
                                                if($censuraComent){
                                                    foreach($palabras as $palabra){
                                                        if($existWord = str_contains(strtolower($user_respuesta['contenido']), trim($palabra))){
                                                            echo "<i>*Este comentario ha sido censurado*</i>";
                                                            break;
                                                        }
                                                    }
                                                    if(!$existWord){
                                                        echo ($user_respuesta['contenido']);
                                                    }
                                                }else{
                                                    echo ($user_respuesta['contenido']);
                                                }
                                            ?>
                                        </p>
                                        <?php
                                            if($fechaPublicado == 0){
                                                echo('<p class="dia-comentario">Hoy</p>');
                                            }else{
                                                echo('<p class="dia-comentario">'. $fechaResPublicado .'d</p>');
                                            }
                                        ?>
                                        <p class="cant-likes cant-likes-res"><?php require "modelos/cant-likes-respuestas.php"?>Me gusta</p>
                                        <a href="respuesta-comentarios.php?idCom=<?php echo $user_comentario['com_id']?>&id=<?php echo ($_GET['id'])?>&idR=<?php echo $user_respuesta['re_id']?>#<?php echo $user_respuesta['re_id']?>" class="btn-responder-comentario">Responder</a>
                                        <a href="modelos/likes-comentarios.php?idR=<?php echo $user_respuesta['re_id']?>&idP=<?php echo ($_GET['id'])?>&idD=<?php echo $user_respuesta['usuario_id']?>&idCom=<?php echo $_GET['idCom']?>id=0" class="like-comentario"><img src="<?php echo RUTA ?>/img/corazonvacio.png" id="corazon-vacio" style="display: block;" class="img-like-comentario"></a>
                                        <a href="javascript:like_function()" class="like-comentario"><img src="<?php echo RUTA ?>/img/corazon.png" id="corazon" style="display: none;" class="img-like-comentario"></a>
                                    </div>
                                </div>
                        <?php   }
                    }?>
                </div>
        <?php } ?>
    <?php   }
}?> 