<form method="POST" action="modelos/ajustes-de-cuenta.php" enctype="multipart/form-data">
  <section class="form-cambiar-datos">
    <div class="foto-perfil-ajustes">
      <img src="<?php echo $user['fotoPerfil'] ?>" class="foto">
      <div class="info">
        <p><?php echo $user['nombreUsuario'] ?></p>
        <label class="label-cambiar-foto" for="cambiar-foto"><?php echo $language['ajustesCuenta']['btn-cambiarFoto'] ?></label>
        <input type="file" name="cambiar-foto" id="cambiar-foto" style="display: none;" accept="image/*, .gif">
      </div>
    </div>
    <input class="controls" type="text" name="nuevo-nombre" id="nuevo-nombre" placeholder="<?php echo $language['ajustesCuenta']['inp-nuevoNombre'] ?>" maxlength="15">
    <textarea class="controls descripcion" name="descripcion-usuario" id="descripcion-usuario" maxlength="460" placeholder="<?php echo $language['ajustesCuenta']['inp-nuevaDescripcion'] ?>"></textarea>
    <p class="controls"><?php echo ($language['ajustesCuenta']['inp-actCorreo'] ." ".$user['email'])?></p>
    <input class="controls" type="email" name="nuevo-correo" id="nuevo-correo" placeholder="<?php echo $language['ajustesCuenta']['inp-nuevoCorreo'] ?>">
    <p class="controls"><?php echo $language['ajustesCuenta']['inp-actContrasena']." ".$user['clave']?></p>
    <input class="controls" type="password" name="password2" id="password2" placeholder="<?php echo $language['ajustesCuenta']['inp-nuevaContrasena'] ?>">
    <div class="botones-formulario">
      <input class="botons" id="guardar-cambios" type="submit" value="<?php echo $language['ajustesCuenta']['btn-guardar'] ?>">
      <div class="botons" id="cerrar-sesion"><a href="<?php echo RUTA ?>/modelos/cerrar-sesion.php" class="link-btn-cerrar-sesion"><?php echo $language['ajustesCuenta']['btn-logOut'] ?></a></div>
    </div>
  </section>
</form>