<?php
    $fondo= mt_rand(1,3);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?php echo RUTA ?>/img/logo.png">
    <link rel="stylesheet" href="<?php echo RUTA ?>/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo RUTA ?>/css/estilos.css">
    <script src="<?php echo RUTA ?>/js/main.js"></script>
    <script src="https://kit.fontawesome.com/962681b4cf.js" crossorigin="anonymous"></script>
    <title>Memingos</title>

</head>
<body <?php echo("class='".$clase."'")?>> <!-- style="background: url('img/fondo-<?php echo(intval($fondo)); ?>.png');" -->
    <?php
        require_once('nav-bar.php');

        require_once('anuncios.php');
        
        require_once($section . ".php");
    ?>
</body>