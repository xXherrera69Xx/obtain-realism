<section class="conteiner">
    <div class="div-comentarios">
        <div class="comentario-responder">
            <p class="title-respodiendo">Respondiendo a: </p>
            <?php
            if($_GET['idR'] != 0){
                foreach($responder as $respuesta){?>
                    <div class="comentario-respondiendo">
                        <a href="#" class="link-perfil-com-resp"><img src="<?php echo RUTA ?>/<?php echo ($respuesta['fotoPerfil']) ?>" class="img-usuario-comentarios"></a>
                        <p class="text-comentario">
                            <a href="#" class="link-nombre-perfil"><?php echo ($respuesta['nombreUsuario']) ?></a>
                            <?php echo ($respuesta['contenido']) ?>
                        </p>
                    </div>
            <?php } } else
                foreach ($comRespon as $com) { ?> 
                    <div class="comentario-respondiendo">
                        <a href="#" class="link-perfil-com-resp"><img src="<?php echo RUTA ?>/<?php echo ($com['fotoPerfil']) ?>" class="img-usuario-comentarios"></a>
                        <p class="text-comentario">
                            <a href="#" class="link-nombre-perfil"><?php echo ($com['nombreUsuario']) ?></a>
                            <?php echo ($com['contenidoComentario']) ?>
                        </p>
                    </div>
            <?php }?>
        </div>
        <div class="div-separador">
            <div class="separador-comentarios"></div>
            <p class="title-respodiendo title-otros-comentarios"> Otros Comentarios </p>
            <div class="separador-comentarios"></div>
        </div>
        <!-- Obtengo todos los comentarios -->
        <?php require_once ('views/selector-comentarios.php');?>
    </div>
    <div class="acciones">
        <a href="<?php echo RUTA ?>/comentarios.php?id=<?php echo $_GET['id'] ?>&idCom=0&idR=0"><img src="<?php echo RUTA ?>/img/flecha.png" class="atras"></a>
        <img src="<?php echo $user['fotoPerfil']?>" class="img-usuario-comentarios">
        <p class="destinatario-respuesta">@<?php if($_GET['idR'] != 0){echo str_replace(" ", "_",$respuesta['nombreUsuario']);} else{echo str_replace(" ", "_",$com['nombreUsuario']);}?></p>
        <form action="modelos/publicar-respuesta.php?id=<?php echo $_GET['id']?>&idCom=<?php echo $_GET['idCom']?>&idD=<?php if($_GET['idR'] != 0){echo $respuesta['usuario_id'];} else{echo $com['usuario_id'];}?>" method="POST" id="form_com">
            <input type="text" placeholder="Agregar respuesta..." class="input-respuesta" name="respuesta" maxlength="2200" autocomplete="off" required>
            <input type="submit" class="enviar-comentario" value="">
        </form>
    </div>
</section>