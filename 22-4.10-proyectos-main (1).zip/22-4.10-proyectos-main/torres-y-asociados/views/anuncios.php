<div class="anuncio-der">
    <a href="<?php echo RUTA ?>/includes/anuncio-sample.php" class="link-anuncio">
        <img src="<?php echo RUTA ?>/img/sample-anuncio.gif" class="img"></img>
    </a>
</div>

<div class="anuncio-izq">
    <a href="<?php echo RUTA ?>/includes/anuncio-sample.php" class="link-anuncio">
        <img src="<?php echo RUTA ?>/img/sample-anuncio.gif" class="img"></img>
    </a>
</div>