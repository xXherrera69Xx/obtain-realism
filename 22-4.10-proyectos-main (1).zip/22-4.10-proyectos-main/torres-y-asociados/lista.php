<?php
    require_once "includes/config.php";

    require_once "modelos/usuario-actual.php";

    require_once "modelos/lista.php";

    $section = "lista";

    require_once "views/layout.php";
?>