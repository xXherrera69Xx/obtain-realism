/* --Like Funcion-- */

function like_function(){
    if (document.getElementById("corazon-vacio").style.display == "block") {
        document.getElementById("corazon").style.display = "block";
        document.getElementById("corazon-vacio").style.display = "none";
        document.getElementById("like-text").style.color = "Red";
    } else if (document.getElementById("corazon-vacio").style.display == "none") {
        document.getElementById("corazon-vacio").style.display = "block";
        document.getElementById("corazon").style.display = "none";
        document.getElementById("like-text").style.color = "White";
    }
}

