function registrarse(){

    const campos = {
        usuario: false,
        correo: false,
        contra: false,
        contra2: false,
        edad_suf: false,
    }


    /* --Validar Nombre de Usuario-- */

    usuario_val = document.getElementById("usu").value;

    if(usuario_val.length >= 4 && usuario_val.length <= 15){
        document.getElementById("usu").style.border = "3px solid #003f68";
        campos.usuario = true;
    }else{
        document.getElementById("usu").style.border = "3px solid #cb1a1a";
    }


    /*comprobar clave */

    clave = document.getElementById("clave").value;
    clave2 = document.getElementById("clave2").value;

    if(clave.length < 8 && clave2.length < 8 && clave != clave2){
        /**error: clave menor k 8 y claves diferentes**/
        document.getElementById("clave").style.border = "3px solid #cb1a1a";
        document.getElementById("clave2").style.border = "3px solid #cb1a1a";
    }else if(clave.length == 0 && clave2.length == 0){
        /* clave vacia */
        document.getElementById("clave").style.border = "3px solid #cb1a1a";
        document.getElementById("clave2").style.border = "3px solid #cb1a1a";
    }else if(clave.length >= 8 && clave2.length >= 8 && clave === clave2){
        /* clave igualita y bien*/
        document.getElementById("clave").style.border = "3px solid #003f68";
        document.getElementById("clave2").style.border = "3px solid #003f68";
        campos.contra = true;
        campos.contra2 = true;
    }else if(clave.length >= 8 && clave2.length >= 8 && clave != clave2){
        /* clave no igualita y bien*/
        document.getElementById("clave").style.border = "3px solid #003f68";
        document.getElementById("clave2").style.border = "3px solid #cb1a1a";
        campos.contra = true;
    }else if(clave.length < 8 && clave2.length < 8 && clave === clave2){
        /* clave igualita y mal*/
        document.getElementById("clave").style.border = "3px solid #cb1a1a";
        document.getElementById("clave2").style.border = "3px solid #cb1a1a";
    }else if(clave.length < 8 && clave2.length >= 8){
        /**error clave menor k 8, clave mayor k  8, claves diferentes**/
        document.getElementById("clave").style.border = "3px solid #cb1a1a";
        document.getElementById("clave2").style.border = "3px solid #cb1a1a";
    }else if(clave.length >= 8 && clave2.length < 8){
        /**error clave mayor k 8, clave2 menor k  8, claves diferentes**/
        document.getElementById("clave2").style.border = "3px solid #cb1a1a";
        document.getElementById("clave").style.border = "3px solid #cb1a1a";
    }


    /* Comprobar Edad */

    var anio = document.getElementById("nac").value.split("-");
    var hoy = new Date();
    var anioA = hoy.getFullYear()

    if(anioA - anio[0] >= 13){
        /*mayor o igual a 13 anios */
        document.getElementById("nac").style.border = "3px solid #003f68";
        campos.edad_suf = true;
    }else{
        /*menor a 13 anios*/
        document.getElementById("nac").style.border = "3px solid #cb1a1a";
    }


    /* Comprobar Gmail */

    var correo_val = document.getElementById("mail").value.split("@");

    if(correo_val[1] == "gmail.com"){
        document.getElementById("mail").style.border = "3px solid #003f68";
        campos.correo = true;
    }else{
        document.getElementById("mail").style.border = "3px solid #cb1a1a";
    }


    /* --Submit con javascript-- */

    if(campos.usuario == true && campos.correo == true &&campos.contra == true && campos.contra2 == true && campos.edad_suf == true){
        document.getElementById("msg-correct").style.display = 'block';
        document.getElementById("msg-error").style.display = 'none';
        setTimeout(function() { document.formulario_regis.submit(); }, 1500);

    }else{
        document.getElementById("msg-error").style.display = 'block';
        document.getElementById("msg-correct").style.display = 'none';
    }
}

/* -- Recuperacion de Cuenta -- */

function generar_codigo(){
    document.getElementById("contenedor-recup-cuenta").style.display = "none";
    document.getElementById("contenedor-gen-codigo").style.display = "flex";

    setTimeout(function() { document.form_envio_correo_recup.submit(); }, 1000);
}

/* -- Verificacion del Codigo -- */

function verificar_codigo(){
    if(document.getElementById("codigo").value == document.getElementById("codigo-mail").value){
        document.getElementById("codigo-correcto").style.display = 'block';
        document.getElementById("codigo-erroneo").style.display = 'none';
        
        setTimeout(function() { document.verificacion_codigo.submit(); }, 1000);
    }else{
        document.getElementById("codigo-erroneo").style.display = 'block';
        document.getElementById("codigo-correcto").style.display = 'none';
    }
}