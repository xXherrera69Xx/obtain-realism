<?php
    header("Location: feed-principal.php");
?>