-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-08-2022 a las 02:53:14
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `memingos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'eso brad'),
(2, ':v'),
(3, 'meme'),
(4, 'jijijija'),
(5, 'clash royale'),
(6, 'perro'),
(7, '._.xd'),
(8, 'monzonpro'),
(9, 'cerebron'),
(10, 'momos monzon'),
(11, 'que pro'),
(12, 'elpepe'),
(13, 'hola'),
(14, 'd'),
(15, 'troll'),
(16, 'xd'),
(17, 'furros'),
(18, 'playa'),
(19, 'mar del plata'),
(20, 'mar'),
(21, 'agua'),
(22, 'arena'),
(23, 'personas'),
(24, 'baños'),
(25, 'sol'),
(26, 'edificios'),
(27, 'ciudad');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `censura_comentarios`
--

CREATE TABLE `censura_comentarios` (
  `id` int(1) NOT NULL,
  `estadoCensuraComentarios` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `censura_comentarios`
--

INSERT INTO `censura_comentarios` (`id`, `estadoCensuraComentarios`) VALUES
(1, 'on'),
(2, 'off');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `censura_memes`
--

CREATE TABLE `censura_memes` (
  `id` int(1) NOT NULL,
  `estadoCensuraMeme` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `censura_memes`
--

INSERT INTO `censura_memes` (`id`, `estadoCensuraMeme`) VALUES
(1, 'on'),
(2, 'off');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(100) NOT NULL,
  `usuario_id` int(100) NOT NULL,
  `publicacion_id` int(100) NOT NULL,
  `fechaComentario` date NOT NULL,
  `contenidoComentario` varchar(2200) NOT NULL,
  `tieneRespuesta` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id`, `usuario_id`, `publicacion_id`, `fechaComentario`, `contenidoComentario`, `tieneRespuesta`) VALUES
(15, 1, 4, '2022-07-03', 'Hooooooooooooooooolaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'NO'),
(16, 1, 4, '2022-07-03', 'Jajjajajajajjjajaja', 'NO'),
(17, 1, 4, '2022-07-03', 'Que buen momo', 'NO'),
(18, 3, 6, '2022-07-03', 'Hola', 'NO'),
(19, 3, 5, '2022-07-03', 'zzz', 'SI'),
(20, 1, 5, '2022-07-10', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero impedit explicabo veritatis neque optio quae iure ut dolor nihil, similique cumque ipsam praesentium consequuntur tenetur quidem sit beatae rerum nisi!                     Unde dolores sapiente odit quibusdam vitae incidunt inventore animi autem ab quae laudantium culpa aspernatur quasi eum eaque natus est ullam sequi saepe voluptas vero illum, provident quidem ratione! Voluptatem!                     Asperiores dicta eveniet voluptate ipsum aspernatur quas, illum magni, incidunt iure cupiditate doloribus ducimus accusamus ratione architecto consequatur recusandae suscipit nemo reprehenderit ab molestiae laborum accusantium impedit veritatis? Laudantium, sequi!                     Distinctio, inventore. Molestiae nemo illo animi placeat consequuntur odio voluptates amet neque. Ut quo quaerat aliquid voluptate facilis praesentium repellat, error cum, necessitatibus aliquam minima officiis similique optio repellendus deserunt.', 'SI'),
(21, 2, 5, '2022-07-10', 'Hola', 'SI'),
(22, 2, 7, '2022-07-10', 'que pro', 'SI'),
(28, 7, 7, '2022-07-14', 'asd', 'NO'),
(29, 3, 7, '2022-07-15', 'matias', 'NO'),
(30, 2, 9, '2022-07-17', 'Prueba comentario', 'NO'),
(31, 1, 5, '2022-07-18', 'sdfsdfsd', 'NO'),
(32, 2, 13, '2022-08-07', 'Sos un imbecil', 'SI'),
(33, 1, 13, '2022-08-07', 'xd', 'NO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios_likes`
--

CREATE TABLE `comentarios_likes` (
  `id` int(100) NOT NULL,
  `usuario_id` int(100) NOT NULL,
  `comentarios_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comentarios_likes`
--

INSERT INTO `comentarios_likes` (`id`, `usuario_id`, `comentarios_id`) VALUES
(23, 7, 28),
(24, 1, 20),
(27, 1, 31),
(28, 1, 18),
(42, 1, 15),
(43, 1, 16),
(44, 1, 17);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contenido_notificaciones`
--

CREATE TABLE `contenido_notificaciones` (
  `id` int(1) NOT NULL,
  `tipoContenido` enum('Alguien le ha dado like a tu publicacion','Alguien le ha dado like a tu comentario','En unas cuantas horas se reiniciara la tabla de clasificación') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `contenido_notificaciones`
--

INSERT INTO `contenido_notificaciones` (`id`, `tipoContenido`) VALUES
(1, 'Alguien le ha dado like a tu publicacion'),
(2, 'Alguien le ha dado like a tu comentario'),
(3, 'En unas cuantas horas se reiniciara la tabla de clasificación');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `generos`
--

CREATE TABLE `generos` (
  `id` int(1) NOT NULL,
  `nombreGeneros` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `generos`
--

INSERT INTO `generos` (`id`, `nombreGeneros`) VALUES
(1, 'Hombre'),
(2, 'Mujer'),
(3, 'Personalizado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `idioma`
--

CREATE TABLE `idioma` (
  `id` int(1) NOT NULL,
  `nombreIdioma` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `idioma`
--

INSERT INTO `idioma` (`id`, `nombreIdioma`) VALUES
(1, 'spanish'),
(2, 'english');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id_N` int(100) NOT NULL,
  `contenidoNotificacion_id` varchar(100) DEFAULT NULL,
  `usuario_id` int(100) NOT NULL,
  `comentarios_likes_id` int(100) DEFAULT NULL,
  `publicaciones_likes_id` int(100) DEFAULT NULL,
  `fechaNotificacion` datetime NOT NULL,
  `destinatario` int(100) DEFAULT NULL,
  `respuestasComentarios_id` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id_N`, `contenidoNotificacion_id`, `usuario_id`, `comentarios_likes_id`, `publicaciones_likes_id`, `fechaNotificacion`, `destinatario`, `respuestasComentarios_id`) VALUES
(49, 'Alguien le dio like a tu publicacion', 7, NULL, 7, '2022-07-15 23:25:38', 3, NULL),
(52, 'Alguien le dio like a tu publicacion', 3, NULL, 7, '2022-07-15 23:35:33', 3, NULL),
(53, 'Alguien le dio like a tu publicacion', 1, NULL, 7, '2022-07-16 14:28:46', 3, NULL),
(54, 'Alguien le dio like a tu publicacion', 1, NULL, 4, '2022-07-16 14:30:06', 2, NULL),
(60, 'Alguien le dio like a tu publicacion', 1, NULL, 5, '2022-07-18 14:46:38', 2, NULL),
(68, 'Alguien le dio like a tu comentario', 1, 18, NULL, '2022-07-19 20:49:32', 3, NULL),
(83, 'Alguien le dio like a tu comentario', 1, 16, NULL, '2022-07-19 21:15:40', 1, NULL),
(84, 'Alguien le dio like a tu comentario', 1, 17, NULL, '2022-07-19 21:15:41', 1, NULL),
(139, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-07-31 14:43:13', 2, 22),
(140, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-07-31 14:44:16', 2, 22),
(149, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-07 21:01:28', 3, 29),
(150, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-07 21:02:08', 7, 33),
(151, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 03:37:39', 7, 28),
(152, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 03:53:20', 7, 22),
(153, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 03:54:14', 7, 22),
(154, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 03:56:42', 7, 22),
(155, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 03:57:07', 7, 32),
(156, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 03:57:58', 7, 36),
(157, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 05:21:22', 7, 34),
(158, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 05:53:22', 7, 29),
(159, 'Alguien respondio tu comentario', 7, NULL, NULL, '2022-08-08 05:54:01', 2, 22),
(166, 'Alguien le dio like a tu comentario', 7, 7, NULL, '2022-08-09 06:41:14', 7, NULL),
(172, 'Alguien le dio like a tu comentario', 7, 33, NULL, '2022-08-09 07:16:00', 7, NULL),
(174, 'Alguien le dio like a tu comentario', 7, 29, NULL, '2022-08-09 07:17:43', 3, NULL),
(176, 'Alguien le dio like a tu comentario', 7, 8, NULL, '2022-08-09 07:19:27', 7, NULL),
(178, 'Alguien le dio like a tu comentario', 7, 16, NULL, '2022-08-09 07:22:25', 7, NULL),
(181, 'Alguien le dio like a tu comentario', 7, 28, NULL, '2022-08-09 07:24:32', 7, NULL),
(184, 'Alguien le dio like a tu comentario', 7, 5, NULL, '2022-08-09 07:30:46', 2, NULL),
(189, 'Alguien respondio tu comentario', 1, NULL, NULL, '2022-08-09 21:51:30', 2, 32);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preferencias`
--

CREATE TABLE `preferencias` (
  `id` int(100) NOT NULL,
  `idioma_id` int(1) NOT NULL,
  `tema_id` int(1) NOT NULL,
  `censuraComentarios_id` int(1) NOT NULL,
  `censuraMemes_id` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `preferencias`
--

INSERT INTO `preferencias` (`id`, `idioma_id`, `tema_id`, `censuraComentarios_id`, `censuraMemes_id`) VALUES
(1, 1, 1, 1, 1),
(2, 1, 1, 1, 2),
(3, 1, 1, 2, 1),
(4, 1, 1, 2, 2),
(5, 1, 2, 1, 1),
(6, 1, 2, 1, 2),
(7, 1, 2, 2, 1),
(8, 1, 2, 2, 2),
(9, 2, 1, 1, 1),
(10, 2, 1, 1, 2),
(11, 2, 1, 2, 1),
(12, 2, 1, 2, 2),
(13, 2, 2, 1, 1),
(14, 2, 2, 1, 2),
(15, 2, 2, 2, 1),
(16, 2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `privilegios`
--

CREATE TABLE `privilegios` (
  `id` int(100) NOT NULL,
  `nombrePrivilegio` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `privilegios`
--

INSERT INTO `privilegios` (`id`, `nombrePrivilegio`) VALUES
(1, 'admintrador'),
(2, 'moderador'),
(3, 'usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones`
--

CREATE TABLE `publicaciones` (
  `id` int(100) NOT NULL,
  `rutaImagen` varchar(250) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `fechaPublicacion` date NOT NULL,
  `censura` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `publicaciones`
--

INSERT INTO `publicaciones` (`id`, `rutaImagen`, `usuario_id`, `fechaPublicacion`, `censura`) VALUES
(1, 'users/1/publicaciones/nvakhf87eoa.jpg', 1, '2022-06-26', 'off'),
(2, 'users/1/publicaciones/hjhlIHI87.jpg', 1, '2022-06-26', 'off'),
(3, 'users/1/publicaciones/yyh7b8.jpeg', 1, '2022-06-26', 'off'),
(4, 'users/2/publicaciones/2adf2fa6.jpeg', 2, '2022-06-26', 'off'),
(5, 'users/2/publicaciones/20220623_170841.jpg', 2, '2022-07-03', 'off'),
(6, 'users/3/publicaciones/fhhf.jpg', 3, '2022-07-03', 'off'),
(7, 'users/3/publicaciones/quepro.jpg', 3, '2022-07-03', 'off'),
(8, 'users/7/publicaciones/logoMemingos.png', 7, '2022-07-15', 'off'),
(9, 'users/7/publicaciones/logoEmpresa.png', 7, '2022-07-15', 'off'),
(10, 'users/7/publicaciones/BotonDeIniciar.png', 7, '2022-07-15', 'off'),
(11, 'users/1/publicaciones/publicacion-n4.gif', 1, '2022-07-21', 'off'),
(12, 'users/2/publicaciones/publicacion-n3.png', 2, '2022-07-23', 'off'),
(13, 'users/2/publicaciones/publicacion-n4.jpg', 2, '2022-07-23', 'off'),
(14, 'users/2/publicaciones/publicacion-n5.jpg', 2, '2022-07-23', 'off'),
(15, 'users/1/publicaciones/publicacion-n5.jpeg', 1, '2022-08-09', 'on');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones_categorias`
--

CREATE TABLE `publicaciones_categorias` (
  `id` int(100) NOT NULL,
  `publicaciones_id` int(100) NOT NULL,
  `categorias_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `publicaciones_categorias`
--

INSERT INTO `publicaciones_categorias` (`id`, `publicaciones_id`, `categorias_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 3),
(4, 3, 4),
(5, 3, 5),
(6, 4, 6),
(7, 4, 7),
(8, 5, 8),
(9, 5, 9),
(10, 6, 10),
(11, 7, 11),
(12, 8, 12),
(13, 9, 13),
(14, 10, 14),
(15, 11, 15),
(16, 11, 16),
(17, 12, 17),
(18, 12, 16),
(19, 13, 6),
(20, 13, 3),
(21, 13, 16),
(22, 14, 18),
(23, 14, 19),
(24, 14, 20),
(25, 14, 21),
(26, 14, 22),
(27, 14, 23),
(28, 14, 24),
(29, 14, 25),
(30, 14, 26),
(31, 14, 27),
(32, 15, 16);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones_likes`
--

CREATE TABLE `publicaciones_likes` (
  `id` int(100) NOT NULL,
  `usuario_id` int(100) NOT NULL,
  `publicacion_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `publicaciones_likes`
--

INSERT INTO `publicaciones_likes` (`id`, `usuario_id`, `publicacion_id`) VALUES
(37, 7, 7),
(38, 7, 10),
(39, 7, 9),
(40, 3, 7),
(41, 1, 7),
(42, 1, 4),
(46, 1, 1),
(47, 1, 5),
(48, 1, 3),
(51, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas_comentarios`
--

CREATE TABLE `respuestas_comentarios` (
  `id` int(100) NOT NULL,
  `usuario_id` int(100) NOT NULL,
  `comentario_id` int(100) NOT NULL,
  `publicacion_id` int(100) NOT NULL,
  `contenido` varchar(2200) NOT NULL,
  `fechaRespuesta` date NOT NULL,
  `destinatario` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `respuestas_comentarios`
--

INSERT INTO `respuestas_comentarios` (`id`, `usuario_id`, `comentario_id`, `publicacion_id`, `contenido`, `fechaRespuesta`, `destinatario`) VALUES
(1, 2, 20, 5, 'aksdjfhaksdhflaksjdafd', '2022-07-10', NULL),
(2, 1, 20, 5, 'zzzzzzzzzzz', '2022-07-10', NULL),
(3, 2, 21, 5, 'monzon zzz', '2022-07-10', NULL),
(4, 2, 19, 5, 'ust zzz', '2022-07-10', NULL),
(5, 2, 22, 7, 'xd', '2022-07-10', NULL),
(6, 1, 19, 5, 'jijijija', '2022-07-11', NULL),
(7, 7, 22, 7, 'feo', '2022-07-31', NULL),
(8, 7, 22, 7, 'muy feo', '2022-07-31', NULL),
(9, 7, 28, 7, 'hola', '2022-07-31', NULL),
(10, 7, 28, 7, 'p', '2022-07-31', NULL),
(11, 7, 28, 7, 'asfafs', '2022-07-31', NULL),
(12, 7, 29, 7, 's', '2022-08-07', NULL),
(13, 7, 33, 7, 'hola', '2022-08-07', NULL),
(14, 7, 28, 7, 'adios', '2022-08-08', NULL),
(15, 7, 22, 7, 'asd', '2022-08-08', 7),
(16, 7, 22, 7, 'ssss', '2022-08-08', 7),
(17, 7, 34, 14, 'verdad', '2022-08-08', 7),
(18, 7, 29, 7, 'jaja', '2022-08-08', 7),
(19, 7, 22, 7, 'aeaes', '2022-08-08', 2),
(20, 1, 32, 13, '??', '2022-08-09', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas_comentarios_likes`
--

CREATE TABLE `respuestas_comentarios_likes` (
  `id` int(100) NOT NULL,
  `usuario_id` int(100) NOT NULL,
  `respuestasComentarios_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `respuestas_comentarios_likes`
--

INSERT INTO `respuestas_comentarios_likes` (`id`, `usuario_id`, `respuestasComentarios_id`) VALUES
(6, 7, 7),
(13, 7, 33),
(15, 7, 29),
(16, 7, 8),
(19, 7, 16),
(25, 7, 5),
(28, 7, 22),
(29, 7, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tema`
--

CREATE TABLE `tema` (
  `id` int(1) NOT NULL,
  `nombreTema` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tema`
--

INSERT INTO `tema` (`id`, `nombreTema`) VALUES
(1, 'off'),
(2, 'on');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(100) NOT NULL,
  `nombreUsuario` varchar(18) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `generos_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `fotoPerfil` varchar(200) DEFAULT NULL,
  `preferencias_id` int(11) DEFAULT NULL,
  `privilegios_id` int(11) DEFAULT NULL,
  `fechaCreacion` date NOT NULL,
  `fechaEliminacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombreUsuario`, `fechaNacimiento`, `generos_id`, `email`, `clave`, `descripcion`, `fotoPerfil`, `preferencias_id`, `privilegios_id`, `fechaCreacion`, `fechaEliminacion`) VALUES
(1, 'Paul Diego', '2006-02-11', 1, 'diego.paul.et.n26@gmail.com', '12345678910', NULL, 'img/foto-perfil-default.jpg', 1, 1, '2022-06-14', NULL),
(2, 'Augusto Torres', '2006-08-17', 2, 'agustoplasencia2006@gmail.com', '12345678', '', 'img/foto-perfil-default.jpg', 1, 3, '2022-06-14', NULL),
(3, 'Matias Monzon', '2006-10-18', 1, 'matiasmonzonetn26@gmail.com', '12345678', 'Bv', 'img/foto-perfil-default.jpg', 1, 3, '2022-06-14', NULL),
(5, 'Francisco Mamani', '2006-08-28', 1, 'mamani@gmail.com', '12345678', NULL, 'img/foto-perfil-default.jpg', 1, 3, '2022-06-17', NULL),
(6, 'Perro Tronco', '2005-04-20', 3, 'perrotronco@gmail.com', '12345678', NULL, 'img/foto-perfil-default.jpg', 1, 3, '2022-06-17', NULL),
(7, 'Rodrigo Acosta', '2004-06-11', 1, 'rodrigo_acosta@gmail.com', '12345678', NULL, 'img/foto-perfil-default.jpg', 1, 3, '2022-06-19', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `censura_comentarios`
--
ALTER TABLE `censura_comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `censura_memes`
--
ALTER TABLE `censura_memes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comentarios_likes`
--
ALTER TABLE `comentarios_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `contenido_notificaciones`
--
ALTER TABLE `contenido_notificaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `generos`
--
ALTER TABLE `generos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `idioma`
--
ALTER TABLE `idioma`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id_N`);

--
-- Indices de la tabla `preferencias`
--
ALTER TABLE `preferencias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `privilegios`
--
ALTER TABLE `privilegios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publicaciones_categorias`
--
ALTER TABLE `publicaciones_categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publicaciones_likes`
--
ALTER TABLE `publicaciones_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `respuestas_comentarios`
--
ALTER TABLE `respuestas_comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `respuestas_comentarios_likes`
--
ALTER TABLE `respuestas_comentarios_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tema`
--
ALTER TABLE `tema`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `comentarios_likes`
--
ALTER TABLE `comentarios_likes`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id_N` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT de la tabla `preferencias`
--
ALTER TABLE `preferencias`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `privilegios`
--
ALTER TABLE `privilegios`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `publicaciones_categorias`
--
ALTER TABLE `publicaciones_categorias`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `publicaciones_likes`
--
ALTER TABLE `publicaciones_likes`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `respuestas_comentarios`
--
ALTER TABLE `respuestas_comentarios`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `respuestas_comentarios_likes`
--
ALTER TABLE `respuestas_comentarios_likes`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;