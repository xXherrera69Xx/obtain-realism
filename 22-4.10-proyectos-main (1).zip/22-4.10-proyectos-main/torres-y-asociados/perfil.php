<?php
    require_once "includes/config.php";

    require_once "modelos/usuario-actual.php";

    $section = "perfil";
    
    require_once "modelos/perfil-likes.php";

    require_once "modelos/perfil-publicaciones.php";

    require_once "views/layout.php";
    
?>