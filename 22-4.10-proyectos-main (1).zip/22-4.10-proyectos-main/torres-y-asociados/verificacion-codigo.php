<?php
    /* -- Verificacion realizada con javascript -- */

    header("Location: cambiar-password-recup.php")
?>