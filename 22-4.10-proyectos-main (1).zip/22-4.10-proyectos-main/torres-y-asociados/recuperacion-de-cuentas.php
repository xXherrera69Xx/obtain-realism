<?php
    require_once "includes/config.php";

    $section_login = "recuperacion-de-cuentas";

    require_once "views/layout-login.php";
?>