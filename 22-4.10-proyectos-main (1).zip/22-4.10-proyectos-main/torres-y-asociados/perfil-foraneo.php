<?php
    require_once "includes/config.php";

    require_once "modelos/usuario-actual.php";

    require_once "modelos/perfil-foraneo.php";

    $section = "perfil-foraneo";
    
    require_once "views/layout.php";
?>