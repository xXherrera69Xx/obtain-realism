<?php
    require_once "includes/config.php";

    $section_login = "cambiar-password-recup";

    require_once "views/layout-login.php";
?>