
<?php   

    require("../includes/publication_home" . ".php");

/* Hay que hacer que cargue x publicaciones y luego que cargue mas a medida que se scrolea */
