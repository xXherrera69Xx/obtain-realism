<html>
<head>
<link rel="stylesheet" href="22-4.10-proyectos/viex/css/bootstrap.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>
<body>
<div class="container-v5 d-grid grid-template-rows">
    <h4 class="mb-5 mt-4 ms-5">Ajustes de usuario</h4>
    <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-around">
        <a href="../controllers/edit_profile.php" aria-selected="true">Editar perfil</a>
        <a href="../controllers/change_password.php" aria-selected="false">Cambiar contraseña</a>
    </div>
</div>
<br>
<div class="container-v3">
    <?php if ($errormessage != "") { ?>
        <div class="alert alert-danger text-center">
            <?php echo $errormessage; ?>
        </div>
    <?php } ?>


    <form method="POST" action="../controllers/users/upload_photo.php" enctype="multipart/form-data">
        <div class="form__container">
            <button class="btn p-0 form__container--img" onclick=" document.getElementById('form__container--file').click()"><img class="form__container--img" src="../<?php echo $user['avatar']; ?>" alt="foto de perfil"></button>
            <div class="form__container--content">
			
                <label class=""><?php echo $user['username']; ?></label>
                <input id="form__container--file" type="file" accept="image/jpeg,image/png,image/gif,image/webp" name="avatar" onchange="this.form.submit()">
				<button type="button" class="form__container--button btn btn-warning" data-bs-toggle="modal" data-bs-target="#Cambiarfoto">Cambiar foto de perfil</button>
            </div>
        </div>
    </form>
	<!--Modal-->
	<div class="modal fade" id="Cambiarfoto">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="cambiarfoto">Cambiar foto de perfil</h5>
			 <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
		  </div>
		  <div class="modal-body">
			<button type="button" class="form__container--button btn btn-warning" onclick="document.getElementById('form__container--file').click()">Cambiar foto</button>
			<br> <br>
			<button type="button" class="form__container--button btn btn-warning">Eliminar foto</button>
			<br> <br>
			<button type="button" class="form__container--button btn btn-warning" data-bs-dismiss="modal">Cancelar</button>
		  </div>
		  <div class="modal-footer">
		  </div>
		</div>
	  </div>
	</div>

    <form method="POST" action="../controllers/edit_profile.php" class="form">
        <div class="form__container">
            <div class="form__container--content ">
                <label class="form__container--text">Nombre</label>
                <input class="form-control form__container--input" type="text" maxlength="60" name="name" value="<?php echo $user['name']; ?>" required>
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <label class="form__container--text">Nombre de usuario</label>
                <input class="form-control form__container--input" type="text" maxlength="30" name="username" value="<?php echo $user['username']; ?>" required>
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <label class="form__container--text">Biografía</label>
                <textarea class="form__container--textarea-biografy form-control" maxlength="300" name="biography"><?php echo $user['biography']; ?></textarea>
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <label class="form__container--text">Correo electronico</label>
                <input class="form-control form__container--input" type="email" maxlength="50" name="email" value="<?php echo $user['email']; ?>">
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <label class="form__container--text">Genero</label>
                <select name="gender" id="gender" class="form-control form__container--input" required>
                    <!--<option value="null" selected disabled hidden>Seleccione su genero</option>-->
                    <option value="male" <?php if ($user['gender'] == "male") {
                                                echo "selected";
                                            } ?>>Masculino</option>
                    <option value="female" <?php if ($user['gender'] == "female") {
                                                echo "selected";
                                            } ?>>Femenino</option>
                    <option value="other" <?php if ($user['gender'] == "other") {
                                                echo "selected";
                                            } ?>>Otro</option>
                    <option value="no" <?php if ($user['gender'] == "no") {
                                            echo "selected";
                                        } ?>>Prefiero no contestar</option>
                </select>
            </div>
        </div>

        <div class="form__container">
            <button class="form__container--button btn btn-warning " type="submit" name="confirm">Confirmar</button>
            <!-- Boton para desactivar cuenta  -->
            <a class="form__container--a  ms-6" href="../controllers/users/disable.php" disabled>Desactivar mi cuenta</a>
        </div>


    </form>
</div>
<script src="../js/main.js"></script>
</body>
</html>