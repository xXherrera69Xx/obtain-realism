<div class="container-v3 ">
    <form method="post" action="../controllers/post_recipe.php" class="form" enctype="multipart/form-data">
        <div class="form__container--content">
            <h4 class="mb-5 mt-4">Publicar receta</h4>
        </div>

        <div class="form__container--content">
            <h5 class="mb-2">Titulo</h5>
            <textarea class="form__container--textarea-tittle form-control" name="title" maxlength="75" required></textarea>
        </div>

        <div class="form__container--content">
            <h5 class="mb-2">Descripción</h5>
            <textarea class="form__container--textarea-description form-control" name="content" maxlength="2500" required></textarea>
            <!--<div id="texto" class="form-control mb-5" contenteditable="true" aria-required="true"></div>-->
        </div>

        <div id="form__container">
            <h5 class="me-2">Agregar imagenes o un video</h5>
            <button type="button" id="selectfile" class="btn btn-warning form__container--file first">Seleccionar archivo</button>
            <input type="file" id="form__container--file" placeholder="Seleccionar archivo" name="multimedia[]" hidden multiple>
        </div>

        <div class="text-end">
            <button class="btn btn-light mb-3 mt-3-5 me-2 px-3" type="reset">Descartar</button>
            <button class="btn btn-warning  mb-3 mt-3-5 px-3" type="submit">Publicar</button>
        </div>
    </form>
</div>


<script src="https://code.jquery.com/jquery-3.4.0.min.js" integrity="sha256-BJeo0qm959uMBGb65z40ejJYGSgR7REI4+CW1fNKwOg=" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

<script src="../js/post_recipe.js" type="text/javascript"></script>