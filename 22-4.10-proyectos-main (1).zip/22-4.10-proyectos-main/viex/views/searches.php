<?php if($option == 1) { ?>
<div class="container-v5">
        <div class="container__submenu">
            <div class="container__submenu--recipes">
                <a href="../controllers/searches.php?search=<?php echo $search; ?>" aria-selected="true">Recetas</a>
            </div>
            <div class="container__submenu-accounts">
                <a href="../controllers/searches.php?search=<?php echo $search; ?>&for=user" aria-selected="false">Cuentas</a>
            </div>
        </div>
    </div>
<?php
    require("../includes/publication_home" . ".php"); // Hay que hacer que cargue x publicaciones y luego que cargue mas a medida que se scrolea 
    
} else {
?>
    <div class="container-v5">
        <div class="container__submenu">
            <div class="container__submenu--recipes">
                <a href="../controllers/searches.php?search=<?php echo $search; ?>" aria-selected="false">Recetas</a>
            </div>
            <div class="container__submenu-accounts">
                <a href="../controllers/searches.php?search=<?php echo $search; ?>&for=user" aria-selected="true">Cuentas</a>
            </div>
        </div>
    </div>
<?php
    require("../includes/miniprofile" . ".php"); // Hay que hacer que cargue x publicaciones y luego que cargue mas a medida que se scrolea 
}
?>