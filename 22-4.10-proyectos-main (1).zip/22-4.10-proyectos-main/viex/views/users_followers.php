<div class="container-v5 d-grid grid-template-rows">
    <div class="mb-5 mt-4 ms-5 d-flex align-items-center">
        <a href="../controllers/profile.php?id=<?php echo $_GET['id'] ?>"><i class="bi bi-arrow-left-short me-3"></i></a>
        <h4 class="mb-1"><?php echo $rowUsername['username']; ?></h4>
    </div>
    <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-around">
        <a href="../controllers/users_followers.php?id=<?php echo $_GET['id'] ?>" aria-selected="true">Seguidores</a>
        <a href="../controllers/users_followeds.php?id=<?php echo $_GET['id'] ?>" aria-selected="false">Seguidos</a>
    </div>
</div>

<?php
require("../includes/miniprofile.php");

?>