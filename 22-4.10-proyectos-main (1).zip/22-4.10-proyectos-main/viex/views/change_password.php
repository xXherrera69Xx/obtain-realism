<div class="container-v5 d-grid grid-template-rows">
    <h4 class="mb-5 mt-4 ms-5">Ajustes de usuario</h4>
    <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-around">
        <a href="../controllers/edit_profile.php" aria-selected="false">Editar perfil</a>
        <a href="../controllers/change_password.php" aria-selected="true">Cambiar contraseña</a>
    </div>
</div>
<div class="container-v3">
    <?php if ($errormessage != "") { ?>
        <div class="alert alert-danger text-center">
            <?php echo $errormessage; ?>
        </div>
    <?php } ?>
    <form method="POST" action="../controllers/change_password.php" class="form">

        <div class="form__container">
            <div class="form__container--content">
                <label class="form__container--text" for="password">Contraseña anterior</label>
                <input type="password" class="form-control form__container--input" name="oldpass" required>
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <label class="form__container--text" for="password">Nueva contraseña</label>
                <input type="password" class="form-control form__container--input" name="newpass" required>
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <label class="form__container--text" for="password">Repetir nueva contraseña</label>
                <input type="password" class="form-control form__container--input" name="confirmnewpass" required>
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <button type="submit" class="form__container--button btn btn-warning">Cambiar contraseña</button>
            </div>
        </div>

        <div class="form__container">
            <div class="form__container--content">
                <a class="form__container--a" href="forgot_password.php">¿Olvidaste tu contraseña?</a>
            </div>
        </div>
    </form>
</div>