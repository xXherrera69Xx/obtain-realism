<div class="container-v4 sticky-top">
    <nav class="container__menu justify-content-lg-between">
        <a href="home.php" class="container__menu--logo">
            <img class="bi" src="../images/Logo Fooder icono.PNG" alt="Logo" width="50">
        </a>


        <form action="../controllers/searches.php" method="GET" class="container__menu--search col-8 col-sm-4">
            <input type="search" class="container__menu--text form-control" placeholder="Buscar" name="search">
        </form>


        <div class="">
            <ul class="container__menu--nav">
                <li><a href="../controllers/home.php" class="container__menu--nav-item"><i class="bi bi-house-door px-2"></i><br></a></li>
                <li><a href="../controllers/recipes_followed.php" class="container__menu--nav-item"><i class="bi bi-people px-2"></i><br></a></li>
                <?php if (!empty($user)) { ?>
                    <li><a href="../controllers/post_recipe.php" class="container__menu--nav-item"><i class="bi bi-plus-circle px-2"></i><br></a></li>
                    <li>
                        <div class="dropdown ps-2">
                            <img onclick="dropDownProfile()" class="container__menu--nav-profile dropbtn" src="../<?php echo $user['avatar'] ?>" alt="foto perfil">
                            <div id="myDropdown" class="dropdown-content">
                                <a class="dropdown-content__profile" href="../controllers/profile.php?id=<?php echo $user['id']; ?>"><img src="../images/icons/user.png" width="18px" class="me-2"> Perfil</a>
                                <a class="dropdown-content__setting" href="../controllers/edit_profile.php"><img src="../images/icons/settings.png" width="18px" class="me-2" alt=""> Configuracion</a>
                                <a class="dropdown-content__logout" href="../controllers/logout.php"><img src="../images/icons/log-out.png" width="18px" class=" me-2"> Salir</a>
                            </div>
                        </div>
                    </li>
                <?php } else { ?>
                    <li><a href="../controllers/login.php" class="container__menu--nav-item"><i class="bi bi-plus-circle px-2"></i><br></a></li>
                    <li><a href="../controllers/login.php"><button type="button" class="container__menu--nav-button">Iniciar sesión</button></a></li>
                <?php } ?>
            </ul>
        </div>
    </nav>
</div>
<script src="../js/main.js"></script>