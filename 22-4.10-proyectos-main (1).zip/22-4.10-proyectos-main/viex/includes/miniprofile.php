<?php
while ($rowFollowers = mysqli_fetch_assoc($resultFollowers)) {
?>

    <div class="container-v3">
        <div class="container-all">
            <div class="container__img">
                <a href="profile.php?id=<?php echo $rowFollowers['id']; ?>">
                    <img src="../<?php echo $rowFollowers['avatar'] ?>" alt="foto perfil">
                </a>
            </div>
            <div class="container__userdata">
                <div class="container__userdata--username">
                    <a href="profile.php?id=<?php echo $rowFollowers['id']; ?>"><?php echo $rowFollowers['username']; ?></a>
                </div>
                <div class="container__userdata--description">
                    <span><?php echo $rowFollowers['biography']; ?></span>
                </div>
            </div>
            <?php
            if (isset($user)) {
                $comprobarSeguir = "SELECT * FROM follows WHERE followed = '" . $rowFollowers['id'] . "' AND follower=" . $user['id'] . " ";
                $comprobarSeguirQuery = mysqli_query($conn, $comprobarSeguir);


                if ($user['id'] != $rowFollowers['id'] && mysqli_num_rows($comprobarSeguirQuery) == 0) { ?>
                    <div class="container__user--follow">
                        <button class="btn btn-dark" onclick="location.href='users/follow.php?id=<?php echo $rowFollowers['id']; ?>'">Seguir</button>
                    </div>
                <?php } else if ($user['id'] != $rowFollowers['id'] && mysqli_num_rows($comprobarSeguirQuery) == 1) { ?>
                    <div class="container__user--unfollow">
                        <button class="btn btn-dark" onclick="location.href='users/follow.php?id=<?php echo $rowFollowers['id']; ?>'">Dejar de Seguir</button>
                    </div>
                <?php       }
            } else { ?>
                <div class="container__user--follow">
                    <button class="btn btn-dark" onclick="location.href='login.php'">Seguir</button>
                </div>
            <?php   }?>
        </div>
    </div>
<?php  
    }
 ?>