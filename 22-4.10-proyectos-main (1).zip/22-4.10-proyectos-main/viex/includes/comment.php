<?php

while ($rowDataComment = mysqli_fetch_assoc($resultDataComment)) {
    // Para los datos del usuario creador del comentario
    $sqlCreatorCom = "SELECT * FROM users WHERE id = '" . $rowDataComment['user_id'] . "'";
    $resultCreatorCom = mysqli_query($conn, $sqlCreatorCom);
    $rowCreatorCom = mysqli_fetch_assoc($resultCreatorCom);

    //Para cant. los LIKES
    $sqlLikesCom = "SELECT COUNT(id) FROM likes_comments WHERE comment_id = '". $rowDataComment['id'] ."'";
    $resultLikesCom = mysqli_query($conn, $sqlLikesCom);
    $rowLikesCom = mysqli_fetch_assoc($resultLikesCom);
    

?>
    <div class="container-v3">
        <div class="container__user">
            <div class="container__user--profilepicture">
                <a href="profile.php?id=<?php echo $rowCreatorCom['id']; ?>">
                    <img src="../<?php echo $rowCreatorCom['avatar'] ?>" alt="foto perfil">
                </a>
            </div>
            <div class="container__user--name-date">
                <div class="container__user--username">
                    <a href="profile.php?id=<?php echo $rowCreatorCom['id']; ?>"><?php echo $rowCreatorCom['username']; ?></a>
                </div>
                <div class="container__user--separator">
                    <span>•</span>
                </div>
                <div class="container__user--date">
                    <span for="dateUp">
                        <?php
                        $fechaactual = strtotime(date('Y-m-d H:i:s'));
                        $creado = strtotime($rowDataComment['created_at']);

                        $segtranscurridos = $fechaactual - $creado;
                        if ($segtranscurridos > 60) {
                            $minstranscurridos = floor($segtranscurridos / 60);
                            if ($minstranscurridos > 60) {
                                $hstranscurridas = floor($minstranscurridos / 60);
                                if ($hstranscurridas > 24) {
                                    $diastranscurridos = floor($hstranscurridas / 24);
                                    echo "hace " . $diastranscurridos . "d";
                                } else {
                                    echo "hace " . $hstranscurridas . "h";
                                }
                            } else {
                                echo "hace " . $minstranscurridos . "m";
                            }
                        } else {
                            echo "hace " . $segtranscurridos . "s";
                        }
                        ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="container__comment">
            <span><?php echo $rowDataComment['comment']; ?></span>
        </div>

        <div class="container__feedback">
            <?php
            if (!isset($user)) { ?>
                <div class="container__feedback--likes">
                    <button class="btn" id="<?php echo $rowDataComment['id']; ?> " onclick="location.href='login.php'">
                        <img src="../images/icons/nolike.png" width="22px" alt="">
                        <span><?php echo $rowLikesCom['COUNT(id)']; ?></span>
                    </button>
                </div>
                <?php
            } else {
                $comprobarLike = "SELECT * FROM likes_comments WHERE comment_id = '" . $rowDataComment['id'] . "' AND user_id=" . $user['id'] . " ";
                $comprobaLikeQuery = mysqli_query($conn, $comprobarLike);
                if (mysqli_num_rows($comprobaLikeQuery) == 0) {
                ?>
                    <!--- No le dio like -->
                    <div class="container__feedback--likes">
                        <button class="btn" id="<?php echo $rowDataComment['id']; ?> " onclick="location.href='comments/likes.php?id=<?php echo $rowDataComment['id']; ?>'">
                            <img src="../images/icons/nolike.png" width="22px" alt="">
                            <span><?php echo $rowLikesCom['COUNT(id)']; ?></span>
                        </button>
                    </div>
                <?php } else { ?>
                    <!--- Le dio like -->
                    <div class="container__feedback--likes">
                        <button class="btn" id="<?php echo $rowDataComment['id']; ?> " onclick="location.href='comments/likes.php?id=<?php echo $rowDataComment['id']; ?>'">
                            <img src="../images/icons/like.png" width="22px" alt="">
                            <span><?php echo $rowLikesCom['COUNT(id)']; ?></span>
                        </button>
                    </div>

            <?php  }
            } ?>

            <!--<div class="container__feedback--comments">
                <button class="btn"><span>Responder</span></button>
            </div>-->

            <?php
            if (isset($user)) {
                if ($user['id'] == $rowCreatorCom['id']) { ?>
                    <div class='container__feedback--delete'>
                        <a class='btn btn-danger p-1' href="comments/delete.php?id=<?php echo $rowDataComment['id'] . "&recipe_id=" . $_GET['id'];  ?>">Eliminar</a>
                    </div>
                <?php } else { ?>
                    <div class="container__feedback--report">
                        <button class="btn"><i class="bi bi-flag"></i></button>
                    </div>
            <?php
                }
            } ?>
        </div>

        <!--<div class="container__answers">
        <button class="btn">
            <span class="container__answers--text">Ver respuestas (25) <i class="bi bi-chevron-down" style="font-size: 13px;"></i></span>
        </button>
    </div>-->
    </div>
<?php } ?>