<?php
while ($rowRecipe = mysqli_fetch_assoc($resultRecipe)) {
    // Para los datos del usuario creador 
    $sqlCreator = "SELECT * FROM users WHERE id = '" . $rowRecipe['user_id'] . "'";
    $resultCreator = mysqli_query($conn, $sqlCreator);
    $rowCreator = mysqli_fetch_assoc($resultCreator);

    // Para cant. los LIKES
    $sqlLikes = "SELECT COUNT(like_id) FROM likes_recipes WHERE recipe_id = '" . $rowRecipe['id'] . "'";
    $resultLikes = mysqli_query($conn, $sqlLikes);
    $rowLikes = mysqli_fetch_assoc($resultLikes);


    // Para cant. de los COMENTARIOS 
    $sqlComments = "SELECT COUNT(id) FROM comments WHERE recipe_id = '" . $rowRecipe['id'] . "'";
    $resultComments = mysqli_query($conn, $sqlComments);
    $rowComments = mysqli_fetch_assoc($resultComments);


?>

    <div class="container-v3">
        <div class="container__user">
            <div>
                <a class="container__user--profilepicture" href="profile.php?id=<?php echo $rowCreator['id']; ?>">
                    <img src="../<?php echo $rowCreator['avatar'] ?>" alt="foto perfil">
                </a>
            </div>
            <div class="container__user--name-date">
                <div class="container__user--username">
                    <a href="profile.php?id=<?php echo $rowCreator['id']; ?>"><?php echo $rowCreator['username']; ?></a>
                </div>
                <div class="container__user--separator">
                    <span>•</span>
                </div>
                <div class="container__user--date">
                    <span for="dateUp">
                        <?php
                        $fechaactual = strtotime(date('Y-m-d H:i:s'));
                        $creado = strtotime($rowRecipe['created_at']);

                        $segtranscurridos = $fechaactual - $creado;
                        if ($segtranscurridos > 60) {
                            $minstranscurridos = floor($segtranscurridos / 60);
                            if ($minstranscurridos > 60) {
                                $hstranscurridas = floor($minstranscurridos / 60);
                                if ($hstranscurridas > 24) {
                                    $diastranscurridos = floor($hstranscurridas / 24);
                                    echo "hace " . $diastranscurridos . "d";
                                } else {
                                    echo "hace " . $hstranscurridas . "h";
                                }
                            } else {
                                echo "hace " . $minstranscurridos . "m";
                            }
                        } else {
                            echo "hace " . $segtranscurridos . "s";
                        }
                        ?>
                    </span>
                </div>

            </div>
            <?php
            if (isset($user)) {
                $comprobarSeguir = "SELECT * FROM follows WHERE followed = '" . $rowCreator['id'] . "' AND follower=" . $user['id'] . " ";
                $comprobarSeguirQuery = mysqli_query($conn, $comprobarSeguir);


                if ($user['id'] != $rowCreator['id'] && mysqli_num_rows($comprobarSeguirQuery)  == 0) { ?>
                    <div class="container__user--follow">
                        <button class="btn btn-dark" onclick="location.href='users/follow.php?id=<?php echo $rowCreator['id']; ?>'">Seguir</button>
                    </div>
                <?php } else if ($user['id'] != $rowCreator['id'] && mysqli_num_rows($comprobarSeguirQuery)  == 1) { ?>
                    <div class="container__user--unfollow">
                        <button class="btn btn-dark" onclick="location.href='users/follow.php?id=<?php echo $rowCreator['id']; ?>'">Dejar de Seguir</button>
                    </div>
                <?php       }
            } else { ?>
                <div class="container__user--follow">
                    <button class="btn btn-dark" onclick="location.href='login.php'">Seguir</button>
                </div>
            <?php } ?>
        </div>
        <div class="container__recipe">
            <div class="container__recipe--tittle">
                <span>
                    <h5><?php echo $rowRecipe['title']; ?></h5>
                </span>
            </div>
            <div class="container__recipe--content">
                <span>  <!--- Esto es la funcion ver mas -->
                        <?php $string = strip_tags($rowRecipe['content']);
                                if (strlen($string) > 1000):                                
                                    $stringCut = substr($string,0,1000);
                                    $endpoint = strrpos($stringCut,' ');
                                    $string = $endpoint?substr($stringCut,1,$endpoint):substr($stringCut,0);
                                endif;
                                echo $string;
                            ?><a href = "publication.php?id=<?php echo $rowRecipe['id']; ?>">Ver mas</a>
                                
                </span>
            </div>
        </div>

        <div class="container__feedback">

            <div class="container__likes-comments">


                <?php
                if (!isset($user)) { ?>
                    <div class="container__feedback--likes">
                        <button class="btn" id="<?php echo $rowRecipe['id']; ?> " onclick="location.href='login.php'">
                            <img src="../images/icons/nolike.png" width="22px" alt="">
                            <!---<i class="bi bi-heart"></i>-->
                            <span><?php echo $rowLikes['COUNT(like_id)']; ?></span>
                        </button>
                    </div>
                    <?php
                } else {
                    $comprobarLike = "SELECT * FROM likes_recipes WHERE recipe_id = '" . $rowRecipe['id'] . "' AND user_id=" . $user['id'] . " ";
                    $comprobaLikeQuery = mysqli_query($conn, $comprobarLike);
                    if (mysqli_num_rows($comprobaLikeQuery) == 0) {
                    ?>
                        <!--- No le dio like -->
                        <div class="container__feedback--likes">
                            <button class="btn" id="<?php echo $rowRecipe['id']; ?> " onclick="location.href='recipes/likes.php?id=<?php echo $rowRecipe['id']; ?>'">
                                <img src="../images/icons/nolike.png" width="22px" alt="">
                                <span><?php echo $rowLikes['COUNT(like_id)']; ?></span>
                            </button>
                        </div>
                    <?php } else { ?>
                        <!--- Le dio like -->
                        <div class="container__feedback--likes">
                            <button class="btn" id="<?php echo $rowRecipe['id']; ?> " onclick="location.href='recipes/likes.php?id=<?php echo $rowRecipe['id']; ?>'">
                                <img src="../images/icons/like.png" width="22px" alt="">
                                <span><?php echo $rowLikes['COUNT(like_id)']; ?></span>
                            </button>
                        </div>

                <?php  }
                } ?>


                <div class="container__feedback--comments">
                    <button class="btn" onclick="location.href='publication.php?id=<?php echo $rowRecipe['id']; ?>'">
                        <img src="../images/icons/comments.png" width="22px" alt="">
                        <span><?php echo $rowComments['COUNT(id)']; ?></span>
                    </button>
                </div>

            </div>

            <!--- Boton de eliminar -->

            <?php
            if (isset($user)) {
                if ($user['id'] == $rowCreator['id']) { ?>
                    <div class='container__feedback--delete'>
                        <button class='btn btn-danger' onclick="location.href='../controllers/recipes/delete.php?id=<?php echo $rowRecipe['id']; ?>'">Eliminar</button>
                    </div>
                <?php } else { ?>
                    <div class="container__feedback--report">
                        <button class="btn"><i class="bi bi-flag"></i></button>
                    </div>
            <?php
                }
            }
            ?>

        </div>
    </div>

<?php } ?>