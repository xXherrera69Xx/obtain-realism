<?php
date_default_timezone_set('America/Argentina/Buenos_Aires');

define('RUTA', '/22-4.10-proyectos/viex');
$conn = mysqli_connect('localhost', 'root', '', 'fooder');

if (!$conn) {
    die('Error de Conexión (' . mysqli_connect_errno() . ') '
        . mysqli_connect_error());
}

?>