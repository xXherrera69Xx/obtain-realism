<?php
function generarToken($length = 15)
		{
			return substr(str_shuffle(str_repeat($x = 'a78njiKD345aLñb', ceil($length / strlen($x)))), 1, $length);
		}

		$miToken = generarToken()
?>