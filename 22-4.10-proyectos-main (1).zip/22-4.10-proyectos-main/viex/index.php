<?php
    header('location: controllers/home.php'); 
?>