<?php

session_start();

require_once "../includes/config.php";

require_once "../includes/check_user_logged.php";

/* Para los datos del usuario */
$sqlCreator = "SELECT * FROM users WHERE id = '" . $_GET['id'] . "'";
$resultCreator = mysqli_query($conn, $sqlCreator);
$rowCreator = mysqli_fetch_assoc($resultCreator);

/* Para cantidad de recetas publicadas*/
$sqlPosts = "SELECT COUNT(id) FROM recipes WHERE user_id = '" . $_GET['id'] . "'";
$resultPosts = mysqli_query($conn, $sqlPosts);
$rowPosts = mysqli_fetch_assoc($resultPosts);

// Para cant. los SEGUIDORES
$sqlFollowed = "SELECT COUNT(followed) FROM follows WHERE followed = " . $rowCreator['id'] . "";
$resultFollowed = mysqli_query($conn, $sqlFollowed);
$rowFollowed = mysqli_fetch_assoc($resultFollowed);

// Para  cant. los SEGUIDOS
$sqlFollower = "SELECT COUNT(follower) FROM follows WHERE follower = " . $rowCreator['id'] . "";
$resultFollower = mysqli_query($conn, $sqlFollower);
$rowFollower = mysqli_fetch_assoc($resultFollower);

/* Para los datos de la receta del usuario*/
$sqlRecipe = "SELECT * FROM recipes WHERE user_id= '" . $_GET['id'] . "' ORDER BY id DESC";
$resultRecipe = mysqli_query($conn, $sqlRecipe);

$page = $rowCreator['username'];
$section = "profile";
require_once "../views/layout.php";
