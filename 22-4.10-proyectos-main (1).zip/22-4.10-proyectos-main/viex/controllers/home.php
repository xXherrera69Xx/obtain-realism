<?php

session_start();

require_once "../includes/config.php";


require_once "../includes/check_user_logged.php";

// Para home
    $sqlRecipe = "SELECT * FROM recipes ORDER BY id DESC";
    $resultRecipe = mysqli_query($conn, $sqlRecipe);
    echo mysqli_error($conn);

$page = "Inicio";
$section = "home";
require_once "../views/layout.php";


