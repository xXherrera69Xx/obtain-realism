<?php

session_start();


require_once "../includes/config.php";

require_once "../includes/check_user_logged.php";

if (!isset($user)) {
    header('location: login.php');
}

/* Cambios editar perfil */
$errormessage = "";
if (!empty($_POST)) {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $gender = $_POST['gender'];
    $biography = trim($_POST['biography']);

    /* Prox sprint, hacer las validaciones en javascript (estas de php son temporales) */
    $sqlCheck = "SELECT * FROM users WHERE username='$username' AND username != '". $user['username'] ."'";
    $resultCheck = mysqli_query($conn, $sqlCheck);
    $sqlCheck2 = "SELECT * FROM users WHERE email='$email' AND email != '" . $user['email'] . "'";
    $resultCheck2 = mysqli_query($conn, $sqlCheck2);

    if((!mysqli_num_rows($resultCheck) > 0) && (!mysqli_num_rows($resultCheck2) > 0)){
        $sqlEdit = "UPDATE users SET username = '$username', name = '$name', email = '$email', biography = '$biography', gender = '$gender' WHERE id= '" . $user['id'] . "'";
        $resultEdit = mysqli_query($conn, $sqlEdit);
        if ($resultEdit) {
            header("Location: edit_profile.php");
        } else {
            die('Error de consulta' . mysqli_error($conn));
        }
    } else if(mysqli_num_rows($resultCheck) > 0){
        /* Ya hay usuarios con ese username*/
        $errormessage = "El nombre de usuario ya esta en uso";
    } else if(mysqli_num_rows($resultCheck2) > 0) {
        /* Ya hay usuarios con ese mail*/
        $errormessage = "El correo electronico ya esta en uso";
    }
}   

$page = "Editar perfil";
$section = "edit_profile";
require_once "../views/layout.php";



