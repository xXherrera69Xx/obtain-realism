<?php

session_start();

require_once "../includes/config.php";

require_once "../includes/check_user_logged.php";


if(isset($user)){
        $sqlRecipe = "SELECT recipes.id, recipes.user_id, recipes.title, recipes.content, recipes.video, recipes.created_at FROM recipes INNER JOIN follows ON recipes.user_id = follows.followed WHERE follows.follower = '" . $user['id'] . "' ORDER BY recipes.id DESC ";
        $resultRecipe = mysqli_query($conn, $sqlRecipe);
        echo mysqli_error($conn);
    } else {
        echo '<div class="container d-flex justify-content-center mt-3"><span class="alert alert-danger">Debes <a class="login-for-view" href="login.php">iniciar sesión</a> en Fooder, para poder ver las recetas de las personas a las que sigues</span></div>';
        die;
    }

$page = "Recetas seguidas";
$section = "recipes_followed";
require_once "../views/layout.php";