<?php



require_once('../includes/config.php');

/*if (isset($user)) {
    header('location: home.php');
}*/

$errormessage = "";

if (!empty($_POST)) {
    $email = trim($_POST['email']);
    $password = sha1($_POST['password']);

    $sqlLogin = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $resultLogin = mysqli_query($conn, $sqlLogin);
    if (mysqli_num_rows($resultLogin) > 0) {
        $rowLogin = mysqli_fetch_assoc($resultLogin);
        session_start();
        $_SESSION['user_id'] = $rowLogin['id'];
        header("Location: home.php");
    } else {
        /* Error en la autentificacion */
        /*echo "<script>alert('El email y/o la contraseña son incorrectos')</script>";*/
        $errormessage = "El email y/o la contraseña no son correctos";
    }
}

$page = "Inicia sesión";
$section = "login";
require_once('../views/layout2.php');
