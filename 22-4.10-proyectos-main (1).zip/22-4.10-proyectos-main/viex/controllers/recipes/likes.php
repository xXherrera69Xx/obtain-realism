<?php
session_start();

require_once "../../includes/config.php";
require_once "../../includes/check_user_logged.php";

$recipe_id = $_GET['id'];


$comprobacion = "SELECT * FROM likes_recipes WHERE recipe_id= '".$recipe_id."' AND user_id = ". $user['id']." ";
$queryComprobacion = mysqli_query($conn, $comprobacion);

$cantidad = mysqli_num_rows($queryComprobacion);

if($cantidad == 0){
   // Agrego el like a la base de datos
   $darLike2 = "INSERT INTO likes_recipes (user_id, recipe_id) VALUES ('" .$user['id']. "' , '" .$recipe_id. "')";
   $darLikeQuery2 = mysqli_query($conn, $darLike2);
} else {
   // Saco el like a la base de datos
   $quitarLike1 = "DELETE FROM likes_recipes WHERE recipe_id= '" .$recipe_id. "' AND user_id= '".$user['id']."' ";
   $quitarLikeQuery = mysqli_query($conn, $quitarLike1);
}


header("Location:" . $_SERVER['HTTP_REFERER']);
?>