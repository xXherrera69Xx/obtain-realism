<?php

session_start();

require_once "../../includes/config.php";
require_once "../../includes/check_user_logged.php";

$recipeId = $_GET['id'];
$sql3 = "SELECT * FROM recipes WHERE id= '$recipeId'";
$res3 = mysqli_query($conn, $sql3);
$row3 = mysqli_fetch_assoc($res3);

if($user['id'] == $row3['user_id']){
  $sql = "DELETE FROM recipes WHERE id=  '$recipeId'";

  $res = mysqli_query($conn, $sql);
  if (!$res) {
      die('Error de Consulta ' . mysqli_error($conn));
  }

  $section = "publication";

  if(strpos($_SERVER['HTTP_REFERER'], $section)){
    header('Location: ../home.php');
  } else {
    header("Location:" . $_SERVER['HTTP_REFERER']);
  }

}



?>