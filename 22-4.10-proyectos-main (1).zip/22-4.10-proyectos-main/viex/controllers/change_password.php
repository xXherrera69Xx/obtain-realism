<?php

session_start();

require_once "../includes/config.php";

require_once "../includes/check_user_logged.php";


if(!isset($user)){
    header('location: login.php');
}

$errormessage = "";

if(!empty($_POST)){
    $oldpass = sha1($_POST['oldpass']);
    $newpass = sha1($_POST['newpass']);
    $cnewpass = sha1($_POST['confirmnewpass']);
    if($newpass == $cnewpass){
        $sqlVerify = "SELECT password FROM users WHERE id= '" . $user['id'] . "'";
        $resultVerify = mysqli_query($conn, $sqlVerify);
        $rowVerify = mysqli_fetch_assoc($resultVerify);
        if(mysqli_num_rows($resultVerify) > 0){
            if($rowVerify['password'] == $oldpass){
                $sqlChangePass = "UPDATE users SET password = '" . $newpass . "' WHERE id= '". $user['id'] ."'";
                $resultChangePass = mysqli_query($conn, $sqlChangePass);
                if($resultChangePass){
                    header("Location: http://127.0.0.1/22-4.10-proyectos/viex/controllers/change_password.php");
                } else {
                    die('Error de Consulta ' . mysqli_error($conn));
                }
            } else {
                /* Contraseña vieja esta mal */
                $errormessage = "La contraseña antigua que especificaste es incorrecta. Intentelo de nuevo";
            }
        }
    } else {
        /* Contraseñas no coinciden */
        $errormessage = "Asegurate de que ambas contraseñas coincidan.";
    }
}


$page = "Cambiar contraseña";
$section = "change_password";
require_once "../views/layout.php";
