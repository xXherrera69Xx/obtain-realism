<?php
session_start();

require_once "../../includes/config.php";
require_once "../../includes/check_user_logged.php";
$sql = "DELETE FROM comments WHERE id=" . $_GET['id'] . " AND user_id=" . $user['id'] ;

$res = mysqli_query($conn, $sql);
if (!$res) {
    die('Error de Consulta ' . mysqli_error($conn));
}

//header('Location: ../publication.php?id=' . $_GET['recipe_id']);
// o  
header("Location:" . $_SERVER['HTTP_REFERER']);