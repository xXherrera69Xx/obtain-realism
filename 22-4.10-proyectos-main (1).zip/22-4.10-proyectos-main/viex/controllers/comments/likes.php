<?php
session_start();

require_once "../../includes/config.php";
require_once "../../includes/check_user_logged.php";

$comment_id = $_GET['id'];


$comprobacion = "SELECT * FROM likes_comments WHERE comment_id= '".$comment_id."' AND user_id = ". $user['id']." ";
$queryComprobacion = mysqli_query($conn, $comprobacion);

$cantidad = mysqli_num_rows($queryComprobacion);

if($cantidad == 0){
   // Agrego el like a la base de datos
   $darLike2 = "INSERT INTO likes_comments (user_id, comment_id) VALUES ('" .$user['id']. "' , '" .$comment_id. "')";
   $darLikeQuery2 = mysqli_query($conn, $darLike2);
} else {
   // Saco el like a la base de datos
   $quitarLike1 = "DELETE FROM likes_comments WHERE comment_id= '" .$comment_id. "' AND user_id= '".$user['id']."' ";
   $quitarLikeQuery = mysqli_query($conn, $quitarLike1);

}


header("Location:" . $_SERVER['HTTP_REFERER']);
?>