<?php

session_start();

require_once "../includes/config.php";

require_once "../includes/check_user_logged.php";

$sqlUsername = "SELECT username FROM users WHERE id = '" . $_GET['id'] . "'";
$resUsername = mysqli_query($conn, $sqlUsername);
$rowUsername = mysqli_fetch_assoc($resUsername);

if(!$resUsername){
    die('Error de Consulta' . mysqli_error($conn));
}

//Datos de los usuarios followeds
$sqlFollowers = "SELECT users.id, users.username, users.avatar, users.biography  FROM users INNER JOIN follows ON users.id = follows.followed WHERE follows.follower = '" . $_GET['id'] . "'";
$resultFollowers = mysqli_query($conn, $sqlFollowers);

$page = "Usuarios Seguidos";
$section = "users_followeds";
require_once "../views/layout.php";