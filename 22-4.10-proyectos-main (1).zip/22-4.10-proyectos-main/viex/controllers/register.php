<?php
require_once "../includes/config.php";
require_once "../includes/funcion_token.php";

$errormessage = "";

if (!empty($_POST)) {
	$username = trim($_POST['username']);
	$name = trim($_POST['name']);
	$email = trim($_POST['email']);
	$password = sha1($_POST['password']);
	$cpassword = sha1($_POST['confirmpassword']);
	if ($password == $cpassword) {
		// Comprueba que no exista ninguna cuenta con ese email
		$sqlCheckEmail = "SELECT * FROM users WHERE email='$email'";
		$resultCheckEmail = mysqli_query($conn, $sqlCheckEmail);

		// Comprueba que no exista ninguna cuenta con ese username
		$sqlCheckUsername = "SELECT * FROM users WHERE username='$username'";
		$resultCheckUsername = mysqli_query($conn, $sqlCheckUsername);
		if ((!mysqli_num_rows($resultCheckEmail) > 0) && (!mysqli_num_rows($resultCheckUsername) > 0)) {
			
			$sqlRegister = "INSERT INTO users (username, name, email, password, token) VALUES ('" . $username . "', '" . $name . "', '" . $email . "', '" . $password . "', '" . $miToken . "' );";
			$resultRegister = mysqli_query($conn, $sqlRegister);
			if ($resultRegister) {
				$sqlLogin = "SELECT * FROM users WHERE email='$email' AND password='$password'";
				$resultLogin = mysqli_query($conn, $sqlLogin);
				if (mysqli_num_rows($resultLogin) > 0) {
					$rowLogin = mysqli_fetch_assoc($resultLogin);
					session_start();
					$_SESSION['user_id'] = $rowLogin['id'];
					header('Location: home.php');
				}
			} else {
				die('Error de Consulta ' . mysqli_error($conn));
			}
		} else if (mysqli_num_rows($resultCheckEmail) > 0) {
			// Ya existe una cuenta con ese email
			$errormessage = "El email ya esta en uso.";
		} else if (mysqli_num_rows($resultCheckUsername) > 0) {
			// Ya existe una cuenta con ese username 
			$errormessage = "El username ya esta en uso.";
		}
	} else {
		// Contaseña no coincide en los campos
		$errormessage = "Las contraseñas no coinciden.";
	}
}

$page = "Registrate";
$section = "register";
require_once('../views/layout2.php');

