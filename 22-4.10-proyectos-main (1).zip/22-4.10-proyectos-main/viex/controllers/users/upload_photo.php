<?php
session_start();

require_once "../../includes/config.php";

require_once "../../includes/check_user_logged.php";


$photo = $_FILES['avatar']['tmp_name'];
$img_type = $_FILES['avatar']['type'];
$img_size = $_FILES['avatar']['size'];

if(strpos($img_type, "jpeg") || strpos($img_type, "png") || strpos($img_type, "gif")|| strpos($img_type, "webp")){
    if($img_size < 2000000 /*2MB*/){
        // Verifico si existe una carpeta en images/profile. Si no existe, la creo. Si existe entro y borro los archivos que tiene (no las carpetas), luego lo cierro
        $dir = "../../images/profiles/" . $user['id'];
        $dir2 = $dir . "/recipes";
        if (!is_dir($dir)) {
            mkdir($dir);
            mkdir($dir2);
        } else {
            $dir_handle = opendir($dir);
            while ($file = readdir($dir_handle)) {
                if (!is_dir($dir . "/" . $file)) {
                    unlink($dir . "/" . $file);
                }
            }
            closedir($dir_handle);
        }

        $ruta = "images/profiles/" . $user['id'] . "/" . $_FILES['avatar']['name'];
        move_uploaded_file($photo, "../../" . $ruta);
        $sqlUploadPhoto = "UPDATE users SET avatar = '" . $ruta . "' WHERE id = ". $user['id'] ;
        $resultUploadPhoto = mysqli_query($conn, $sqlUploadPhoto);
        if ($resultUploadPhoto) {
            header("Location: ../edit_profile.php");
        } else {
            die('Error de Consulta ' . mysqli_error($conn));
        }
    } else {
        // El archivo pesa mas de 2MB 
        header("Location: ../edit_profile.php");
    }
} else {
    // El archivo no es jpeg, png o gif 
    header("Location: ../edit_profile.php");
}
