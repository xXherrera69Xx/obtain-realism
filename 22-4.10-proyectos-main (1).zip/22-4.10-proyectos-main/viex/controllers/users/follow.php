<?php

session_start();

require_once "../../includes/config.php";
require_once "../../includes/check_user_logged.php";

$rowCreator = $_GET['id'];

$comprobacion = "SELECT * FROM follows WHERE followed= '".$rowCreator."' AND follower = ". $user['id']." ";
$queryComprobacion = mysqli_query($conn, $comprobacion);

$cantidad = mysqli_num_rows($queryComprobacion);

if($cantidad == 0){

    $seguir = "INSERT INTO follows (follower, followed, created_at) VALUES ('" .$user['id']. "' , '" .$rowCreator. "' , current_timestamp() );";

    $seguirQuery = mysqli_query($conn, $seguir);

} else {
    $dejardeSeguir = "DELETE FROM follows WHERE followed= '" .$rowCreator. "' AND follower= '".$user['id']."' ";

    $dejardeSeguirQuery = mysqli_query($conn, $dejardeSeguir);

}


header("Location:" . $_SERVER['HTTP_REFERER']);
?>