<?php

session_start();

require_once "../../includes/config.php";
require_once "../../includes/check_user_logged.php";
$sql = "UPDATE users SET deleted_at = current_timestamp() WHERE id=" . $user['id'] ;

$res = mysqli_query($conn, $sql);
if (!$res) {
    die('Error de Consulta ' . mysqli_error($conn));
}

session_unset();
session_destroy();
    
header('Location: ../list_users.php');

?>