<?php


session_start();

require_once "../includes/config.php";


require_once "../includes/check_user_logged.php";

if (!isset($user)) {
    header('location: login.php');
}

if (!empty($_POST)) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    
    /*$multimedia = $_FILES['multimedia']['tmp_name'];
    $ruta = "../images/profiles/" . $_FILES['multimedia']['name'];
    move_uploaded_file($multimedia, $ruta);*/

    $sqlPostRecipe = "INSERT INTO recipes (title, content, user_id ) VALUES ('" . $title . "', '" . $content . "' , '" . $user['id'] . "');";
    $resultPostRecipe = mysqli_query($conn, $sqlPostRecipe);
    if ($resultPostRecipe) {
        header("Location: home.php");
    } else {
        die('Error de Consulta ' . mysqli_error($conn));
    }
}

$page = "Publicar receta";
$section = "post_recipe";
require_once('../views/layout.php');
?>