<?php
session_start();

require_once "../includes/config.php";


require_once "../includes/check_user_logged.php";


// Para los datos de la receta 
$sqlRecipe = "SELECT * FROM recipes WHERE id= '" . $_GET['id'] . "'";
$resultRecipe = mysqli_query($conn, $sqlRecipe);

$rowRecipe = mysqli_fetch_assoc($resultRecipe);
// Para los datos del usuario creador 
$sqlCreator = "SELECT * FROM users WHERE id = '" . $rowRecipe['user_id'] . "'";
$resultCreator = mysqli_query($conn, $sqlCreator);
$rowCreator = mysqli_fetch_assoc($resultCreator);

// Para cant. los LIKES
$sqlLikes = "SELECT COUNT(like_id) FROM likes_recipes WHERE recipe_id = '" . $rowRecipe['id'] . "'";
$resultLikes = mysqli_query($conn, $sqlLikes);
$rowLikes = mysqli_fetch_assoc($resultLikes);

// Para los datos de los comentarios 
$sqlDataComment = "SELECT * FROM comments WHERE recipe_id= '" . $_GET['id'] . "' ORDER BY id DESC";
$resultDataComment = mysqli_query($conn, $sqlDataComment);
// Para cant. de los COMENTARIOS 
$sqlComments = "SELECT COUNT(id) FROM comments WHERE recipe_id = '" . $rowRecipe['id'] . "'";
$resultComments = mysqli_query($conn, $sqlComments);
$rowComments = mysqli_fetch_assoc($resultComments);

/* Publicar comentario */
if (!empty($_POST)) {
    $recipeId2 = trim($_POST['idReceta']);
    $comment = trim($_POST['comment']);


    $sql3 = "INSERT INTO comments (comment, user_id, recipe_id) VALUES ('" . $comment . "', '" . $user['id'] . "' , '" . $recipeId2 . "');";
    $result2 = mysqli_query($conn, $sql3);
    if ($result2) {
        header("Location: publication.php?id=" . $recipeId2);
    } else {
        die('Error de Consulta ' . mysqli_error($conn));
    }
}

$page = $rowRecipe['title'];
$section = "publication";
require_once "../views/layout.php";
