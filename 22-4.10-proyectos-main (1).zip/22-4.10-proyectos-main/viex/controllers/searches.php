<?php
session_start();

require_once "../includes/config.php";
require_once "../includes/check_user_logged.php";

if(isset($_GET)){
    $search = trim($_GET['search']);
    if(isset($_GET['for'])){
        /*$for = $_GET['for'];*/
        $option = 2;
    } else {
        $option = 1;
    }
}

if(!isset($_GET['for'])){
  // Para busquedas
  $sqlRecipe = "SELECT * FROM recipes WHERE title LIKE '%$search%'";
  $resultRecipe = mysqli_query($conn, $sqlRecipe);
  echo mysqli_error($conn);
} else {
  //Datos de los usuarios buscado
  $sqlFollowers = "SELECT * FROM users WHERE username LIKE '%$search%' AND deleted_at IS NULL ";
  $resultFollowers = mysqli_query($conn, $sqlFollowers);
}

$page = "Busqueda Receta";
$section = "searches";
require_once "../views/layout.php";

?>