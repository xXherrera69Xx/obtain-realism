-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-08-2022 a las 00:41:06
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fooder`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories_recipes`
--

CREATE TABLE `categories_recipes` (
  `recipe_id` int(100) NOT NULL,
  `category_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comments`
--

CREATE TABLE `comments` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `recipe_id` int(100) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `recipe_id`, `comment`, `created_at`) VALUES
(1, 37, 4, 'que gran receta', '2022-06-28 15:16:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `follows`
--

CREATE TABLE `follows` (
  `id` int(11) NOT NULL,
  `follower` int(11) NOT NULL,
  `followed` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `follows`
--

INSERT INTO `follows` (`id`, `follower`, `followed`, `created_at`) VALUES
(2, 43, 37, '2022-08-13 18:29:10'),
(13, 32, 37, '2022-08-13 22:09:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `likes_comments`
--

CREATE TABLE `likes_comments` (
  `id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `comment_id` int(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `likes_comments`
--

INSERT INTO `likes_comments` (`id`, `user_id`, `comment_id`, `created_at`) VALUES
(4, 32, 1, '2022-08-13 21:57:01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `likes_recipes`
--

CREATE TABLE `likes_recipes` (
  `like_id` int(11) NOT NULL,
  `user_id` int(100) NOT NULL,
  `recipe_id` int(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `likes_recipes`
--

INSERT INTO `likes_recipes` (`like_id`, `user_id`, `recipe_id`, `created_at`) VALUES
(1, 43, 10, '2022-08-13 18:14:26'),
(2, 32, 10, '2022-08-13 22:40:03'),
(3, 32, 4, '2022-08-13 22:40:15'),
(4, 32, 3, '2022-08-13 22:40:16');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipes`
--

CREATE TABLE `recipes` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `title` varchar(75) NOT NULL,
  `content` varchar(2500) NOT NULL,
  `image1` varchar(100) DEFAULT NULL,
  `image2` varchar(100) DEFAULT NULL,
  `image3` varchar(100) DEFAULT NULL,
  `image4` varchar(100) DEFAULT NULL,
  `video` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `recipes`
--

INSERT INTO `recipes` (`id`, `user_id`, `title`, `content`, `image1`, `image2`, `image3`, `image4`, `video`, `created_at`) VALUES
(3, 3, 'Tacos mexicanos de carne con salsa roja!', 'Ingredientes:\r\n-250 grs de carne: puede ser peceto, nalga, la que más te guste\r\n-1 cebolla morada mediana\r\n-2 dientes de ajo\r\n-1 chile fresco (opcional)\r\n-1/2 pimiento o morrón rojo\r\n-1/2 pimiento o morrón verde\r\n-Jugo de 1 lima o limón\r\n-1 tomate mediano\r\n-Orégano\r\n-Chile seco (a gusto)\r\n-Sal y pimienta\r\n-Cilantro\r\n-Aceite neutro\r\n\r\nProceso:\r\n1. Cortar los morrones y la cebolla en juliana, el ajo y el chile bien bien pequeño y el tomate en cubitos. Reservar por separado.\r\n2. Cortar la carne en tiritas y en un bol salpimentar, agregar la mitad del zumo de lima o limón y dejar macerando unos 20 minutos.\r\nSi quieren, en este paso pueden hacer la magia que les guste para darle sabor a la carne: ponerle mostaza, un chorro de cerveza… Lo que ustedes quieran. La idea es que los tacos de carne queden bien sabrosos así que todo vale. \r\n3. En una sartén poner un chorro de aceite, el chile seco y el orégano y calentar unos 2 o 3 minutos. Agregar el ajo y el chile y sofreír unos minutos más.\r\n4. Agregar la carne y saltear. Después de 5 minutos, a mitad de cocción, sumar el tomate y terminar de cocinar.\r\n5. Por otro lado, saltear el resto de las verduras hasta que estén cocidas pero OJO: que estén firmes.\r\n6. Mezclar las dos preparaciones y rectificamos con sal y pimienta de ser necesario. Le agregamos el resto del zumo de lima o limón y el cilantro deshojado.\r\n\r\nSalsa roja:\r\n-Ingredientes:\r\n-3 chiles verdes\r\n-1/2 morrón o pimiento verde\r\n-1 chile jalapeño\r\n-5 tomates verdes\r\n-Cilantro\r\n-1/2 cebolla\r\n-Sal\r\n\r\nProcedimiento:\r\n-Poner el pimiento, la cebolla, el chile y los tomates en una sartén con un poquito de aceite de oliva y tapar. Cuando estén cocidos dejar que se enfríen.\r\n-Ponerlas en una licuadora y sumarle sal y cilantro a gusto. Licuar hasta obtener una masa homogénea.\r\n\r\nCon el relleno y la salsa preparada, solo queda preparar el taco en una rapidita y listo el pollo!! A comer', NULL, NULL, NULL, NULL, NULL, '2022-06-28 15:12:41'),
(4, 3, 'Hamburguesa smash doble', 'Que es una hamburguesa smash? Es una tecnica muy conocida en EEUU para hacer hamburguesas, esta trata de aplastar el paty mientras se cocina para asi generar una super costra bien crujiente, que queda muy bien!\r\n\r\nLos ingredientes para esta smash burger son:\r\n-120 g Carne picada\r\n-Queso cheddar en lonchas\r\n-Pepinillo\r\n-Cebolla morada\r\n-Lechuga\r\n-Mayonesa\r\n-Pan de hamburguesa\r\n-Mantequilla\r\n-Sal\r\n-Pimienta negra molida (Opcional)\r\n\r\nLa carne es lo principal de la burga por eso, recomendamos, una carne que tenga una proporcion de 80% carne magra y 20% grasa. Además recomendamos que la carne picada, en vez de estar pasadas por el disco grueso como cualquier medallon de carne, este pasada dos veces por el disco chico.\r\nAclarado esto, empezemos con el proceso:\r\n1. Dividir la carne picada en dos partes de 60g (50% del total) y hacerlas con forma de bola\r\n2. Con la plancha bien caliente, tostar los panes de hamburguesa, para que la miga de este se selle y no se desarme.\r\n3. Al pan, ponerle un poco de mayonesa en ambos lados. Sobre la mayonesa de la base del pan, poner un poco de lechuga. Luego ponerle pepinillo arriba (a gusto). Y finalmente ponerle unas rodajas de cebolla morada.\r\n4. Bien, ya preparado el pan y sus complementos, vamos a la parte MAS IMPORTANTE de la receta, hacer el paty smash. Para esto, en la misma sarten donde tostamos el pan (la cual debe estar bien caliente), vamos poner las bolas de carne picada que habiamos hecho (sin aceite). Inmediatamente luego de poner las bolas de carne picada tenemos que con la espatula (o  un artefacto especial para hacer las burgas smash) aplastarlas bien, pero ojo porque puede que se nos pegue la carne a la espatula, por eso, luego de aplastarla debemos moverla sobre la bolas de carne aplastadas y, de paso, darle forma. Cuando ya tengamos las bolas de carne aplastadas, vamos a decirle paty smash, le pondremos un poco de sal y si quieren un poco de pimienta. En pocos segundos ya estara hecha de un lado y la tendremos que dar vuelta lo mas cuidadosamente (por las dudas), y ponerle las fetas de cheddar, luego esperar hasta que se termine este se derrita (que seran otros pocos segundos). Y listo, ya tenemos los dos patys smash hechos\r\n5. Ahora solo queda colocar los patys smash uno encima de otro y ponerlo entre los panes.\r\n\r\nY ya puedes comer tu hamburguesa smash doble, la tecnica para hacer los patys smash puede que no te salga tan bien a la primera, por eso, no te desesperes que a medida que vayas haciendo mas,', NULL, NULL, NULL, NULL, NULL, '2022-06-28 15:12:41'),
(7, 37, 'testeando para la desactivacion de cuenta', 'testinmg', NULL, NULL, NULL, NULL, NULL, '2022-06-30 20:45:58'),
(10, 3, 'Ejemplo', 'Esto es un ejemplo de una receta', '../images/profiles/', NULL, NULL, NULL, NULL, '2022-07-05 13:18:05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(60) NOT NULL,
  `biography` varchar(300) DEFAULT NULL,
  `gender` enum('male','female','other','no') NOT NULL DEFAULT 'no',
  `email` varchar(300) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` text DEFAULT 'images/profiles/default.png',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `token` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `biography`, `gender`, `email`, `password`, `avatar`, `created_at`, `deleted_at`, `token`) VALUES
(1, 'homero', 'Gaston', 'Soy un fanatico del LoL', 'male', 'gasty@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'images/profiles/default.png', '2022-06-13 04:20:57', NULL, NULL),
(2, 'aborigendesquiciado', 'Simon', 'Soy un dibujante fracasado', 'male', 'simon2004@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profiles/default.png', '2022-06-01 23:28:04', NULL, NULL),
(3, 'elmasi', 'Massi', 'Boca Juniors', 'male', 'massipozzuto2016@gmail.com', '8cb2237d0679ca88db6464eac60da96345513964', 'images/profiles/3/tenor.png', '2022-06-06 23:28:04', NULL, NULL),
(32, 'aa', 'aa', NULL, 'other', 'aa', 'e0c9035898dd52fc65c41454cec9c4d2611bfb37', 'images/profiles/default.png', '2022-06-22 21:31:03', NULL, NULL),
(35, 'homero9305', 'gastonam', 'esto es un test asdasd', 'other', 'testeandocambios@gmail.com', '8cb2237d0679ca88db6464eac60da96345513964', 'images/profiles/default.png', '2022-06-23 23:09:26', NULL, 'ibj4Da3añLnK75'),
(37, 'holaaa', 'queondaa', 'test', 'no', 'gaston.amenta@gmail.com', '2b1466e64b6040935428cd5644d49ffefaf3c62f', 'images/profiles/default.png', '2022-06-27 21:23:46', '2022-06-30 21:52:49', 'b?DLn43ia7aj?5K'),
(38, 'quququququeueueu', 'testeao', NULL, 'no', 'testeando@gmail.com', 'a21f505a3e11cffaaa48d8bdf94dab19134dfcda', 'images/profiles/default.png', '2022-06-30 21:15:34', '2022-06-30 21:32:38', 'j4bLn57Kaa??38D'),
(43, '22', '22', NULL, 'no', '22', '12c6fc06c99a462375eeb3f43dfd832b08ca9e17', 'images/profiles/default.png', '2022-08-13 18:02:48', NULL, 'DLnKbj4aiñ53a7');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categories_recipes`
--
ALTER TABLE `categories_recipes`
  ADD KEY `fk_categoriesrecipes_recipes` (`recipe_id`),
  ADD KEY `fk_categoriesrecipes_categories` (`category_id`);

--
-- Indices de la tabla `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `fk_comments_recipes` (`recipe_id`),
  ADD KEY `fk_comments_users` (`user_id`);

--
-- Indices de la tabla `follows`
--
ALTER TABLE `follows`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `likes_comments`
--
ALTER TABLE `likes_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_commentslikes2_users` (`user_id`),
  ADD KEY `fk_commentslikes_comments` (`comment_id`);

--
-- Indices de la tabla `likes_recipes`
--
ALTER TABLE `likes_recipes`
  ADD PRIMARY KEY (`like_id`),
  ADD KEY `fk_likesrecipes_recipes` (`recipe_id`),
  ADD KEY `fk_likesrecipes2_users` (`user_id`);

--
-- Indices de la tabla `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_recipes_users` (`user_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT de la tabla `follows`
--
ALTER TABLE `follows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `likes_comments`
--
ALTER TABLE `likes_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `likes_recipes`
--
ALTER TABLE `likes_recipes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `recipes`
--
ALTER TABLE `recipes`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `categories_recipes`
--
ALTER TABLE `categories_recipes`
  ADD CONSTRAINT `fk_categoriesrecipes_categories` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `fk_categoriesrecipes_recipes` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`);

--
-- Filtros para la tabla `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `fk_comments_recipes` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_comments_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `likes_comments`
--
ALTER TABLE `likes_comments`
  ADD CONSTRAINT `fk_commentslikes2_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_commentslikes_comments` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `likes_recipes`
--
ALTER TABLE `likes_recipes`
  ADD CONSTRAINT `fk_likesrecipes2_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_likesrecipes_recipes` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `recipes`
--
ALTER TABLE `recipes`
  ADD CONSTRAINT `fk_recipes_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
