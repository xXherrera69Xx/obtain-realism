function createPreview(file) {
    var imgCodified = URL.createObjectURL(file);
    var img = $('<div class="d-inline-block justify-content-center"><div class="image-container" ><figure><img src="' + imgCodified + '" alt="foto" ><!--<figcaption><i class="icon-cross"></i></figcaption>--></figure></div></div>');
    $(img).insertAfter("#form__container");
}

$(document).ready(function () {

    // Abro el explorador de archivo  
    $(document).on("click", "#selectfile", function () {
        $("#form__container--file").click();
    });

    // Evento change
    $(document).on("change", "#form__container--file", function () {
        console.log(this.files);
        var files = this.files;
        var element;
        var supportedImages = ["image/jpeg", "image/png", "image/gif"];
        var elementosNoValidos = false;

        for (var i = 0; i < files.length; i++) {
            element = files[i];
            if (supportedImages.indexOf(element.type) != -1) {
                createPreview(element);
            } else {
                elementosNoValidos = true;
            }

        }

        /*if (elementosNoValidos) {
            showMessage("Se encontraron elementos no validos");
        } else {
            showMessage("Los archivos se subieron correctamente");
        }*/
    });

    $(document).on("mouseenter", ".image-container", function (e) {
        var cross = $('<div class="icon-cross"><i class="bi bi-x-lg"></i></div>');
        $(cross).insertBefore(".image-container");
        
    });
    $(document).on("mouseleave", ".image-container", function (e) {
        $(".bi-x-lg").parent().remove();
        
    });

    $(document).on("click", ".image-container", function (e) {
        $(this).parent().remove();
    });

});