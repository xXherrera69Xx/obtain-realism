(function ($) {

  "use strict";

  $(".toggle-password").click(function () {

    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
  });

})(jQuery);


(function ($) {

  "use strict";

  $(".toggle-confirmpassword").click(function () {

    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
  });


})(jQuery);



/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function dropDownProfile() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function (event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}


/* aaa

$(document).on("change", "#form__container--file", function () {
  document.form.submit()
});
*/


/*window.addEventListener('load', () => {
   const name = document.getElementById("name");
   const email = document.getElementById("email");
   const username = document.getElementById("username");
   const password = document.getElementById("password-field");
   const confirmpass = document.getElementById("confirmpassword-field");
   const form = document.getElementById("form");
   

  form.addEventListener('submit', (e)=> {
    e.preventDefault()
    validaCampos()
  })
  const validaCampos = ()=>{
    //caputrar los valores ingresados :)
    const usernameValue = username.value.trim()
    const nameValue = name.value.trim()
    const emailvalue = email.value.trim()
    const passwordValue = password.value.trim()
    const confirmValue = confirmpass.value.trim()
//validacion de username
    if(!usernameValue){
      validafalla(username, 'campo vacio')
    }
    else{
      validaOk(username)
    } 
//validar email
    if(!emailvalue){
      validafalla(email, 'campo vacio')
    }
    else if(!validaEmail(emailvalue)){
      validafalla(email, 'el email no es valido')
    }
    else{
      validaOk(email)
    }
//validar password
    const er = /^(?=.*[a-z])(?=.*[A-Z]){6,15}/
    if(!passwordValue){
      validafalla(password, 'campo vacio')
    }
    else if(passwordValue.length < 8){
      validafalla(password, 'ingrese 8 caracteres minimo')
    }
    else if(!passwordValue.match(er)){
      validafalla(password, 'debe tener al menos una mayuscula y una minuscula')
    }
    else{
      validaOk(password)
    }
//validar confirmacion
    if(!confirmValue){
      validafalla(confirmpass, 'confirme la contraseña')
    }
    else if(passwordValue != confirmValue){
      validafalla(confirmpass, 'las contraseñas no coinciden')
    }
    else{
      validaOk(confirmpass)
    }
//validacion del nombre

    if(!nameValue){
      validafalla(name, 'campo vacio')
    }
    else{
      validaOk(name)
    }
  }
  const validafalla = (input, msje) => {
    const form = input.parentElement
    const warning = form.querySelector('p')
    warning.innerText = msje
    form.classList = 'form-group fail'
  }
  const validaOk = (input, msje) => {
    const form = input.parentElement
    const warning =form.querySelector('p')
    form.classList = 'form-group succes'
    
  }

  const validaEmail = (email) => {
    return /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i.test(email);
  }
}) */