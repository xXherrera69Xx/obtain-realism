/*
Que hace este archivo:
1) Valida que la contrasenia original y la repetida sean iguales
2) Valida que el nombre de usuario sea correcto
3) Valida la fecha de nacimiento
4) Llama al PHP en caso de registro

Es requerido por:
1) El registro
2) La recuperacion de contrasenias
*/

// Valida si las contrasenias coinciden
function does_password_match() {
    lacontra = document.getElementById("lacontra").value;
    lacontra_validation = document.getElementById("lacontra_validation").value;
    try {
        if (validate_password() !== true) {throw ple.not_validated}
        else if (lacontra_validation == "") {throw ple.empty}
        else if (lacontra !== lacontra_validation) {throw ple.not_the_same}
    } catch (exception) {
        display_error_login(exception, 4);
        return false;
    }
    hide_message_error(4);
    return true;
}

// Valida el usuario
const min_username_lenght = 3;
const max_username_lenght = 16;

function validate_username() {
    elusuario = document.getElementById("elusuario").value;
    elusuario_caracteres = elusuario.length;
    try {
        if (elusuario == "") {throw username.empty}
        else if ((elusuario_caracteres <= min_username_lenght) !== false) {throw username.min_error}
        else if ((elusuario_caracteres >= max_username_lenght) !== false) {throw username.max_error}
    } catch (exception) {
        display_error_login(exception, 3);
        return false;
    }
    hide_message_error(3);
    return true;
}

// Valida la edad

const currentDate = new Date();
const currentDateMs = currentDate.getTime();

function compute_years_ms(year, belowzero) {
    pre_calculated = ((parseInt((24 * 365 * year) + ((year/4) * 24))) * 60 * 60 * 1000);
    switch (belowzero) {
        case true:
            return (currentDateMs - pre_calculated);
        case false:
            return pre_calculated;
        default:
            throw ("Fallo al pasar anios a milisegundos. \n No se puede computar si se calcula debajo de la fecha cero o no. \n Contactar soporte.");
    }
}
const min_age_ms = compute_years_ms(13, false);
const max_age_ms = compute_years_ms(110, true);

function validate_birthdate() {
  userBirthdate = document.getElementById("birthdate").value;

  currentUserBirthDate = new Date(userBirthdate);
  currentUserMs = currentUserBirthDate.getTime();
  try {
      if ((typeof userBirthdate) !== "string") {throw birthdate.non_string}
      else if (userBirthdate == "") {throw birthdate.empty}
      else if ((currentUserMs + min_age_ms) > (currentDateMs)) {throw birthdate.age.underage}
      else if (currentUserMs <= max_age_ms) {throw birthdate.age.overage}
      else if (currentUserMs > currentDateMs) {throw birthdate.age.invalid}
  } catch (exception) {
      display_error_login(exception, 5);
      return false;
  }
  hide_message_error(5);
  return true;
}

$(document).ready(function() {

if (validate_passwordmatch_jquery === true) {
    $("#lacontra_validation").blur(function() {
        does_password_match();
    });
}

if (validate_username_jquery === true) {
    $("#elusuario").blur(function() {
        validate_username();
    });   
}

if (validate_birthdate_jquery === true) {
    $("#birthdate").blur(function() {
        validate_birthdate();
    });   
}

});