/*}
Puedes tocar algunos ajustes de aca ya que este js se encarga
de administrar mensajes de error en pantalla para el usuario
en el momento de loguearse/registrarse.

Que hace este archivo:
1) Carga todos los mensajes de error de login/registro
2) Permite activar/desactivar los validadores al tabular fuera del campo
3) Recibe los errores del programa y los procesa.

Es requerido por:
1) El login
2) El registro
3) La recuperacion de contrasenias
*/

// mle = mail login error
const mle = {
  slash: 'El email no puede contener el caracter "/" o "\"',
  non_string: "Error al cargar el tipo de email",
  empty: "No has ingresado ningun email.",
  not_found: "El email ingresado no se encuentra registrado.",
  wrong: "El email ingresado es incorrecto.",
  unknow: "Ha ocurrido un error desconocido desconocido en el email",
  used: "Este email ya se encuentra registrado.",
  test: "Mensaje de prueba de fallo de email",
};
// ple = password login errors
const ple = {
  slash: 'La contrase&ntilde;a no puede contener el caracter "/" o "\"',
  non_string: "Error al cargar el tipo de contrase&ntilde;a",
  empty: "No has ingresado ninguna contrase&ntilde;a",
  min_error: "La contrase&ntilde;a debe ser mayor a 8 caracteres.",
  max_error: "La contrase&ntilde;a debe ser menor de 32 caracteres.",
  missing: {
      number: "La contrase&ntilde;a debe tener al menos 1 numero",
      lowercase: "La contrase&ntilde;a debe tener al menos una minuscula",
      uppercase: "la contrase&ntilde;a debe tener al menos una mayuscula",
      special: "La contrase&ntilde;a debe tener al menos un caracter especial",
  },
  wrong: "La contrase&ntilde;a ingresada es incorrecta",
  unknow: "Ha ocurrido un error desconocido en la contrase&ntilde;a",
  not_the_same: "La contrase&ntilde;a no es identica a la anterior",
  not_validated: "La contrase&ntilde;a original no es valida",
  test: "Mensaje de prueba de fallo de contrase&ntilde;a",
};

const username = {
  slash: 'El usuario no puede contener el caracter "/" o "\"',
  non_string: "Error al cargar el tipo de usuario",
  empty: "No has ingresado ningun nombre de usuario.",
  min_error: "El nombre debe ser mayor de 3 caracteres.",
  max_error: "El nombre debe ser menor de 16 caracteres.",
  used: "Este nombre ya se encuentra en uso.",
  forbidden: "Este nombre es inapropiado.",
  unknow: "Ha ocurrido un error desconocido con el usuario.",
  test: "Mensaje de prueba de fallo de usuario",
};

const birthdate = {
  slash: 'La edad no puede contener el caracter "/" o "\"',
  empty: "No has ingresado ninguna edad",
  non_string: "Error al cargar el tipo de edad",
  age: {
    underage: "Usted no cumple la edad minima permitida",
    overage: "Ingresa tu verdadera edad",
    invalid: "Edad invalida",
  },
  unknow: "Ha ocurrido un error desconocido con la edad",
  test: "Mensaje de prueba de fallo de edad",
};

// LLamar a los validadores cuando se tabula fuera del campo

const validate_email_jquery = true;
const validate_password_jquery = true;
const validate_passwordmatch_jquery = true;
const validate_username_jquery = true;
const validate_birthdate_jquery = true;

// Que mensajes estan desactivados, debes poner el id del mensaje
// y despues una coma para separarlos (Basicamente un array).

const message_disabled = [ple.test, mle.test, username.test, birthdate.test];

// ATENCION: NO TOCAR TODO LO QUE SE ENCUENTRE DEBAJO DE ESTA LINEA

// Sistema que muestra el mensaje de error en pantalla
function display_error_login(id, whattype) {
  div_error = select_whattype(whattype, false);
  message_disabled.forEach(element => {
      if (element === id) {
          throw "Mensaje desactivado";
      }
  });
  try {
      document.getElementById(div_error).innerHTML = id;
      document.getElementById(div_error).hidden = false;
  } catch (exception) {
      throw ("Fallo al MOSTRAR mensaje de error en pantalla. \n Puede que el diverror o el id esten mal. \n Contactar soporte.");
  }
};

// Sistema que oculta el mensaje de error en pantalla
function hide_message_error(whattype) {
  div_error = select_whattype(whattype, true);
  try {
      document.getElementById(div_error).innerHTML = "";
      document.getElementById(div_error).hidden = true;
  } catch (exception) {
      throw ("Fallo al OCULTAR mensaje de error en pantalla. \n Puede que el diverror o el id esten mal. \n Contactar soporte.");
  }
};

contra_buttom = email_buttom = username_buttom = contra2_buttom = birthdate_buttom = false;
// En los sistemas de mostrar y ocultar, se necesita saber sobre que div se esta operando.
function select_whattype(whattype, trueorfalse) {
switch (whattype) {
    case 1:
      div_error = "contra_error";
      contra_buttom = trueorfalse;
      break;
    case 2:
      div_error = "email_error";
      email_buttom = trueorfalse;
      break;
    case 3:
      div_error = "username_error";
      username_buttom = trueorfalse;
      break;
    case 4:
      div_error = "contra_error2";
      contra2_buttom = trueorfalse;
      break;
    case 5:
      div_error = "birthdate_error";
      birthdate_buttom = trueorfalse;
      break;
    default:
      throw ("Fallo al mostrar mensaje de error en pantalla. \n No se puede computar que tipo de error es. \n Contactar soporte.");
};
switch (trueorfalse) {
  case true:
    if ((contra_buttom && email_buttom && username_buttom && contra2_buttom && birthdate_buttom) === true) {
      document.getElementById("botonenviar").removeAttribute("disabled");
    }
    break;
  case false:
    document.getElementById("botonenviar").setAttribute("disabled", "disabled");
    break;
  default:
    throw ("Fallo al activar o desactivar el boton de envio. \n No se puede computar si se debe mostrar o no. \n Contactar soporte.")

};
return div_error;
};