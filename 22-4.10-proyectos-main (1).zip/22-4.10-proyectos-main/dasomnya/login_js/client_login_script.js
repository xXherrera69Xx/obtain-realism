/*
Que hace este archivo:
1) Valida el email
2) Valida la contrasenia
3) Llama al PHP en caso de login
Es requerido por:
1) El login
2) El registro
3) La recuperacion de contrasenias
*/

//Validador de emails
const regexemail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
function validate_email() {
    elemail = document.getElementById("elemail").value;
    try {
        if ((typeof elemail) !== "string") {throw mle.non_string}
        else if (elemail == "") {throw mle.empty}
        else if (regexemail.test(elemail) !== true) {throw mle.wrong}
    } catch (exception) {
        display_error_login(exception, 2);
        return false;
    };
    hide_message_error(2);
    return true;
}

// Ajustes internos de la contrasenia, si se cambia algo aca
// tambien debe cambiarse del lado del servidor
const min_password_lenght = 8;
const max_password_lenght = 32;
    // Esto se fija que la contra tenga minusculas, mayusculas, especiales y numeros
    // NO LO TOQUES A NO SER QUE SEPAS COMO FUNCIONA
    const regex_password_validator = {
        number: /(?=.*\d)/,
        lowercase: /(?=.*[a-z])/,
        uppercase: /(?=.*[A-Z])/,
        special: /(?=.*\W)/,
    }
    // /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/;

// Validador de contrasenias
function validate_password() {
    // Obtener la contrasenia que el usuario ingreso y ajustarla para la funcion
    lacontra = document.getElementById("lacontra").value;
    lacontra_caracteres = lacontra.length;
    // Aca el sistema revisa en busqueda de errores por parte del usuario en la contrasenia.
    try {
        if ((typeof lacontra) !== "string") {throw ple.non_string}
        else if (lacontra === "") {throw ple.empty}
        else if ((lacontra_caracteres < min_password_lenght) !== false) {throw ple.min_error}
        else if ((lacontra_caracteres > max_password_lenght) !== false) {throw ple.max_error}
        else if ((regex_password_validator.number.test(lacontra)) !== true) {throw ple.missing.number}
        else if ((regex_password_validator.lowercase.test(lacontra)) !== true) {throw ple.missing.lowercase}
        else if ((regex_password_validator.uppercase.test(lacontra)) !== true) {throw ple.missing.uppercase}
        else if ((regex_password_validator.special.test(lacontra)) !== true) {throw ple.missing.special};
    } catch (exception) {
        // Si el sistema encontro un error se debe llamar al sistema que muestra errores
        // Tambien se debe retornar false la funcion para indicar que fallo al validar
        display_error_login(exception, 1);
        return false;
    }
    hide_message_error(1);
    return true;
}

// En las respectivas paginas de registrase y loguearse. los botones para alternar
// entre estas dos deben ejecutar un script para cambiar de pagina
function changeMenu(x) {
    switch (x) {
        case 1:
            window.open("register.php", "_self");
            break;
        case 2:
            window.open("login.php", "_self")
            break;
        // Aca deberia llamarse a una futura pagina de 404
        //default:
        //
        //    break;
    }
}
$(document).ready(function() {

// Llamar al validador de emails cuando se tabula fuera del campo de emails (clases)
if (validate_email_jquery === true) {
    $("#elemail").blur(function() {
        validate_email();
    });
}

// Llamar al validador de contrasenias cuando se tabula fuera del campo de emails (Clases).
if (validate_password_jquery === true) {
    $("#lacontra").blur(function() {
        validate_password();
    });
}

});