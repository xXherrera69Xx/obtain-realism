<?php
require_once "../server/config.php";

require_once "../server/check_user_logged.php";

$view = "subscripciones";
require_once "../views/layout.php";