<?php
     include("../server/config.php");
     $response=new stdClass();
     $datos=[];
     $i = 0;
     $text= $_POST['text'];
     $sql = "SELECT * FROM manga WHERE estado=1 AND title LIKE '%$text%' ";
     $result = mysqli_query($conn, $sql);
     while ($row = mysqli_fetch_array($result)) {
          $obj=new stdClass();
          $obj->nombre=$row['title'];
          $obj->descripcion= $row['description']; 
          $datos[$i]=$obj;
          $i++;
     }
     $response->datos=$datos;

     mysqli_close($conn);
     header('Content-Type: application/json');
     echo json_encode($response);
     $view = "busqueda";
     require_once('../views/layout.php');
?>    