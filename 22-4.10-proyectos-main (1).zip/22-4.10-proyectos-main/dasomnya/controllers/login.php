<?php

require_once('../server/config.php');

if (!empty($_POST)) {
    $email = trim($_POST['email']);
    $password = sha1($_POST['password']);

    $sql = "SELECT * FROM users WHERE Email='$email' AND Password='$password'";
    $resultLogin = mysqli_query($conn, $sql);
    if (mysqli_num_rows($resultLogin) > 0) {
        $rowLogin = mysqli_fetch_assoc($resultLogin);
        session_start();
        $_SESSION['user_id'] = $rowLogin['id'];
        header("Location: ../views/homepage.php");
    } else {
        /* Error en la autentificacion */
        header("Location: ../views/login.php");
    }
}

$view = "login";
require_once('../views/layout.php');