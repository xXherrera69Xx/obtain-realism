<?php
require_once "../server/config.php";

require_once "../server/check_user_logged.php";

$view = "intlectura1";
require_once "../views/layout.php";