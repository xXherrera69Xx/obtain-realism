<?php
require_once "../server/config.php";

require_once "../server/check_user_logged.php";

$view = "register";
require_once "../views/layout.php";