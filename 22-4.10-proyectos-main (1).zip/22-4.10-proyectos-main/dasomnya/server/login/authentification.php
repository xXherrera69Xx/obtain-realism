<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Cargando...</title>
        <link rel="icon" type="image/x-icon" href="../../Img/favicon.png">
    </head>
    <body>
        <p>Procesando informacion, por favor espere...</p>
    </body>
</html>

<?php
//Declaro a la clase abstracta y al constructor protegido para que
// la clase validateData solo pueda ser instanciada por otra clases

require("../mysqli_connector.php");

abstract class validateData  {
    public static $error;
    public static $error2;
    public static $error3;
    public static $htmlchars;
    public static $information;
    protected $isRegister;
    protected $data;
    protected $useemail;
    const REGEX_PASSWORD_NUMBER = "/(?=.*\d)/";
    const REGEX_PASSWORD_LOWERCASE = "/(?=.*[a-z])/";
    const REGEX_PASSWORD_UPPERCASE = "/(?=.*[A-Z])/";
    const REGEX_PASSWORD_SPECIAL = "/(?=.*\W)/";
    const REGEX_SLASH = "/(?=.*[\/])/";
    const PASSWORD_MAX_LENGHT = 32;
    const PASSWORD_MIN_LENGHT = 8;
    const USERNAME_MAX_LENGHT = 16;
    const USERNAME_MIN_LENGHT = 3;

    protected function __construct($isRegister) {
        echo("Se inicializo el constructor");
        $this->validateDataSuccess = false;
        try {
            $this->getData();
            $this->validateEmail();
            $this->validatePassword();
            switch ($isRegister) {
                case true:
                    $this->isRegister = true;
                    $this->doPasswordMatch();
                    $this->validateUsername();
                    $this->validateBirthdate();
                    break;
                case false:
                    $this->isRegister = false;
                    break;
                default:
                    throw new Exception("global.unknow_method");
                    break;
            }
            $this->hashPassword();
            $this->validateDataSuccess = true;
        } catch (Exception $e) {
            $this->returnLogin($e->getMessage());
        };
    }
    // El static hace que se pueda llamar por fuera de la clase
    // Sin necesidad de instanciar a la clase
    public static function returnLogin($error) {
        //header("LOCATION: ../../register.php?error=" . $error);
        echo("El sistema devolvio el error: ");
        echo($error);
        die;
    }
    public static function dataExists($data, $error, $error2, $error3, $htmlchars) {
        echo("<pre>" . print_r([$_POST[$data]]) . "</pre>");
        if ((isset($_POST[$data]) === false) || ($_POST[$data] == (null || ""))) { throw new Exception($error); }
        else if (gettype($_POST[$data]) !== 'string') { throw new Exception($error2); } 
        else if ((preg_match(self::REGEX_SLASH, $_POST[$data])) !== 0) { throw new Exception($error3); }
        else { 
            $information = stripslashes(trim($_POST[$data]));
            if ($htmlchars === true) {
                $information = htmlspecialchars($information);
            }
            return $information;
            }
        }
    protected function getData() {
        $this->email = $this->dataExists('email', 'mle.empty', 'mle.non_string', 'mle.slash', true);
        $this->username = $this->dataExists('username', 'username.empty', 'username.non_string', 'username.slash', true);
        $this->username_lenght = strlen($this->username);
        $this->birthdate = $this->dataExists('birthdate', 'birthdate.empty', 'birthdate.non_string', 'birthdate.slash', true);
        $this->password = $this->dataExists('password', 'ple.empty', 'ple.non_string', 'ple.slash', false);
        $this->password_lenght = strlen($this->password);
        $this->password2 = $this->dataExists('password2', 'ple.empty', 'ple.non_string', 'ple.slash', false);
    }
    protected function validateEmail() {
        if (filter_var($this->email, FILTER_VALIDATE_EMAIL)) { return true; } 
        else { throw new Exception("mle.wrong"); }
    }
    protected function validatePassword() {
        echo $this->password;
        echo "<br>";
        echo $this->password_lenght;
        if (($this->password_lenght > self::PASSWORD_MAX_LENGHT) !== false) { throw new Exception("ple.max_error"); }
        else if (($this->password_lenght < self::PASSWORD_MIN_LENGHT) !== false) { throw new Exception("ple.min_error"); }
        else if ((preg_match(self::REGEX_PASSWORD_NUMBER, $this->password)) !== 1) { throw new Exception("ple.missing.number"); }
        else if ((preg_match(self::REGEX_PASSWORD_LOWERCASE, $this->password)) !== 1) { throw new Exception("ple.missing.lowercase"); }
        else if ((preg_match(self::REGEX_PASSWORD_UPPERCASE, $this->password)) !== 1) { throw new Exception("ple.missing.uppercase"); }
        else if ((preg_match(self::REGEX_PASSWORD_SPECIAL, $this->password)) !== 1) { throw new Exception("ple.missing.special"); }
        else { return true; };
    }
    protected function doPasswordMatch() {
        if (($this->password) === ($this->password2)) { return true; }
        else { throw new Exception("ple.not_the_same"); }
    }
    protected function validateUsername() {
        if (($this->username_lenght >= self::USERNAME_MAX_LENGHT) !== false) { throw new Exception("username.max_error");}
        else if (($this->username_lenght <= self::USERNAME_MIN_LENGHT) !== false) { throw new Exception("username.min_error"); }
        else { return true; }
    }
    protected function validateBirthdate() {
        // Falta completar
        return ("2022-10-12");
    }
    protected function hashPassword() {
        $this->password_hashed = sha1($this->password);
        echo ("<pre> Contrasenia hasheada: " . $this->password_hashed . "<pre>");
        return true;
    }
    abstract protected function createQuery();
    protected function selectUserID($useemail) {
        // No funciona
        $this->query = ("SELECT ID FROM Users WHERE ");
        if ($useemail === true) {
            $this->query .= ("Email = '" . $this->email . "');");
        } else {
            $this->name .= ("Name = '" . $this->username . "');");
        }
        echo ("pre1");
        $result = $GLOBALS["mClass"]->storeMySQLiResult($this->query);
        echo ("pre2");
        $GLOBALS["mClass"]->numRowIsZero('global.unknow.userid', $result);
        echo ("pre3");
        return array_column($GLOBALS["mClass"]->fetchAssoc($result), 'ID');
    }
}

trait createCookie {
    // Faltan corregir errores
    private $expirationDays;
    private function cookieConstructor() {
        try {
            //Este constructor requiere si o si un UserID para funcionar.
            $this->createToken();
            $this->databaseToken();
            $this->setUserCookie();
        } catch (Exception $e) {
            $this->returnLogin($e->getMessage());
        }
    }
    private function createToken() {
        $expirationDays = 30;
        $this->unhashedToken = random_bytes(32);
        $this->expirationDate = time() + ($expirationDays * 24 * 60 * 60);
        $this->hashedToken = password_hash($this->password, PASSWORD_DEFAULT);
    }
    private function databaseToken() {
        $this->query = "INSERT INTO loginTokens(ID, expirationTime, User_ID) ";
        $this->query .= "VALUES ('" . $this->hashedToken . "', '" . $this->expirationDate ."', '" . $this->userid . "');";
        $GLOBALS["mClass"]->storeMySQLiResult($this->query);
    }
    private function setUserCookie() {
        setcookie("cattusmanga_login", $this->unhashedToken, $this->expirationDate, "/", "", false, true);
    }
}

class register extends validateData {
    protected $result;
    use createCookie;
    final public function __construct() {
        parent::__construct(true);
        if ($this->validateDataSuccess === true) {
            try {
                createClass();
                $this->createQuery();
                //$this->selectUserID();
                $this->doesUserExists();
                $this->createUser();
                //$this->userid = $this->selectUserID(true);
                //$this->cookieConstructor();
            } catch (Exception $e) {
                $this->returnLogin($e->getMessage());
            }
        }
    }
    private function doesUserExists() {
        $this->query = "SELECT Email FROM Users WHERE Email='" . $this->email . "';";
        $result = $GLOBALS["mClass"]->storeMySQLiResult($this->query);
        $GLOBALS["mClass"]->numRowIsZero('mle.used', $result);
        $this->query = "SELECT Name FROM Users WHERE Name='" . $this->username . "';";
        $result = $GLOBALS["mClass"]->storeMySQLiResult($this->query);
        $GLOBALS["mClass"]->numRowIsZero('username.used', $result);
    }
    protected function createQuery() {
        $this->finalquery = "INSERT INTO Users(ID, Name, Email, Password, birthdate, activation_date, desactivation_date, moderationRoles_ID, suscriptions_ID, email_validated, points) ";
        $this->finalquery .= "VALUES (" . rand(20050, 20200) . ", '" . $this->username . "', '" .  $this->email . "', '" . $this->password_hashed . "', " . $this->birthdate . ", NOW(), null, 1, 3, false, 100);";
    }
    private function createUser() {
        if (($GLOBALS["mysqli"]->query($this->finalquery)) === true) {
            echo("USUARIO CREADO EXITOSAMENTE");
        }
        else {
            echo ("La consulta ha fallado");
           // mysqli_query_failed_fatal();
            die("Programa finalizado");
        }
    }
}

$test = new register;
?>