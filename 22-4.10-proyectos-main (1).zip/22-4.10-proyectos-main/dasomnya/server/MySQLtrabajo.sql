CREATE DATABASE cattusmanga;
USE cattusmanga;

CREATE TABLE IF NOT EXISTS Ages (
	ID tinyint UNSIGNED NOT NULL,
	clasification VARCHAR(10),
	CONSTRAINT UC_Ages UNIQUE (ID,clasification),
	PRIMARY KEY (ID)
);
INSERT INTO 
	Ages(ID, clasification)
VALUES
	(1,null),
	(2,'ATP'),
	(3,'+13'),
	(4,'+16'),
	(5,'+18');

CREATE TABLE IF NOT EXISTS ageReview (
	ID tinyint UNSIGNED NOT NULL,
	Name varchar(40),
	CONSTRAINT UC_ageReview UNIQUE (ID,Name),
	PRIMARY KEY (ID)
);
INSERT INTO
	ageReview(ID, Name)
VALUES
	(1, 'Tabaquismo'),
	(2, 'Pornografia'),
	(3, 'Gore'),
	(4, 'Violencia de Fantasia'),
	(5, 'Lenguaje subido de tono'),
	(6, 'Lenguaje violento'),
	(7, 'Drogas');

CREATE TABLE IF NOT EXISTS moderationRoles (
	ID tinyint UNSIGNED NOT NULL,
	Name varchar(20),
	CONSTRAINT MR_ageReview UNIQUE (ID,Name),
	PRIMARY KEY (ID)
);
INSERT INTO
	moderationRoles(ID,Name)
VALUES
	(1,	'none'),
	(2,	'Administrador'),
	(3,	'Moderador');

CREATE TABLE IF NOT EXISTS Suscriptions (
	ID tinyint UNSIGNED NOT NULL,
	Name varchar(20),
	CONSTRAINT SUS_ageReview UNIQUE (ID,Name),
	PRIMARY KEY (ID)
);
INSERT INTO
	Suscriptions(ID, Name)
VALUES
	(1, 'Cat'),
	(2, 'Cattus'),
	(3, 'none');

CREATE TABLE IF NOT EXISTS Users (
	ID int UNSIGNED NOT NULL,
	Name varchar(20) NOT NULL,
	Email varchar(64) NOT NULL,
	Password varchar(128) NOT NULL,
	birthdate datetime NOT NULL,
	activation_date datetime NOT NULL,
	desactivation_date datetime,
	moderationRoles_ID tinyint UNSIGNED NOT NULL,
	suscriptions_ID tinyint UNSIGNED NOT NULL,
	email_validated tinyint UNSIGNED NOT NULL,
	points mediumint NOT NULL,
	CONSTRAINT UC_Users UNIQUE (ID,Name,Email),
	CONSTRAINT FK_UserMod FOREIGN KEY (moderationRoles_ID) REFERENCES moderationRoles(ID),
	CONSTRAINT FK_UserSuscription FOREIGN KEY (suscriptions_ID) REFERENCES Suscriptions(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	Users(ID, Name, Email, Password, birthdate, activation_date, desactivation_date, moderationRoles_ID, suscriptions_ID,
	email_validated, points)
VALUES
	(20000,	'Ivanqpro12', 'Ivan@correo.com', '1loveM@chuPichu',	'26/12/2005', '12/02/2005',	null, 3, 1, true, 400),
	(20001,	'Mahuel', 'Man@correo.com',	'Ow0Uwu@w@E', '26/12/2005',	'12/02/2010', null,	3, 2, true, 200),
	(20002,	'XxNicolasxX', 'Nic@correo.com', 'N1c@4Ever',	'26/12/2005', '12/02/2010',	null, 2, 1,	true, 100),
	(20003,	'Dece',	'Dece@correo.com',	'N@S0yAl3',	'26/12/2005', '12/02/2010',	null, 1, 3,	true, 999),
	(20004,	'MatiasGatorade', 'MaGa@correo.com', 'D0uknwC@nc@rdi@', '26/12/2005', '12/02/2010',	null, 2, 3,	false, 10),
	(20005,	'BlackSamu', 'Night@correo.com', 'Bl@ckL1veM@tters', '26/12/2005', '12/02/2010', null, 1, 3, false,	0);

CREATE TABLE IF NOT EXISTS Manga (
	ID int UNSIGNED NOT NULL,
	title varchar(60) NOT NULL,
	description varchar(1000) NOT NULL,
	uploadDate datetime NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	Ages_ID tinyint UNSIGNED NOT NULL,
	suscriptions_ID tinyint UNSIGNED NOT NULL,
	desactivation_date datetime,
	CONSTRAINT UC_Manga UNIQUE (ID,title,description),
	CONSTRAINT FK_UserID FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_AgeManga FOREIGN KEY (Ages_ID) REFERENCES Ages(ID),
	CONSTRAINT FK_MangaSuscription FOREIGN KEY (suscriptions_ID) REFERENCES Suscriptions(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	Manga(ID, title, description, uploadDate, User_ID, Ages_ID, suscriptions_ID, desactivation_date)
VALUES
	(10000, 'OnePiece', 'El mejor manga', '12/07/2020', 20000, 2, 1, null);

CREATE TABLE IF NOT EXISTS Manga_ageReview (
	Manga_ID int UNSIGNED NOT NULL,
	ageReview_ID tinyint UNSIGNED NOT NULL,
	CONSTRAINT FK_AgeMangaReviewID FOREIGN KEY (Manga_ID) REFERENCES Manga(ID),
	CONSTRAINT FK_AgeMangaReviewID2 FOREIGN KEY (ageReview_ID) REFERENCES ageReview(ID)
);
INSERT INTO
	Manga_ageReview(Manga_ID, ageReview_ID)
VALUES
	(10000, 1),
	(10000, 3),
	(10000, 7);

CREATE TABLE IF NOT EXISTS MangaGenders (
	ID tinyint UNSIGNED NOT NULL,
	Name VARCHAR(20),
	CONSTRAINT UC_MG UNIQUE (ID,Name),
	PRIMARY KEY (ID)
);
INSERT INTO
	MangaGenders(ID, Name)
VALUES
	(100, 'Yuri'),
	(101, 'Romance'),
	(102, 'Accion');

CREATE TABLE IF NOT EXISTS MangaGenders_Manga (
	Manga_ID int UNSIGNED NOT NULL,
	MangaGenders_ID tinyint UNSIGNED NOT NULL,
	CONSTRAINT FK_MangaGendersManga FOREIGN KEY (Manga_ID) REFERENCES Manga(ID),
	CONSTRAINT FK_MangaGendersGender FOREIGN KEY (MangaGenders_ID) REFERENCES MangaGenders(ID)
);
INSERT INTO
	MangaGenders_Manga(Manga_ID, MangaGenders_ID)
VALUES
	(10000,	100),
	(10000,	101),
	(10000, 102);

CREATE TABLE IF NOT EXISTS comments (
	ID int UNSIGNED NOT NULL,
	date datetime NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	Manga_ID int UNSIGNED NOT NULL,
	information varchar(512) NOT NULL,
	deleted_date datetime,
	CONSTRAINT UC_Comments UNIQUE (ID),
	CONSTRAINT FK_UserComment FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_CommentsManga FOREIGN KEY (Manga_ID) REFERENCES Manga(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	comments(ID, date, User_ID, Manga_ID, information, deleted_date)
VALUES
	(10001, 26/12/2011, 20000, 10000, 'Buen manga 10/10',	null),
	(10002, 26/12/2011, 20001, 10000, 'Buen manga 10/10',	null),
	(10003, 26/12/2011, 20002, 10000, 'Buen manga 10/10',	null),
	(10004, 26/12/2011, 20003, 10000, 'Buen manga 10/10',	null),
	(10005, 26/12/2011, 20004, 10000, 'Buen manga 10/10',	null),
	(10007, 26/12/2011, 20005, 10000, 'Buen manga 10/10',	null);

CREATE TABLE IF NOT EXISTS moderationStatus (
	ID tinyint UNSIGNED NOT NULL,
	Name varchar(40),
	show2 boolean NOT NULL,
	CONSTRAINT UC_moderationStatus UNIQUE(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	moderationStatus(ID, Name, show2)
VALUES
	(1, 'No moderado,aprobado', true),
	(2, 'Moderado, aprobado', true),
	(3, 'Moderado, no aprobado', false),
	(4, 'Moderado, retirado',	false),
	(5, 'Moderado, reaprobado', true),
	(6, 'No moderado, esperando accion', true);

CREATE TABLE IF NOT EXISTS userPointHistory (
	ID bigint UNSIGNED NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	Date datetime NOT NULL,
	Action varchar(150),
	AddedBy varchar(150),
	CONSTRAINT UC_UserPointHistory UNIQUE (ID),
	CONSTRAINT FK_UserPointHistory FOREIGN KEY (User_ID) REFERENCES Users(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	userPointHistory(ID, User_ID, Date, action, AddedBy)
VALUES
	(10000, 20000, 12/01/2022, 'Plus 500', 'Leer un capitulo'),
	(10001, 20001, 12/02/2022, 'Plus 99999', 'Lo agrego un admin');

CREATE TABLE IF NOT EXISTS MangaChapters (
	ID int UNSIGNED NOT NULL,
	Manga_ID int UNSIGNED NOT NULL,
	description varchar(512),
	number smallint UNSIGNED NOT NULL,
	uploadDate datetime NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	LastPagesSuscription smallint UNSIGNED NOT NULL,
	LastPagesPrice smallint UNSIGNED NOT NULL,
	allow_purchase boolean NOT NULL,
	desactivation_date datetime,
	CONSTRAINT UC_MangaChaptersUnique UNIQUE (ID),
	CONSTRAINT FK_MangaChaptersManga FOREIGN KEY (Manga_ID) REFERENCES Manga(ID),
	CONSTRAINT FK_MangaChapterUser FOREIGN KEY (User_ID) REFERENCES Users(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	MangaChapters(ID, Manga_ID, description, number, uploadDate, User_ID, LastPagesSuscription, LastPagesPrice,
	allow_purchase, desactivation_date)
VALUES
	(100001, 10000, 'Este es el primer capitulo',	1, 12/07/2020, 20000, 4, 300, true, null),
	(100002, 10000, 'Este es el segundo capitulo', 2, 12/07/2020, 20000, 6, 200, true, null),
	(100003, 10000, 'Este es el tercer capitulo', 3, 12/07/2020, 20000, 5, 1400,	false, null),
	(100004, 10000, 'Este es el cuarto capitulo',	4, 12/07/2020, 20000, null, null, false, null);

CREATE TABLE IF NOT EXISTS moderationLogComment (
	ID int UNSIGNED NOT NULL,
	comments_ID int UNSIGNED NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	date datetime NOT NULL,
	moderationStatus_ID tinyint UNSIGNED NOT NULL,
	information varchar(256),
	CONSTRAINT FK_MLCU FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_MLCMS FOREIGN KEY (moderationStatus_ID) REFERENCES moderationStatus(ID),
	CONSTRAINT FK_MLCC FOREIGN KEY (comments_ID) REFERENCES comments(ID),
	CONSTRAINT UC_MLC UNIQUE(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	moderationLogComment(ID, comments_ID, User_ID, date, moderationStatus_ID, information)
VALUES
	(10000, 10001, 20001, 30/12/2021, 2, "Cumple con las normas");

CREATE TABLE IF NOT EXISTS moderationLogManga (
	ID int UNSIGNED NOT NULL,
	Manga_ID int UNSIGNED NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	date datetime NOT NULL,
	moderationStatus_ID tinyint UNSIGNED NOT NULL,
	information varchar(256),
	CONSTRAINT FK_MLMU FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_MLMMS FOREIGN KEY (moderationStatus_ID) REFERENCES moderationStatus(ID),
	CONSTRAINT FK_MLMM FOREIGN KEY (Manga_ID) REFERENCES Manga(ID),
	CONSTRAINT UC_MLM UNIQUE(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	moderationLogManga(ID, Manga_ID, User_ID, date, moderationStatus_ID, information)
VALUES
	(10000, 10000, 20001, 30/12/2021, 2, "Cumple con las normas");

CREATE TABLE IF NOT EXISTS moderationLogMangaChapters (
	ID int UNSIGNED NOT NULL,
	MangaChapters_ID int UNSIGNED NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	date datetime NOT NULL,
	moderationStatus_ID tinyint UNSIGNED NOT NULL,
	information varchar(256),
	CONSTRAINT FK_MLMCU FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_MLMCMS FOREIGN KEY (moderationStatus_ID) REFERENCES moderationStatus(ID),
	CONSTRAINT FK_MLMCMC FOREIGN KEY (MangaChapters_ID) REFERENCES MangaChapters(ID),
	CONSTRAINT UC_MLMC UNIQUE(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	moderationLogMangaChapters(ID, MangaChapters_ID, User_ID, date, moderationStatus_ID, information)
VALUES
	(10000, 100001, 20001, 30/12/2021, 2, "Cumple con las normas");

CREATE TABLE IF NOT EXISTS moderationLogUsers (
	ID int UNSIGNED NOT NULL,
	Affected_User_ID int UNSIGNED NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	date datetime NOT NULL,
	moderationStatus_ID tinyint UNSIGNED NOT NULL,
	information varchar(256),
	CONSTRAINT FK_MLUU FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_MLUMS FOREIGN KEY (moderationStatus_ID) REFERENCES moderationStatus(ID),
	CONSTRAINT FK_MLUAU FOREIGN KEY (Affected_User_ID) REFERENCES Users(ID),
	CONSTRAINT UC_MLU UNIQUE(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	moderationLogUsers(ID, Affected_User_ID, User_ID, date, moderationStatus_ID, information)
VALUES
	(10000, 20000, 20001, 30/12/2021, 2, "Cumple con las normas");

CREATE TABLE IF NOT EXISTS PermissionsSuscriptions (
	suscriptions_ID tinyint UNSIGNED NOT NULL,
	pointMultiplier float,
	allAccess boolean NOT NULL,
	uploadManga boolean NOT NULL,
	bypassMangaValidation boolean NOT NULL,
	promotedMangas boolean NOT NULL,
	CONSTRAINT UC_PS UNIQUE (suscriptions_ID),
	CONSTRAINT FK_PS FOREIGN KEY (suscriptions_ID) REFERENCES Suscriptions(ID)
);
INSERT INTO
	PermissionsSuscriptions(suscriptions_ID, pointMultiplier, allAccess, uploadManga, bypassMangaValidation, promotedMangas)
VALUES
	(1, 2, true, false, false, false),
	(2, 4, true, true, false, true);

CREATE TABLE IF NOT EXISTS moderationPermissions (
	moderationRoles_ID tinyint UNSIGNED NOT NULL UNIQUE,
	reviewComments boolean NOT NULL,
	editComments boolean NOT NULL,
	reviewMangas boolean NOT NULL,
	editMangas boolean NOT NULL,
	delayActions smallint UNSIGNED,
	reviewUsers boolean NOT NULL,
	editUsers boolean NOT NULL,
	viewModerationLog boolean NOT NULL,
	reviewReports boolean NOT NULL,
	editDatabase boolean NOT NULL,
	editSuscription boolean NOT NULL,
	editModeration boolean NOT NULL,
	modifyShop boolean NOT NULL,
	CONSTRAINT FK_ModPermRol FOREIGN KEY (moderationRoles_ID) REFERENCES moderationRoles(ID)
);
INSERT INTO
	moderationPermissions (moderationRoles_ID, reviewComments, editComments, reviewMangas, editMangas, delayActions, reviewUsers, editUsers,
  viewModerationLog, reviewReports, editDatabase, editSuscription, editModeration, modifyShop)
VALUES 
	(3, true, false, true, false,	60, true, false, true, true, false, false, false, false),
	(2, true, true, true, true, null, true, true, true, true, true, true, true, true),
	(1, false, false, false, false, null, false, false, false, false, false, false, false, false);

CREATE TABLE IF NOT EXISTS MangaLikes (
	User_ID int UNSIGNED NOT NULL,
	Manga_ID int UNSIGNED NOT NULL,
	LikeOrDislike boolean NOT NULL,
	CONSTRAINT FK_LikesUser FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_MangaLike FOREIGN KEY (Manga_ID) REFERENCES Manga(ID)
);
INSERT INTO
	MangaLikes(User_ID, Manga_ID, LikeOrDislike)
VALUES
	(20000, 10000, true),
	(20001, 10000, false);

CREATE TABLE IF NOT EXISTS ItemsShop (
	ID mediumint UNSIGNED NOT NULL,
	Name varchar(64) NOT NULL,
	Description varchar(512),
	Price mediumint UNSIGNED NOT NULL,
	showitem boolean NOT NULL,
	finalDate datetime,
	action varchar(512) NOT NULL,
	CONSTRAINT UC_ItemsShopID UNIQUE (ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	ItemsShop(ID, Name, Description, Price, showitem, finalDate, action)
VALUES
	(10001, 'Suscripcion Catus', 'La mejor suscripcion', 400, true, null, '(Dar suscripcion)'),
	(10002,	'Suscripcion Cat', 'Tiene muchos beneficios', 200, true, null, '(Dar Suscripcion)'),
	(10003,	'Ultimo capitulo de un manga', 'Lo necesitas para ver el final', 800, false, 26/07/2021, '(Dar acceso)');

CREATE TABLE IF NOT EXISTS badges (
	ID smallint UNSIGNED NOT NULL,
	Name varchar(64) NOT NULL,
	description varchar(256),
	isAvaiable boolean NOT NULL,
	isRemoved boolean NOT NULL,
	CONSTRAINT UC_badgesID UNIQUE (ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	badges(ID, Name, description, isAvaiable, isRemoved)
VALUES
	(1, '1000 Puntos', 'El usuario alcanzo la meta de los 1000 puntos', true, false),
	(2, 'Insignia CAT', 'El usuario compro el Cat', true, false),
	(3, 'Insignia CATTUS', 'El usuario compro el Cattus', true, false),
	(4, 'Insignia Moderador', 'El usuario es moderador desde...', true, false),
	(5, 'Insignia Administrador', 'El usuario es administrador desde...', true, false),
	(6, 'Veterano', 'El usuario lleva 1 year en el sitio', true, false),
	(7, 'OnePiece Exclusivo', 'El usuario compro OnePiece cuando se publico', false, false),
	(8, 'Los Nuevos', 'Se registro antes de la meta de 100 usuarios', false, false),
	(9, 'Test', 'Esta es una insignia de prueba', false, true);

CREATE TABLE IF NOT EXISTS UserBadges (
	User_ID int UNSIGNED NOT NULL,
	purchaseDate datetime NOT NULL,
	expirationDate datetime,
	badge_ID smallint UNSIGNED NOT NULL,
	CONSTRAINT FK_BadgeUserId FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_UserBadge FOREIGN KEY (badge_ID) REFERENCES badges(ID)
);

INSERT INTO
	UserBadges(User_ID, purchaseDate, expirationDate, badge_ID)
VALUES
	(20000, 25/12/2021, 25/12/2022, 1),
	(20001, 25/12/2021, null, 9);

CREATE TABLE IF NOT EXISTS userProfile (
	User_ID int UNSIGNED NOT NULL UNIQUE,
	show_Badges boolean NOT NULL,
	Manga_ID int UNSIGNED NOT NULL,
	show_favourite boolean NOT NULL,
	show_birthdate boolean NOT NULL,
	show_points boolean NOT NULL,
	description varchar(128),
	show_interests boolean NOT NULL,
	show_role boolean NOT NULL,
	show_mangaHistory boolean NOT NULL,
	CONSTRAINT FK_UserProfile FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_ProfileManga FOREIGN KEY (Manga_ID) REFERENCES Manga(ID)
);

INSERT INTO
	userProfile(User_ID, show_Badges, Manga_ID, show_favourite, show_birthdate, show_points, description, show_interests,
	show_role, show_mangaHistory)
VALUES
	(20000, true, 10000, false, true, false, 'Me gusta leer mangas', true, true, true),
	(20001, true, 10000, true, false, false, 'Me gusta leer mangas', true, true, false),
	(20002, true, 10000, true, false, false, 'Me gusta leer mangas', true, true, false),
	(20003, true, 10000, false, true, false, 'Me gusta leer mangas', false, true, false),
	(20004, true, 10000, true, true, false, 'Me gusta leer mangas', true, true, false),
	(20005, true, 10000, true, false, false, 'Me gusta leer mangas', true, true, false);

CREATE TABLE IF NOT EXISTS userFavorites (
	User_ID int UNSIGNED NOT NULL,
	Manga_ID int UNSIGNED NOT NULL,
	CONSTRAINT FK_UserFavoriteID FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_UserFavoriteManga FOREIGN KEY (Manga_ID) REFERENCES Manga(ID)
);

INSERT INTO
	userFavorites(User_ID, Manga_ID)
VALUES
	(20000, 10000);

CREATE TABLE IF NOT EXISTS userReadMangaHistory (
	ID bigint UNSIGNED NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	MangaChapters_ID int UNSIGNED NOT NULL,
	lastPage smallint UNSIGNED NOT NULL,
	CONSTRAINT UC_MangaHistoryID UNIQUE (ID),
	CONSTRAINT FK_UserHistoryID FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_UserHistoryMangaChapter FOREIGN KEY (MangaChapters_ID) REFERENCES MangaChapters(ID),
	PRIMARY KEY (ID)
);

INSERT INTO
	userReadMangaHistory(ID, User_ID, MangaChapters_ID, lastPage)
VALUES
	(10000, 20000, 100001, 20),
	(10001, 20001, 100001, 10);

CREATE TABLE IF NOT EXISTS User_MangaGenders (
	User_ID int UNSIGNED NOT NULL,
	MangaGenders_ID tinyint UNSIGNED NOT NULL,
	CONSTRAINT FK_UserGenderManga FOREIGN KEY (User_ID) REFERENCES Users(ID),
    CONSTRAINT FK_UserMangaGendersGender FOREIGN KEY (MangaGenders_ID) REFERENCES MangaGenders(ID)
);
INSERT INTO
	User_MangaGenders(User_ID, MangaGenders_ID)
VALUES
	(20000, 100),
	(20000, 101);

CREATE TABLE IF NOT EXISTS reportOptions (
	ID tinyint UNSIGNED NOT NULL,
	name varchar(64) NOT NULL,
	CONSTRAINT UC_RO UNIQUE(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	reportOptions(ID, name)
VALUES
	(1, "Contenido inapropiado"),
	(2, "Amenazas"),
	(3, "Mensajes de odio u acoso"),
	(4, "Spam"),
	(5, "Menor de edad");

CREATE TABLE IF NOT EXISTS reportType (
	ID tinyint UNSIGNED NOT NULL,
	ExternalType varchar(15) NOT NULL,
	CONSTRAINT UC_RT UNIQUE(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	reportType(ID, ExternalType)
VALUES
	(1, "Manga"),
	(2, "MangaChapters"),
	(3, "Comments"),
	(4, "Users");

CREATE TABLE IF NOT EXISTS reports (
	ID int UNSIGNED NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	reportDate datetime NOT NULL,
	reportsOptions_ID tinyint UNSIGNED NOT NULL,
	reportType_ID tinyint UNSIGNED NOT NULL,
	reportContentID int UNSIGNED NOT NULL,
	information varchar(512),
	CONSTRAINT UC_R UNIQUE(ID),
	CONSTRAINT FK_RRU FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT FK_RRO FOREIGN KEY (reportsOptions_ID) REFERENCES reportOptions(ID),
	CONSTRAINT FK_RRT FOREIGN KEY (reportType_ID) REFERENCES reportType(ID),
	PRIMARY KEY (ID)
);
INSERT INTO
	reports(ID, User_ID, reportDate, reportsOptions_ID, reportType_ID, reportContentID, information)
VALUES
	(10000, 20000, 24/12/2021, 3, 3, 10001, "Este comentario contiene info inapropiada"),
	(10001, 20000, 24/12/2021, 1, 1, 10000, "Este manga contiene info inapropiada");

CREATE TABLE IF NOT EXISTS loginTokens (
	ID varchar(128) NOT NULL,
	expirationTime datetime NOT NULL,
	User_ID int UNSIGNED NOT NULL,
	CONSTRAINT FK_LTU FOREIGN KEY (User_ID) REFERENCES Users(ID),
	CONSTRAINT UC_LT UNIQUE(ID)
);