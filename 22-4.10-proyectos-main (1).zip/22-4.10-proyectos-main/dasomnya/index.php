<?php
    require 'server/error_handler.php';
    header('location:controllers/homepage.php');
?>