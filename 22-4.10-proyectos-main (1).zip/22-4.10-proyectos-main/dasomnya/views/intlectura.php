
<div class="container">
    <h1>Titulo</h1>
    <div class="preintmanga">
        <div class="caratula"><img src="../mangas/watamote/watamotecover.jpg" class="float-start d-block img-thumbnail mangacover" alt="caratula">
            <div class="container">                   
                <aside>
                <h2>Descripción</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec congue venenatis ex sit amet accumsan. Donec laoreet vehicula quam. In non est dolor. Aliquam cursus ligula eget elit pharetra, id aliquet lorem interdum. Nunc et lorem dui. Cras sit amet leo orci. Suspendisse lacinia urna facilisis, fermentum sapien quis, ullamcorper tortor. Aliquam rutrum commodo blandit. Nunc ultricies faucibus accumsan. Vivamus volutpat elementum mauris ut sollicitudin. Donec bibendum bibendum tincidunt. Pellentesque id lorem dignissim massa iaculis pharetra. Ut ultricies lobortis tellus, et condimentum nunc molestie ut. Suspendisse sollicitudin ipsum sit amet volutpat luctus. Etiam ornare nec enim quis malesuada.
                    </p>
                    <p>Añadido en: 14/6/2022</p>
                    <p>Ultima actualizacion: 14/6/2022</p>
                </aside>
            </div>
        </div>
        <div class="container d-inline-flex etiqueta">
            <button type="button" class="btn btn-outline-secondary separado"><a href="#">Etiqueta</a></button>
            <button type="button" class="btn btn-outline-secondary separado"><a href="#">Etiqueta</a></button>
            <button type="button" class="btn btn-outline-secondary separado"><a href="#">Etiqueta</a></button>
            <button type="button" class="btn btn-secondary favbtn"><i class="bi bi-heart"></i></button>
        </div>
        <hr>
        <div>
            <h2>Capitulos (4)</h2>
            <div class="container capitulos">
                <article>Capitulo 4</article>
                <article>Capitulo 3</article>
                <article>Capitulo 2</article>
                <article>Capitulo 1</article>
            </div>
        </div>
    </div>
</div>

