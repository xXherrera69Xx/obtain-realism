
<div class="container fluid">
    <h1>Error 404</h1>
    <h4>Pagina no encontrada</h4>
    <hr>
    <div class="container-fluid">
        <ul>
            <li>La pagina solicitada no existe</li>
            <li>Haga click en el boton para ser redirigido a la pagina principal</li>
        </ul>

        <button id="redirect" class="btn btn-primary">
            Click aqui
        </button>
        <div class="container">
            <img src="../Img/Otros/gato404.png" width="105" alt="Gato cuestionando" />
        </div>

    </div>
</div>

<script>
    document.querySelector('#redirect')
        .addEventListener('click', () => {
            window.location.href = '<?php echo ($GLOBALS["index_root"]) ?>homepage'
        });
</script>
