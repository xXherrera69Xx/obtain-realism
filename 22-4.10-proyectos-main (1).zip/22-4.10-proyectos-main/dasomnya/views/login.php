<link href="../Css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
<link href="../Css/styles.css" rel="stylesheet" crossorigin="anonymous">
<link href="../Css/fonts.css" rel="stylesheet">
<script src="../js/jquery3.6.0.js"></script>
<!--SCRIPTS requeridos para el login-->
<script src="../login_js/messages_client_login.js"></script>
<script src="../login_js/client_login_script.js"></script>
<!--SCRIPTS requeridos para el login-->
<title>Cattus Manga</title>
<link rel="icon" type="image/x-icon" href="../Img/favicon.png">



<div class="container">
    <div id="loginnico">
        <h1>Iniciar sesión</h1>
        <hr>
        <form action="../controllers/login.php" method="POST">
            Ingrese su E-mail
            <input type="email" id="elemail" name="email" class="form-control emails" placeholder="E-mail" value=""><br>
            <div id="email_error" hidden="true" class="errores"></div>
            Ingrese su contraseña
            <input type="password" id="lacontra" name="password" placeholder="Contraseña" class="form-control lascontrasenias"><br>
            <div id="contra_error" hidden="true" class="errores"></div>
            <input type="submit" id="botonenviar" class="btn btn-cust" text="Enviar">
        </form>
        <button onClick="changeMenu(1)" class="btn btn-primary" disabled="disabled">No funciona</button>
    </div>
</div>
