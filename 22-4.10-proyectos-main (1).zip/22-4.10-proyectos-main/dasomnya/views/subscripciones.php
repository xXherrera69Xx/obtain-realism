
<div class="container">
    <div class="row justify-content-evenly">
        <div class="col-6 mb-3 d-flex justify-content-center align-items-stretch">
            <div class="card" style="width: 24rem;">
                <img class="card-img-top" src="../img/Otros/gatonocorona.png" alt="Card image cap">
                <div class="card-body align-items-stretch">
                    <h5 class="card-title  text-center">Cat</h5>
                    <p class="lead  text-center">9USD/mes</p>
                    <div class="container">
                        <ul>
                            <li>Beneficio</li>
                            <li>Beneficio</li>
                            <li>Beneficio</li>
                            <li>Beneficio</li>
                        </ul>
                    </div>
                    <div class="container d-flex align-self-end justify-content-center">
                        <a href="#" class="btn btn-primary">1 Mes</a>
                        <a href="#" class="btn btn-primary">6 Meses</a>
                        <a href="#" class="btn btn-primary">12 Meses</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 mb-3 d-flex justify-content-center align-items-stretch">
            <div class="card" style="width: 24rem;">
                <img class="card-img-top" src="../img/otros/gatocorona.png" alt="Card image cap">
                <div class="card-body align-items-stretch">
                    <h5 class="card-title text-center">Cattus</h5>
                    <p class="lead  text-center">19USD/mes</p>
                    <div class="container">
                        <ul>
                            <li>Beneficio</li>
                            <li>Beneficio</li>
                            <li>Beneficio</li>
                            <li>Beneficio</li>
                        </ul>
                    </div>
                    <div class="container d-flex align-self-end justify-content-center">
                        <a href="#" class="btn btn-primary">1 Mes</a>
                        <a href="#" class="btn btn-primary">6 Meses</a>
                        <a href="#" class="btn btn-primary">12 Meses</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
