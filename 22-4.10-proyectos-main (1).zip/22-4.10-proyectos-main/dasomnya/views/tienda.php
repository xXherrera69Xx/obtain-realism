
<script src="../js/products.js"></script>
<div class="container-fluid">
  <div class="row flex-nowrap">
    <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0">
      <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 min-vh-100">
        <h3>Filtrar</h3>
        <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
          <li class="w-100">
            <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline" onclick="filterproducts('all')">Todo</span></a>
          </li>
          <li class="w-100">
            <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline" onclick="filterproducts('varios')">Varios</span></a>
          </li>
          <li>
            <a href="#" class="nav-link px-0" onclick="filterproducts('userpers')"> <span class="d-none d-sm-inline">Personalizacion de usuario</span></a>
          </li>
        </ul>
        <hr>
      </div>
    </div>
    <div class="col py-3">
      <h1 class="text-center">Tienda de puntos</h1>
      <hr />
      <p class="small text-center">En esta tienda se podra canjear puntos a traves de misiones diarias, en el cual se podra canjear para la personalizacion de tu perfil o canjear mangas en la tienda</p>
      <section class="bg-light pt-5 pb-5 shadow-sm">

        <div class="container">
          <div class="row pt-5">

            <div class="col-12">
            </div>
          </div>
          <div class="row">
            <div class="col-sm-4 mb-3 d-flex align-items-stretch">
              <div class="card box varios" style="width:300px">
                <img src="../pointshop/booba-twitch.gif" class="card-img-top" alt="Card Image">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title">Emote</h5>
                  <p class="card-text mb-4">Varios</p>
                  <a href="#" class="btn btn-primary mt-auto align-self-center">777 Puntos</a>
                </div>
              </div>
            </div>
            <div class="col-sm-4 mb-3 d-flex align-items-stretch">
              <div class="card box userpers" style="width:300px">
                <img src="../pointshop/drag.png" class="card-img-top" alt="Card Image">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title">Foto de perfil</h5>
                  <p class="card-text mb-4">Personalizacion de usuario.</p>
                  <a href="#" class="btn btn-primary mt-auto align-self-center">1000 puntos</a>
                </div>
              </div>
            </div>
            <div class="col-sm-4 mb-3 d-flex align-items-stretch">
              <div class="card userpers" style="width:300px">
                <img src="../pointshop/drag.png" class="card-img-top" alt="Card Image">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title">Foto de perfil</h5>
                  <p class="card-text mb-4">Personalizacion de usuario.</p>
                  <a href="#" class="btn btn-primary mt-auto align-self-center">1000 puntos</a>
                </div>
              </div>
            </div>
            <div class="col-sm-4 mb-3 d-flex align-items-stretch">
              <div class="card userpers" style="width:300px">
                <img src="../pointshop/drag.png" class="card-img-top" alt="Card Image">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title">Foto de perfil</h5>
                  <p class="card-text mb-4">Personalizacion de usuario.</p>
                  <a href="#" class="btn btn-primary mt-auto align-self-center">1000 puntos</a>
                </div>
              </div>
            </div>
            <div class="col-sm-4 mb-3 d-flex align-items-stretch">
              <div class="card userpers" style="width:300px">
                <img src="../pointshop/drag.png" class="card-img-top" alt="Card Image">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title">Foto de perfil</h5>
                  <p class="card-text mb-4">Personalizacion de usuario.</p>
                  <a href="#" class="btn btn-primary mt-auto align-self-center">1000 puntos</a>
                </div>
              </div>
            </div>
            <div class="col-sm-4 mb-3 d-flex align-items-stretch">
              <div class="card userpers" style="width:300px">
                <img src="../pointshop/drag.png" class="card-img-top" alt="Card Image">
                <div class="card-body d-flex flex-column">
                  <h5 class="card-title">Foto de perfil</h5>
                  <p class="card-text mb-4">Personalizacion de usuario.</p>
                  <a href="#" class="btn btn-primary mt-auto align-self-center">1000 puntos</a>
                </div>
              </div>
            </div>
          </div>
      </section>
    </div>
  </div>
</div>
