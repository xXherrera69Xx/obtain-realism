
<!--SCRIPTS requeridos para el login-->
<script src="../login_js/messages_client_login.js"></script>
<script src="../login_js/client_login_script.js"></script>
<!--SCRIPTS requeridos para el login-->
<!--SCRIPTS requeridos para el registro-->
<script src="../login_js/client_register_script.js"></script>
<!--SCRIPTS requeridos para el registro-->
<div class="container">
  <div id="registernico">
    <h1>Crea tu usuario</h1>
    <hr>
    <form action="../server/login/authentification.php" method="post">
      Ingrese su E-mail
      <input type="email" id="elemail" name="email" class="form-control emails" value="" placeholder="E-mail">
      <div id="email_error" hidden="true" class="errores"></div>
      Cree un nombre de usuario
      <input type="text" id="elusuario" name="username" class="form-control" value="" placeholder="Nombre de Usuario"><br>
      <div id="username_error" hidden="true" class="errores"></div>
      Ingrese su fecha de nacimiento <input type="date" class="form-control" name="birthdate" id="birthdate">
      <div id="birthdate_error" hidden="true" class="errores"></div>
      Cree una contraseña
      <input type="password" class="form-control lascontrasenias" name="password" placeholder="Contraseña" id="lacontra"><br>
      <div id="contra_error" hidden="true" class="errores"></div>
      <div id="contra_valido" hidden="true">La contrasenia ingresada es correcta</div>
      Repita la contraseña
      <input type="password" class="form-control lascontrasenias" name="password2" placeholder="Repita la contraseña" id="lacontra_validation">
      <div id="contra_error2" hidden="true" class="errores"></div>
      <div id="contra_valido2" hidden="true">La contrasenia ingresada coincide con la anterior</div>
      <input type="submit" id="botonenviar" class="btn btn-cust" text="Enviar">
    </form>
    <button onClick="location.href='login.php'">Login</button>
  </div>
</div>