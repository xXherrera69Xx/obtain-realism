
<div class="container">
    <div class="mangaint">
    <a href="#"><i class="bi bi-arrow-left-square-fill"></i></a>
    Pagina 1 de 12
    <a href="#"><i class="bi bi-arrow-right-square-fill"></i></a>   <a href="#"><i class="bi bi-gear"></i></a>  
        <div class="d-flex justify-content-center mangapdf">
            <embed type="application/pdf" src="mangas/watamote/WM 01-09.pdf" width="500" height="650"></embed>
        </div>
        <a href="#"><i class="bi bi-arrow-left-square-fill"></i></a>    
    Pagina 1 de 12
    <a href="#"><i class="bi bi-arrow-right-square-fill"></i></a>   
    </div>
    <div class="container-fluid anuncio">
        <b>Anuncio</b>
    </div>
    <div class="container-fluid comentariossection">
        <h6>Comentarios</h6>
        <input type="text" id="comment-box" placeholder="Añadir un comentario">
        <button id="comentario">Enviar</button>
        <ul id="unordered">
        </ul>
    </div>
</div>
<script>
    var comentario = document.getElementById("comentario");
    comentario.addEventListener("click", function() {
        var commentBoxValue = document.getElementById("comment-box").value;
        var li = document.createElement("li");
        var text = document.createTextNode(commentBoxValue);
        li.appendChild(text);
        document.getElementById("unordered").appendChild(li);
    });
</script>
