
<div class="container">
    <div class="container">
        <img src="../img/Otros/gatogodsupport.png" class="float-end" alt="gato te soportea">
        <p>Espacio de ayuda y soporte</p>
        <div class="container">
            <ul>
                <li>Contacto: +54 15 4373-43783</li>
                <li>Sede: Sudafrica, Boychuay 1450</li>
                <li>Correo: <a href="#">cattusmangagod@cattus.com</a></li>
            </ul>
        </div>
    </div>
</div>
