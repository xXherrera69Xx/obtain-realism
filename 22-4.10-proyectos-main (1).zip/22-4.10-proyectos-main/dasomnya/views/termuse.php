
<div class="container">
    <img src="../img/Otros/Banner.png" class="mx-auto d-block" alt="banner">
    <div class="container cajadeterminos">
        <ol>
            LA INFORMACIÓN QUE USTED PROPORCIONA Podemos recolectar las siguientes categorías de información de identificación personal ("Datos personales") que usted nos brinda cuando utiliza los Contenidos:
            <li> Datos de identificación: esta información nos permite diferenciarlo de otras personas y puede incluir el nombre y el apellido, la fecha de nacimiento, el género, el domicilio postal y la contraseña. </li>
            <li> Información de contacto: esta información nos permite mantenernos en contacto con usted y puede incluir la dirección de correo electrónico y el número telefónico.Registros electrónicos: esta información comprende algunos datos de usted o de su dispositivo que se obtienen cuando accede a nuestros Contenidos.</li>
            <li> Contenidos generados por usuarios: también podemos recoger información que usted nos brinda a través de nuestros Contenidos, como fotografías, imágenes de video u otros contenidos que usted categorias
            <li>Información sobre uso: nosotros y nuestros socios y proveedores de servicios externos, como Google Analytics o Adobe Analytics, podemos utilizar diversas tecnologías que recogen y brindan información acerca de cómo se accede a los Contenidos y cómo se utilizan. La información sobre uso puede consistir en su tipo y versión de navegador de Internet, su sistema operativo, su proveedor de servicios, las páginas web y las aplicaciones que visitó, el horario en que las visitó y durante cuánto tiempo permaneció, el historial de juegos y el nivel de habilidades, su información demográfica (como la edad. género, idioma, ubicación y áreas de interés, cuando se encuentren disponibles), su ubicación, zona horaria, idioma y qué páginas web vio antes de visualizar la página actual.</li>
        </ol>
    </div>
</div>
