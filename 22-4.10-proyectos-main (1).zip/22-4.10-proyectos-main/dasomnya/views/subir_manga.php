<div class="container">
    <div id="subirmanga">
        <h1>Subi tu manga</h1>
        <hr>
        <form action="../controllers/subir_manga.php" method="POST">
            Ingrese el título del manga
            <input type="text" name="title" class="form-control" value="" placeholder="Título" required> <br>

            Ingrese la sinopsis del manga
            <input type="text" name="description" class="form-control" value="" placeholder="Sinopsis" required><br>

            Elija las categorias del manga
            <label class="form__container--text"></label>
            <select name="categories" class="form-control form__container--input">

                <option value="Ejemplo1">Ejemplo1</option>
                <option value="Ejemplo2">Ejemplo2</option>

            </select>
            <br>

            Ingrese los archivos del manga
            <input type="file" class="form-control" name="files" placeholder="Archivos" required><br>

            <input type="submit" id="enviar" class="btn btn-cust" text="Enviar">
        </form>
    </div>
</div>