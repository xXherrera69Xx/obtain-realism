
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/slider.css"> 


  <div class="titlesection">Resultados para <strong>"<?php echo $_GET['text']; ?>"</strong></div>
  <div class="space-list" id="space-list">

</div>
  <script type="text/javascript">

    var text="<?php echo $_GET['text']; ?>"
    $(document).ready(function() {
      $.ajax({
        url: '../controllers/get_all_mangas.php',
        type: 'POST',
        data: {
          text:text
        },
        success:function(data) {
          console.log(data);
          let html ='';
          for(var i=0; i<data.datos.length; i++) {
            html+=
            '<div class="mangasearch">'+
                '<div class="card-image">'+
                  '<img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">'+
                  '<div class="cosa">'+
                    '<div class="textManga">'+ data.datos[i].nombre + '</div>'+ '</div>'+'</div>'+'</div>';
          }
          document.getElementById("space-list").innerHTML=html;
        },
        error:function(err){
          console.log(err);
        }
      });
    });
  </script>
