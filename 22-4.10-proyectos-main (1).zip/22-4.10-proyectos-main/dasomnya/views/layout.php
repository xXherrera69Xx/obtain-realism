<html lang="es">

<head>

   <link href="../Css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
    <link href="../Css/styles.css" rel="stylesheet" crossorigin="anonymous">
    <link href="../Css/fonts.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/swiper-bundle.min.css">
    <link rel="stylesheet" href="../css/slider.css">

    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery3.6.0.js"></script>
    <link rel="icon" type="image/x-icon" href="../Img/favicon.png">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="../js/swiper-bundle.min.js"></script>
    <script src="../js/test.js"></script>
    <script src="../js/slider.js"></script>
    <title>Cattus Manga</title>

</head>

<body>
    <?php require_once('../includes/menu.php'); 
    require '../includes/footer.php';
    ?>

    <div class="container ">
        <!-- Empieza el contenido especifico -->
        <?php require_once($view . ".php") ?>
        <!-- Termina el contenido especifico -->
    </div>
</body>



</html>