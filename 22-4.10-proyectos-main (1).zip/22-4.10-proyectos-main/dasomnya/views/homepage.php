 
  <meta name="viewport" content="width=device-width, initial-scale=1">


  <!--image slider start-->
  
  <div class="container-fluid">
    <div class="pagewebcattus">
      <div class="slider">
        <div class="slides">
          <!--radio buttons start-->
          <input type="radio" name="radio-btn" id="radio1">
          <input type="radio" name="radio-btn" id="radio2">
          <input type="radio" name="radio-btn" id="radio3">
          <input type="radio" name="radio-btn" id="radio4">
          <!--radio buttons end-->

          <!--slide images start-->
          <div class="slide first">
            <img src="../Img/Otros/baki-banner-test.jpg" alt="">
          </div>
          <div class="slide">
            <img src="../Img/Otros/yuruYuri-banner-test.jpg" alt="">
          </div>
          <div class="slide">
            <img src="../Img/Otros/watamote-banner.jpg" alt="">
          </div>
          <div class="slide">
            <img src="../Img/Otros/naruto-banner-test.jpg" alt="">
          </div>
          <!--slide images end-->
        </div>

        <!--manual navigation start-->
        <div class="navigation-manual">
          <label for="radio1" class="manual-btn"></label>
          <label for="radio2" class="manual-btn"></label>
          <label for="radio3" class="manual-btn"></label>
          <label for="radio4" class="manual-btn"></label>
        </div>
        <!--manual navigation end-->
      </div>
      <!--image slider end-->
      <script src="../js/slider.js"></script>
    </div>
    <link rel="stylesheet" href="../css/swiper-bundle.min.css">
    <link rel="stylesheet" href="../css/test.css">
    <h2 class="text-center"> Mejores mangas del momento </h2>
    
    
    <div class="container">
      <div class="slide-container swiper">
        <div class="slide-content">
          <div class="card-wrapper swiper-wrapper">
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-1.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
    <script src="../js/swiper-bundle.min.js"></script>
    <script src="../js/test.js"></script>
    <h2 class="text-center"> Algo supongo </h2>
    <div class="container">
      <div class="slide-container swiper">
        <div class="slide-content">
          <div class="card-wrapper swiper-wrapper">
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-1.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="../Img/Manga-Ejemplo-2.jpg" alt="" class="card-img">
                  <div class="cosa">
                    <div class="textManga">Hello World</div>
                  </div>
                  <h3>Naruto</h3>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </div>
