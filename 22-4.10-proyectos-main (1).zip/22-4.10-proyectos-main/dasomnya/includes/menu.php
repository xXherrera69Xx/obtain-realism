<?php
//session_start();
//$estadoSesion = session_status();
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<div class="container">
    <nav class="navbar navbar-expand-sm nav-custom navbar-light fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="homepage.php">
                    <img src="../Img/cattusmangalogo.png" width="105" height="65" class="d-inline-block align-top">
                </a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggleNavbar" aria-controls="toggleNavbar" aria-expanded="false">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="toggleNavbar">
                <ul class="navbar-nav text-center">
                    <li class="nav-item active"><a class="nav-link" style="color: #dde6ed" href="../controllers/categorias.php">Categorias</a></li>
                    <li class="nav-item"> <a class="nav-link" style="color: #dde6ed" href="../controllers/tienda.php">Tienda</a> </li>
                    <li class="nav-item"> <a class="nav-link" style="color: #dde6ed" href="../controllers/subscripciones.php">Subscripciones</a> </li>
                </ul>
                <div class="searchplace">
                    <input class="form-control me-2" type="text" name="text" placeholder="Buscar" id="idbusqueda" value="<?php if (isset($_GET['text'])) {
                                                                                                                                echo $_GET['text'];
                                                                                                                            } else {
                                                                                                                                echo '';
                                                                                                                            } ?>">
                    <button class="btn btn-primary" onclick="search_manga()">Ir</button>
                </div>
                <?php
                if (isset($_SESSION['user_id'])) { ?>
                    <ul class="nav nav-pills nav-justify-center">
                        <li class="nav-item dropdown">
                            <a class="nav-link actiev dropdown-toggle" data-bs-toggle="dropdown" href="#">
                                <i class="bi bi-person-circle" style="color:aliceblue; font-size: 150%;">Bienvenido </i></a>
                        </li>
                    </ul>
                <?php } else { ?>
                    <ul class="nav nav-pills nav-justify-center">
                        <li class="nav-item dropdown">
                            <a class="nav-link actiev dropdown-toggle" data-bs-toggle="dropdown" href="#">
                                <i class="bi bi-person-circle" style="color:aliceblue; font-size: 150%;"></i></a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../controllers/login.php">Iniciar sesion</a></li>
                                <li><a class="dropdown-item" href="../controllers/register.php">Crear tu cuenta</a></li>
                            </ul>
                        </li>
                    </ul>
                <?php }
                ?>

            </div>
        </div>
    </nav>
    <nav class="navbar navbar-default ">
    </nav>
    <nav class="navbar  navbar-default navbar-fixed-top ">
        <div class="container-fluid">
        </div>
    </nav>
</div>
<script src="../js/buscador.js"></script>