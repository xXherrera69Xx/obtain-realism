<div class="container-fluid footer">
  <ul class="navbar navbar-expand-sm justify-content-center">
    <li class="nav-item">
      <a class="nav-link" href="#">Dasomnya&trade;</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="../controllers/contacto.php">Contacto y Soporte</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="../controllers/termuse.php">Terminos y condiciones</a>
    </li>
  </ul>
</div>