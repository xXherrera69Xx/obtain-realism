-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-07-2022 a las 06:56:47
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `moondev`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bonificaciones`
--

CREATE TABLE `bonificaciones` (
  `id` int(10) UNSIGNED NOT NULL,
  `bonificacion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `objeto_id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `precio_de_venta` int(10) UNSIGNED NOT NULL,
  `cantidad` int(10) UNSIGNED NOT NULL,
  `publicar_en_el_mercado` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `misiones`
--

CREATE TABLE `misiones` (
  `id_mis` int(10) UNSIGNED NOT NULL,
  `titulo_mis` varchar(40) NOT NULL,
  `descripcion_mis` text NOT NULL,
  `mis_rutaimg` varchar(70) NOT NULL,
  `oro_mis` smallint(6) NOT NULL,
  `winrate_mis` int(10) UNSIGNED NOT NULL,
  `droprate_mis` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `misiones`
--

INSERT INTO `misiones` (`id_mis`, `titulo_mis`, `descripcion_mis`, `mis_rutaimg`, `oro_mis`, `winrate_mis`, `droprate_mis`) VALUES
(1, 'Caballero Blanco', 'Detonar al caballero blanco', 'mision_1.jpg', 122, 12, 22),
(16, 'Kraken devorador de Icebergs', 'Asesinar al Kraken demoledor de icebergs lleva tiempo, por eso recomendamos ir con un reloj', '20220705063535.jpg', 23, 10, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `objetos`
--

CREATE TABLE `objetos` (
  `id_obj` int(10) UNSIGNED NOT NULL,
  `precio` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `rareza_id` int(10) UNSIGNED NOT NULL,
  `ruta_img` varchar(70) NOT NULL,
  `se_vende` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `objetos`
--

INSERT INTO `objetos` (`id_obj`, `precio`, `nombre`, `descripcion`, `rareza_id`, `ruta_img`, `se_vende`) VALUES
(1, 2000, 'DragonSlayer', 'Esta espada de 2 metros pertenecio a un guerrero capaz de cualquier cosa y con una determinacion aterradora', 4, '20220705061454.jpg', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `objetos_equipados`
--

CREATE TABLE `objetos_equipados` (
  `id` int(10) UNSIGNED NOT NULL,
  `objeto_id` int(10) UNSIGNED NOT NULL,
  `personaje` enum('1','2','3','4') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `objeto_bonificacion`
--

CREATE TABLE `objeto_bonificacion` (
  `id` int(10) UNSIGNED NOT NULL,
  `objeto_id` int(10) UNSIGNED NOT NULL,
  `valor_bonificacion_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personaje`
--

CREATE TABLE `personaje` (
  `id` int(10) UNSIGNED NOT NULL,
  `skin` enum('1','2','3','4') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rarezas`
--

CREATE TABLE `rarezas` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usu` int(10) UNSIGNED NOT NULL,
  `mail_usu` varchar(100) NOT NULL,
  `clave_usu` varchar(20) NOT NULL,
  `personaje_id` int(10) UNSIGNED NOT NULL,
  `usuario_usu` varchar(20) NOT NULL,
  `monedas_usu` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usu`, `mail_usu`, `clave_usu`, `personaje_id`, `usuario_usu`, `monedas_usu`) VALUES
(1, 'test2@gmail.com', 'asdfmovie2', 1, 'gonzatroll', 123455),
(2, 'charkotest@gmail.com', 'charkolon', 1, 'Charkousuario', 99992),
(3, 'test34@gmail.com', 'faculongo', 1, 'facudrip', 14534);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valores bonificaciones`
--

CREATE TABLE `valores bonificaciones` (
  `id` int(10) UNSIGNED NOT NULL,
  `bonificacion_id` int(10) UNSIGNED NOT NULL,
  `valor` enum('10','20','30','40','50','60','70','80','90','100') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bonificaciones`
--
ALTER TABLE `bonificaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `misiones`
--
ALTER TABLE `misiones`
  ADD PRIMARY KEY (`id_mis`);

--
-- Indices de la tabla `objetos`
--
ALTER TABLE `objetos`
  ADD PRIMARY KEY (`id_obj`);

--
-- Indices de la tabla `objetos_equipados`
--
ALTER TABLE `objetos_equipados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `objeto_bonificacion`
--
ALTER TABLE `objeto_bonificacion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `personaje`
--
ALTER TABLE `personaje`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rarezas`
--
ALTER TABLE `rarezas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usu`);

--
-- Indices de la tabla `valores bonificaciones`
--
ALTER TABLE `valores bonificaciones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bonificaciones`
--
ALTER TABLE `bonificaciones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `misiones`
--
ALTER TABLE `misiones`
  MODIFY `id_mis` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `objetos`
--
ALTER TABLE `objetos`
  MODIFY `id_obj` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `objetos_equipados`
--
ALTER TABLE `objetos_equipados`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `objeto_bonificacion`
--
ALTER TABLE `objeto_bonificacion`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `personaje`
--
ALTER TABLE `personaje`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `rarezas`
--
ALTER TABLE `rarezas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usu` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `valores bonificaciones`
--
ALTER TABLE `valores bonificaciones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;