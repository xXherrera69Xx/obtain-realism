<?php
//require_once 'api/error_handler.php';
$GLOBALS["index_root"] = "index.php?seccion=";
//echo($test);
if (isset($_GET['seccion']) == (false || null || "")) {
    header("LOCATION:" . $GLOBALS["index_root"] . "index");
};
$get = $_GET['seccion'];

$auth_pages = ["login", "register"];
$admin_pages = ["admin", "main", "misionesadm", "objetos", "usuariosadm"];

if (in_array($get, $auth_pages)) { $layout = "layout_auth"; $folder = "auth"; }
else if (in_array($get, $admin_pages)) { $layout = "layout_admin"; $folder = "gestion-pagina"; }
else { $layout = "layout"; $folder = "normal"; }

$filename = file_exists("views/" . $folder . "/" . $get . ".php");

if ($filename === true) { $section = ($get . ".php");
} else { $folder = "failed"; $section = '404.php'; };

$fileinfo = "controllers/" . $folder . "/" . $get . "/";

require_once ("views/" . $layout . ".php");
