function loadAjax(isRegister) {
    $( document ).ready(function() {
        let information = new FormData;
        function store(variable) {
            information.append(variable, document.getElementById(variable).value);
        }
        if (isRegister === true ) {
            information.append("auth_method", "true");
            store("username");
            store("password2");
            //store("birthdate");
        } else {
            information.append("auth_method", "false");
        }
        store("email");
        store("password");
        const xhttp = new XMLHttpRequest
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4  && this.status == 200) {
                console.log(this.responseText);
                let response = JSON.parse(this.responseText);
                response_received(response);
            }
        }
        xhttp.open("POST", "api/authentification.php", true);
        xhttp.send(information);
    });
}