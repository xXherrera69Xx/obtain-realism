function response_received(response) {
    $( document ).ready(function() {
    if (response.http_code !== 200) {
        function file() {
            if (typeof window.jsonresult === 'undefined') {
                $.getJSON("controllers/auth/auth_messages.json", function(jsonresult) {
                    window.jsonresult = jsonresult;
                    message();
                });
            }
            else { message(); }
        }
        function message() {
            var message = response.message;
            var access_message = message.split(".");
            var access_lenght = access_message.length;
            switch (access_lenght) {
                case 2:
                    message_output = window.jsonresult[access_message[0]][access_message[1]];
                    break;
                case 3:
                    message_output = window.jsonresult[access_message[0]][access_message[1]][access_message[2]];
                    break;
                default:
                    message_output = "ERROR: No se puede imprimir el mensaje";
                    break;
            }
            console.log(message_output);
            printer(access_message[0], message_output);
        }
        function printer(am, mo) {
            document.getElementById(am).innerHTML = mo;
        }
        file();
    }
    else {
        location.href='index.php?seccion=index';
    }
    //response = null;
    //response = {"http_code": 199, "message": "ple.missing.lowercase" };
    //response_received(response);
    });
}