function show_modal(id) {
    document.getElementById(id).style.display = "block";
}

function hide_modal(id) {
    document.getElementById(id).style.display = "none";
}

function save_object() {
    let fd = new FormData();
    fd.append('codigo', document.getElementById('codigo').value);
    fd.append('nombre', document.getElementById('nombre').value);
    fd.append('descripcion', document.getElementById('descripcion').value);
    fd.append('precio', document.getElementById('precio').value);
    fd.append('rareza', document.getElementById('rareza').value);
    fd.append('imagen', document.getElementById('imagen').files[0]);
    fd.append('enventa', document.getElementById('enventa').value);
    let request = new XMLHttpRequest();
    request.open('POST', 'api/save_object.php', true);
    request.onload = function() {
        if (request.readyState == 4 && request.status == 200) {
            let response = JSON.parse(request.responseText);
            console.log(response);
            if (response.state) {
                alert("Objeto subido");
                window.location.reload();
            } else {
                alert(response.detail);
            }
        }
    }
    request.send(fd);
}

function delete_object(id_obj) {
    var c = confirm("Estas seguro de eliminar el objeto? (Este cambio es irreversible)")
    if (c) {
        let fd = new FormData();
        fd.append('id_obj', id_obj);
        let request = new XMLHttpRequest();
        request.open('POST', 'api/delete_object.php', true);
        request.onload = function() {
            if (request.readyState == 4 && request.status == 200) {
                let response = JSON.parse(request.responseText);
                console.log(response);
                if (response.state) {
                    alert("Objeto eliminado");
                    window.location.reload();
                } else {
                    alert(response.detail);
                }
            }
        }
        request.send(fd);
    } else {
        return;
    }
}

function edit_object(id_obj) {

    {
        let fd = new FormData();
        fd.append('id_obj', id_obj);
        let request = new XMLHttpRequest();
        request.open('POST', 'api/get_object.php', true);
        request.onload = function() {
            if (request.readyState == 4 && request.status == 200) {
                let response = JSON.parse(request.responseText);
                console.log(response);
                document.getElementById("codigo-e").value=id_obj;
                document.getElementById("nombre-e").value=response.products.nombre;
                document.getElementById("descripcion-e").value=response.products.descripcion;
                document.getElementById("precio-e").value=response.products.precio;
                document.getElementById("rareza-e").value=response.products.rareza_id;
                document.getElementById("rutimgobj").src="../img/"+response.products.ruta_img;
                document.getElementById("enventa-e").value=response.products.se_vende;
                document.getElementById("rutimgobj-aux").value=response.products.ruta_img;
                show_modal("modal-object-edit");   
            }
        }
        request.send(fd);
    }
}

function update_object() {
    let fd = new FormData();
    fd.append('codigo', document.getElementById('codigo-e').value);
    fd.append('nombre', document.getElementById('nombre-e').value);
    fd.append('descripcion', document.getElementById('descripcion-e').value);
    fd.append('precio', document.getElementById('precio-e').value);
    fd.append('rareza', document.getElementById('rareza-e').value);
    fd.append('imagen', document.getElementById('imagen-e').files[0]);
    fd.append('rutimgobj',document.getElementById("rutimgobj-aux").value);
    fd.append('enventa', document.getElementById('enventa-e').value);
    let request = new XMLHttpRequest();
    request.open('POST', 'api/object_update.php', true);
    request.onload = function() {
        if (request.readyState == 4 && request.status == 200) {
            let response = JSON.parse(request.responseText);
            console.log(response);
            if (response.state) {
                alert("Objeto actualizado");
                window.location.reload();
            } else {
                alert(response.detail);
            }
        }
    }
    request.send(fd);
}