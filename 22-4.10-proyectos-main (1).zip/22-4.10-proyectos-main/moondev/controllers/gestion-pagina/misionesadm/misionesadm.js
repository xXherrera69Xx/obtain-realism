function show_modal(id) {
    document.getElementById(id).style.display = "block";
}

function hide_modal(id) {
    document.getElementById(id).style.display = "none";
}

function save_mis() {
    let fd = new FormData();
    fd.append('id_mis', document.getElementById('id_mis').value);
    fd.append('titulo_mis', document.getElementById('titulo_mis').value);
    fd.append('descripcion_mis', document.getElementById('descripcion_mis').value);
    fd.append('oro_mis', document.getElementById('oro_mis').value);
    fd.append('winrate_mis', document.getElementById('winrate_mis').value);
    fd.append('mis_rutaimg', document.getElementById('mis_rutaimg').files[0]);
    fd.append('droprate_mis', document.getElementById('droprate_mis').value);
    let request = new XMLHttpRequest();
    request.open('POST', 'api/save_mis.php', true);
    request.onload = function() {
        if (request.readyState == 4 && request.status == 200) {
            let response = JSON.parse(request.responseText);
            console.log(response);
            if (response.state) {
                alert("Mision creada");
                window.location.reload();
            } else {
                alert(response.detail);
            }
        }
    }
    request.send(fd);
}

function delete_mis(id_mis) {
    var c = confirm("Estas seguro de eliminar esta mision? (Este cambio es irreversible)")
    if (c) {
        let fd = new FormData();
        fd.append('id_mis', id_mis);
        let request = new XMLHttpRequest();
        request.open('POST', 'api/delete_mis.php', true);
        request.onload = function() {
            if (request.readyState == 4 && request.status == 200) {
                let response = JSON.parse(request.responseText);
                console.log(response);
                if (response.state) {
                    alert("Mision eliminada");
                    window.location.reload();
                } else {
                    alert(response.detail);
                }
            }
        }
        request.send(fd);
    } else {
        return;
    }
}

function edit_mis(id_mis) {
    {
        let fd = new FormData();
        fd.append('id_mis', id_mis);
        let request = new XMLHttpRequest();
        request.open('POST', 'api/get_mis.php', true);
        request.onload = function() {
            if (request.readyState == 4 && request.status == 200) {
                let response = JSON.parse(request.responseText);
                console.log(response);
                document.getElementById("id_mis-e").value=id_mis;
                document.getElementById("titulo_mis-e").value=response.missions.titulo_mis;
                document.getElementById("descripcion_mis-e").value=response.missions.descripcion_mis;
                document.getElementById("oro_mis-e").value=response.missions.oro_mis;
                document.getElementById("droprate_mis-e").value=response.missions.droprate_mis;
                document.getElementById("rutimgmis").src="../img/"+response.missions.mis_rutaimg;
                document.getElementById("winrate_mis-e").value=response.missions.winrate_mis;
                document.getElementById("rutimgmis-aux").value=response.missions.mis_rutaimg;
                show_modal("modal-object-edit");
            }
        }
        request.send(fd);
    }
}

function update_mis() {
    let fd = new FormData();
    fd.append('id_mis', document.getElementById('id_mis-e').value);
    fd.append('titulo_mis', document.getElementById('titulo_mis-e').value);
    fd.append('descripcion_mis', document.getElementById('descripcion_mis-e').value);
    fd.append('oro_mis', document.getElementById('oro_mis-e').value);
    fd.append('winrate_mis', document.getElementById('winrate_mis-e').value);
    fd.append('rutimgmis', document.getElementById('rutimgmis-aux').value);
    fd.append('droprate_mis', document.getElementById('droprate_mis-e').value);
    fd.append('mis_rutaimg', document.getElementById('mis_rutaimg-e').files[0]);
    let request = new XMLHttpRequest();
    request.open('POST', 'api/update_mis.php', true);
    request.onload = function() {
        if (request.readyState == 4 && request.status == 200) {
            let response = JSON.parse(request.responseText);
            console.log(response);
            if (response.state) {
                alert("Mision actualizada");
                window.location.reload();
            } else {
                alert(response.detail);
            }
        }
    }
    request.send(fd);
}