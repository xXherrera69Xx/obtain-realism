function show_modal(id) {
    document.getElementById(id).style.display = "block";
}

function hide_modal(id) {
    document.getElementById(id).style.display = "none";
}

function save_object() {
    let fd = new FormData();
    fd.append('codigo', document.getElementById('codigo').value);
    fd.append('nombre', document.getElementById('nombre').value);
    fd.append('descripcion', document.getElementById('descripcion').value);
    fd.append('precio', document.getElementById('precio').value);
    fd.append('rareza', document.getElementById('rareza').value);
    fd.append('imagen', document.getElementById('imagen').files[0]);
    fd.append('enventa', document.getElementById('enventa').value);
    let request = new XMLHttpRequest();
    request.open('POST', 'api/save_object.php', true);
    request.onload = function() {
        if (request.readyState == 4 && request.status == 200) {
            let response = JSON.parse(request.responseText);
            console.log(response);
            if (response.state) {
                alert("Objeto subido");
                window.location.reload();
            } else {
                alert(response.detail);
            }
        }
    }
    request.send(fd);
}

function delete_usu(id_usu) {
    var c = confirm("Estas seguro de eliminar este usuario? (Este cambio es irreversible)")
    if (c) {
        let fd = new FormData();
        fd.append('id_usu', id_usu);
        let request = new XMLHttpRequest();
        request.open('POST', 'api/delete_usu.php', true);
        request.onload = function() {
            if (request.readyState == 4 && request.status == 200) {
                let response = JSON.parse(request.responseText);
                console.log(response);
                if (response.state) {
                    alert("Usuario eliminado");
                    window.location.reload();
                } else {
                    alert(response.detail);
                }
            }
        }
        request.send(fd);
    } else {
        return;
    }
}

function edit_usu(id_usu) {
    {
        let fd = new FormData();
        fd.append('id_usu', id_usu);
        let request = new XMLHttpRequest();
        request.open('POST', 'api/get_usu.php', true);
        request.onload = function() {
            if (request.readyState == 4 && request.status == 200) {
                let response = JSON.parse(request.responseText);
                console.log(response);
                document.getElementById("id_usu-e").value=id_usu;
                document.getElementById("usuario_usu-e").value=response.users.usuario_usu;
                document.getElementById("mail_usu-e").value=response.users.mail_usu;
                document.getElementById("clave_usu-e").value=response.users.clave_usu;
                document.getElementById("monedas_usu-e").value=response.users.monedas_usu;
                document.getElementById("personaje_id-e").value=response.users.personaje_id;
                show_modal("modal-object-edit");   
            }
        }
        request.send(fd);
    }
}

function update_usu() {
    let fd = new FormData();
    fd.append('id_usu', document.getElementById('id_usu-e').value);
    fd.append('usuario_usu', document.getElementById('usuario_usu-e').value);
    fd.append('mail_usu', document.getElementById('mail_usu-e').value);
    fd.append('clave_usu', document.getElementById('clave_usu-e').value);
    fd.append('monedas_usu', document.getElementById('monedas_usu-e').value);
    fd.append('personaje_id',document.getElementById("personaje_id-e").value);
    let request = new XMLHttpRequest();
    request.open('POST', 'api/usu_update.php', true);
    request.onload = function() {
        if (request.readyState == 4 && request.status == 200) {
            let response = JSON.parse(request.responseText);
            console.log(response);
            if (response.state) {
                alert("Usuario actualizado");
                window.location.reload();
            } else {
                alert(response.detail);
            }
        }
    }
    request.send(fd);
}