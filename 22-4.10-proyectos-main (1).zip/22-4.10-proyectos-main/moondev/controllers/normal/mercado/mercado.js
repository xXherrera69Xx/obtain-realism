$(document).ready(function() {
    $.ajax({
        url:'apipag/get_objects_pag.php',
        type:'POST',
        data: {},
        success:function(data){
            console.log(data);
            let html='';
            for(var i=0;i<data.datos.length;i++){
            html+=
                '<div class="product-box">'+
                 '<a href="">'+
                '<div class="product">'+
                    '<img src="img/'+ data.datos[i].ruta_img +'" alt="Cargando">'+
                    '<div class="detail-title">'+ data.datos[i].nombre +'</div>'+
                    '<div class="detail-description">'+ data.datos[i].descripcion +'</div>'+
                    '<div class="detail-price">'+ data.datos[i].precio +' <span>EclipseCoins</span></div>'+
                '</div>'+
            '</a>'+
        '</div>';
        }
        document.getElementById("space-list").innerHTML=html;
    },
        error:function(err){
        console.log(err);
    }
});
});