<?php
require_once "includes/config.php";
$sql = "DELETE FROM misiones WHERE id=" . $_GET['id'];

$res = mysqli_query($conn, $sql);
if (!$res) {
    die('Error de Consulta ' . mysqli_error($conn));
}

header('Location: misiones.php');
