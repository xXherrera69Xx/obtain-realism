<script src="<?php echo $fileinfo; ?>usuariosadm.js"></script>

<body class="adminm">
    <div class="modal" id="modal-object-edit" style="display: none;">
        <div class="body-modal">
            <button class="btn-close" onclick="hide_modal('modal-object-edit')"><i class="fa fa-times" aria-hidden="true"></i></button>
            <h3>Editar Usuario</h3>
            <div class="div-flex">
                <label>ID</label>
                <input type="text" id="id_usu-e" disabled>
            </div>
            <div class="div-flex">
                <label>Usuario</label>
                <input type="text" id="usuario_usu-e">
            </div>
            <div class="div-flex">
                <label>Email</label>
                <input type="text" id="mail_usu-e">
            </div>
            <div class="div-flex">
                <label>Clave</label>
                <input type="text" id="clave_usu-e">
            </div>
            <div class="div-flex">
                <label>Color de piel</label>
                <select id="personaje_id-e">
                    <option value="1">Negro</option>
                    <option value="2">Blanco</option>
                </select>
            </div>
            <div class="div-flex">
                <label>Monedas</label>
                <input type="number" id="monedas_usu-e">
            </div>
            <button class="btn-save" onclick="update_usu()">Actualizar</button>
        </div>
    </div>
    <div class="body-pagem">
        <h2>Usuarios</h2>
        <table class="mt10">
            <thead>
                <tr>
                    <th>ID Usuario</th>
                    <th>Nombre</th>
                    <th>Mail</th>
                    <th>Contraseña</th>
                    <th>Monedas</th>
                    <th class="td-option">Opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * from usuario";
                $resultado = mysqli_query($conn, $sql);
                while ($row = mysqli_fetch_array($resultado)) {
                    echo '<tr>
                    <td class="idtd">' . $row['id_usu'] . '</td>
                    <td class="nombretd">' . $row['usuario_usu'] . '</td>
                    <td class="descripciontd">' . $row['mail_usu'] . '</td>
                    <td class="preciotd">' . $row['clave_usu'] . '</td>
                    <td class="preciotd">' . $row['monedas_usu'] . '</td>
                    <td class="td-option">
                        <div class="div-flexop div-td-button">
                            <button class="btn-op"><i class="fa fa-pencil" onclick="edit_usu(' . $row['id_usu'] . ')"></i></button>
                            <button class="btn-op"><i class="fa fa-trash" onclick="delete_usu(' . $row['id_usu'] . ')"></i></button>
                        </div>
                    </td>
                </tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    </div>
</body>