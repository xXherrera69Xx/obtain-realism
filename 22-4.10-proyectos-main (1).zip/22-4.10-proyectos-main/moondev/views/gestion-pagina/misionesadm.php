<script src="<?php echo $fileinfo; ?>misionesadm.js"></script>

<body class="adminm">
    <div class="modal" id="modal-object" style="display: none;">
        <div class="body-modal">
            <button class="btn-close" onclick="hide_modal('modal-object')"><i class="fa fa-times" aria-hidden="true"></i></button>
            <h3>Crear Mision</h3>
            <input type="text" id="id_mis" style="display: none;">
            <div class="div-flex">
                <label>Imagen</label>
                <input type="file" id="mis_rutaimg">
            </div>
            <div class="div-flex">
                <label>Titulo</label>
                <input type="text" id="titulo_mis">
            </div>
            <div class="div-flex">
                <label>Descripcion</label>
                <input type="text" id="descripcion_mis">
            </div>
            <div class="div-flex">
                <label>Oro</label>
                <input type="number" id="oro_mis">
            </div>
            <div class="div-flex">
                <label>Winrate</label>
                <select id="winrate_mis">
                    <option value="10">10%</option>
                    <option value="20">20%</option>
                    <option value="30">30%</option>
                    <option value="40">40%</option>
                    <option value="50">50%</option>
                    <option value="60">60%</option>
                    <option value="70">70%</option>
                    <option value="80">80%</option>
                    <option value="90">90%</option>
                    <option value="100">100%</option>
                </select>
            </div>
            <div class="div-flex">
                <label>Droprate</label>
                <select id="droprate_mis">
                    <option value="10">10%</option>
                    <option value="20">20%</option>
                    <option value="30">30%</option>
                    <option value="40">40%</option>
                    <option value="50">50%</option>
                    <option value="60">60%</option>
                    <option value="70">70%</option>
                    <option value="80">80%</option>
                    <option value="90">90%</option>
                    <option value="100">100%</option>
                </select>
            </div>
            <button class="btn-save" onclick="save_mis()">Crear Misión</button>
        </div>
    </div>
    <div class="modal" id="modal-object-edit" style="display: none;">
        <div class="body-modal">
            <button class="btn-close" onclick="hide_modal('modal-object-edit')"><i class="fa fa-times" aria-hidden="true"></i></button>
            <h3>Editar Mision</h3>
            <div class="div-flex">
            <label>Id</label>
            <input type="text" id="id_mis-e" disabled>
            </div>
            <div class="div-flex">
                <label style="padding-top: 100px;" class="label-img">Imagen</label>
                <div style="border: 1px solid; width:100%;" ><img id="rutimgmis" src=""><input type="file" id="mis_rutaimg-e" ></div>
            </div>    
            <div class="div-flex">
                <label>Titulo</label>
                <input type="text" id="titulo_mis-e">
            </div>
            <div class="div-flex">
                <label>Descripcion</label>
                <input type="text" id="descripcion_mis-e">
            </div>
            <div class="div-flex">
                <label>Oro</label>
                <input type="number" id="oro_mis-e">
            </div>
            <div class="div-flex">
                <label>Winrate</label>
                <select id="winrate_mis-e">
                    <option value="10">10%</option>
                    <option value="20">20%</option>
                    <option value="30">30%</option>
                    <option value="40">40%</option>
                    <option value="50">50%</option>
                    <option value="60">60%</option>
                    <option value="70">70%</option>
                    <option value="80">80%</option>
                    <option value="90">90%</option>
                    <option value="100">100%</option>
                </select>
            </div>
            <div class="div-flex">
                <label>Droprate</label>
                <select id="droprate_mis-e">
                    <option value="10">10%</option>
                    <option value="20">20%</option>
                    <option value="30">30%</option>
                    <option value="40">40%</option>
                    <option value="50">50%</option>
                    <option value="60">60%</option>
                    <option value="70">70%</option>
                    <option value="80">80%</option>
                    <option value="90">90%</option>
                    <option value="100">100%</option>
                </select>
            </div>
            <input type="text" id="rutimgmis-aux" style="display: none;">
            <button class="btn-save" onclick="update_mis()">Actualizar</button>
        </div>
    </div>
        <div class="body-pagem">
            <h2>Misiones</h2>
            <table class="mt10">
                <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Descripcion</th>
                        <th>Oro</th>
                        <th class="td-option">Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * from misiones";
                    $resultado = mysqli_query($conn, $sql);
                    while ($row = mysqli_fetch_array($resultado)) {
                        echo '<tr>
                    <td class="idtd"><img src="../img/'. $row['mis_rutaimg'] .'"></td>
                    <td class="idtd">' . $row['id_mis'] . '</td>
                    <td class="nombretd">' . $row['titulo_mis'] . '</td>
                    <td class="descripciontd">' . $row['descripcion_mis'] . '</td>
                    <td class="preciotd">' . $row['oro_mis'] . '</td>
                    <td class="td-option">
                        <div class="div-flexop div-td-button">
                            <button class="btn-op"><i class="fa fa-pencil" onclick="edit_mis(' . $row['id_mis'] . ')"></i></button>
                            <button class="btn-op"><i class="fa fa-trash" onclick="delete_mis(' . $row['id_mis'] . ')"></i></button>
                        </div>
                    </td>
                </tr>';
                    }
                    ?>
                </tbody>
            </table>
            <button class="botonag" onclick="show_modal('modal-object')">Crear Mision</button>
        </div>
    </div>
</body>