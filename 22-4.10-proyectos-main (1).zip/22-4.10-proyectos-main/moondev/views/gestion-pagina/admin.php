<body class="adminb">
<button onclick="login()">Ingresar</button>
<script type="text/javascript">
    function login(){
        window.location.href="main.php";
    }
    </script>
</body>