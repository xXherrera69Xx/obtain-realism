<body class="adminm">
    <div class="main-container">
        <div class="body-pagem">
           <h2>Bienvenido</h2>
        </div>
    </div>
</body>