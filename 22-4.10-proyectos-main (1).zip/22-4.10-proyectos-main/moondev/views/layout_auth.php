<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="includes/jquery3.6.0.js"></script>
    <script src="controllers/auth/ajax.js"></script>
    <script src="controllers/auth/response.js"></script>
    <title>Autentificacion</title>
</head>
<body class="login">
    <div class="formulario">
        <img src="img/luna.jpg" alt="Cargando..." class="icono">
        <?php require_once ("views/" . $folder. "/" . $section); ?>
    </div>
    <div class="texto">Si olvidaste tu contraseña hace click <a href="#">aqui</a>
</body>
</html>