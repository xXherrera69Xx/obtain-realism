<?php require_once("api/misiones.php"); ?>

<div class="miscont">
    <?php foreach ($misiones as $mision) { ?>
        <div class="divmis" style="border-style: solid;">
            <h2><?php echo $mision['titulo_mis'] ?></h2>
            <br>
            <?php echo $mision['descripcion_mis'] ?>
            <a href="misiones_eliminar.php?id=<?php echo $mision['id'] ?>">Eliminar</a>
        </div>
    <?php } ?>
</div>