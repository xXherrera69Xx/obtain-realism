<link rel="stylesheet" type="text/css" href="<?php echo $fileinfo; ?>mercado.css">
<script src="<?php echo $fileinfo; ?>mercado.js"></script>

<body>
    <header>
        <div class="search-place">
            <input type="text" id="idbusqueda" placeholder="Buscar items">
            <button class="btn-main btn-search"><i class="fa fa-search" aria-hidden="true"></i></button>
            <div class="options-place">
                <div class="item-option" title="Configuracion"><i class="fa fa-cog " aria-hidden="true"></i></div>
                <div class="item-option" title="Cerrar sesion"><i class="fa fa-sign-in" aria-hidden="true"></i></div>
            </div>
    </header>
    <div class="main-content">
        <div class="content-page">
            <div class="titulo-sec">Mercado General</div>
            <div class="products-list" id="space-list">
            </div>
        </div>
</body>