<div><img src="cofre" alt="Cargando..."></div>
<button class="abrir">Abrir</button>