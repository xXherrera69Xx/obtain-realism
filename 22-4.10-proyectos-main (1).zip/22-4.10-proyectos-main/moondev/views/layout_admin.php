<?php require_once("includes/config.php"); ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Administracion</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="font-awesome\css\font-awesome.min.css">
</head>

<body class="adminm">
    <div class="main-container">
        <div class="body-nav-bar">
            <img src="assets/luna.png" alt="aaa">
            <center>
                <h3>Administrador</h3>
            </center>
            <ul class="mt10">
                <li><a href="<?php echo ($GLOBALS["index_root"]); ?>usuariosadm">Jugadores</a></li>
                <li><a href="<?php echo ($GLOBALS["index_root"]); ?>objetos">Objetos</a></li>
                <li><a href="<?php echo ($GLOBALS["index_root"]); ?>misionesadm">Misiones</a></li>
                <li><a href="<?php echo ($GLOBALS["index_root"]); ?>admin">Salir</a></li>
            </ul>
        </div>
        <div class="body-pagem">
            <?php require_once("views/" . $folder . "/" . $section); ?>
        </div>
    </div>
</body>

</html>