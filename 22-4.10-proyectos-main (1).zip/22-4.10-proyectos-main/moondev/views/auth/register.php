<form action="javascript:loadAjax(true);" class="registro">
    <p id="global"></p>
    <input type="text" name="usuario" id="username" placeholder="Ingrese su nombre de usuario" class="user">
    <p id="mle"></p>
    <br />
    <input type="text" name="clave" id="password" placeholder="Ingrese su clave" class="contra">
    <p id="ple"></p>
    <br />
    <input type="text" name="clave2" id="password2" placeholder="Repita su clave" class="contra">
    <p id="ple2"></p>
    <br />
    <input type="text" name="email" id="email" placeholder="Ingrese su mail" class="email">
    <p id="mle"></p>
    <br />
    <div class="botonescont">
        <br />
        <button class="bot">Crear Usuario</button>
        <button class="bot" onclick="location.href='index.php?seccion=login'" type="button">Iniciar sesion</button>
    </div>
</form>