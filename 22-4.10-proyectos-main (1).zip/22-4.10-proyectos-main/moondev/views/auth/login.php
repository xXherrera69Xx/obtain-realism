<form action="javascript:loadAjax(false);" class="registro">
    <p id="global"></p>
    <input type="email" id="email" name="mail" placeholder="Ingrese su mail" class="email">
    <p id="mle"></p>
    <br />
    <input type="password" id="password" name="contraseña" placeholder="Ingrese su clave" class="contra">
    <p id="ple"></p>
    <br />
    <div class="botonescont">
        <button class="bot">Ingresar</button>
        <button class="bot" onclick="location.href='index.php?seccion=register'" type="button">Registrarse</button>
    </div>
</form>