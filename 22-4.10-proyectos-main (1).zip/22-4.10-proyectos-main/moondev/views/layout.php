<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="font-awesome\css\font-awesome.min.css">
    <script src="includes/jquery3.6.0.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Surmoon</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
    <body class="every">
        <div>
            <div>
                <?php require_once "includes/sidenav.php" ?>
            </div>
            <div >
                <div class="container">
                    <?php require_once ("views/" . $folder. "/" . $section); ?>
                </div>
            </div>
        </div>
    </body>
</html>