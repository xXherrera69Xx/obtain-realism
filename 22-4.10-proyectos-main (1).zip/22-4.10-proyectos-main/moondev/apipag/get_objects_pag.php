<?php
     include("../includes/config.php");
     $response=new stdClass();
     $datos=[];
     $i = 0;
     $sql = "SELECT * FROM objetos WHERE se_vende = 1";
     $result = mysqli_query($conn, $sql);
     while ($row = mysqli_fetch_array($result)) {
          $obj=new stdClass();
          $obj->nombre=$row['nombre'];
          $obj->descripcion= $row['descripcion'] ;
          $obj->precio= $row['precio'] ;
          $obj->ruta_img= $row['ruta_img'] ;
          $datos[$i]=$obj;
          $i++;
     }
     $response->datos=$datos;

     mysqli_close($conn);
     header('Content-Type: application/json');
     echo json_encode($response);
