<?php
class MySQLIclass {
    private $ini_file;
    public $result;
    public $query;
    public $campus;
    public $numrowerror;
    final public function __construct() {
        $this->createMySQLi();
    }
    private function createIniFile() {
        $ini_file = parse_ini_file("mysqli.ini", false);
        if ($ini_file == false) {
            die("Fallo al conectar a la MySQL: No se encuentra el archivo de configuracion");
        }
        return $ini_file;
    }
    private function createMySQLi() {
        $ini_file = $this->createIniFile();
        $GLOBALS["mysqli"] = new mysqli($ini_file["hostname"], $ini_file["username"], $ini_file["password"], $ini_file["database"], $ini_file["port"]);
        if ($GLOBALS["mysqli"]->connect_errno) {
            die('No pudo conectarse: ' . $GLOBALS["mysqli"]->connect_errno . " " .  $GLOBALS["mysqli"]->connect_error);
        }
    }
    // Si el resultado devuelve >= a 1 fila de resultados, tirar una excepcion.
    public function numRowIsZero($numrowerror, $result) {
        if (($result->num_rows) > 0) { throw new Exception($numrowerror); }
        else { return true; }
    }
    // Si el resultado devuelve 0 filas de resultados, tirar una excepcion.
    public function numRowIsNotZero($numrowerror, $result) {
        if (($result->num_rows) == 0) { throw new Exception($numrowerror); }
        else { return true; }
    }
    public function storeMySQLiResult_exception($result, $exception) {
        if (!($result)) { 
            $this->mysqli_query_failed_fatal(false);
            throw new Exception($exception); 
        }
        else { return true; }
    }
    public function fetchArray($query, $campus) {
        $tablearray = [];
        $result = $GLOBALS["mysqli"]->query($query);
        while ($row = $result->fetch_assoc()) {
            array_push($tablearray, $row[$campus]);
        }
        return $tablearray;
    }
    public function mysqli_function_close() {
        mysqli_close($GLOBALS["mysqli"]);
        //echo("Se cerro la conexion");
    }
    public function mysqli_query_failed_fatal($silent) {
        if ($silent !== true) { echo("Fallo en la consulta: " . $GLOBALS["mysqli"]->error . "."); }
        $this->mysqli_function_close();
    }
    public function __destruct() {
        //echo("Se llamo al destructor");
        if ($GLOBALS["mysqli"]->ping() !== false) { $this->mysqli_function_close(); }
    }
}

function createClass() {
    $GLOBALS["mClass"] = new MySQLIclass;
}
?>