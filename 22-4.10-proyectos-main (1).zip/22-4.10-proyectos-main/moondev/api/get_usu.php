<?php
include("../includes/config.php");
$response = new stdClass();

$id_usu = $_POST['id_usu'];
$sql = "SELECT * FROM usuario WHERE id_usu=$id_usu";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

$obj = new stdClass();
$obj->usuario_usu = utf8_encode($row['usuario_usu']);
$obj->mail_usu = utf8_encode($row['mail_usu']);
$obj->clave_usu = utf8_encode($row['clave_usu']);
$obj->monedas_usu = $row['monedas_usu'];
$obj->personaje_id = $row['personaje_id'];

$response->users = $obj;

echo json_encode($response);
