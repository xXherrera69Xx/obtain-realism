<?php
require_once "includes/config.php";

$sql = "SELECT * FROM misiones";
$res = mysqli_query($conn, $sql);
if (!$res) {
    die('Error de Consulta ' . mysqli_error($conn));
}

while ($fila = mysqli_fetch_assoc($res)) {
    $misiones[] = $fila;
}

$section = "misiones";
