<?php
function exception_error_handler($error_level, $error_message, $error_file, $error_line, $error_context)
{
    $section = 'technical_error';
}
set_error_handler("exception_error_handler");
