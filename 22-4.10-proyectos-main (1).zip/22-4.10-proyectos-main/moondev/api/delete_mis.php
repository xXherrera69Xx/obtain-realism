<?php

include("../includes/config.php");
$response = new stdClass();

$id_mis = $_POST['id_mis'];
$sql = "DELETE FROM misiones WHERE id_mis=$id_mis";

$result = mysqli_query($conn, $sql);

if ($result) {
    $response->state = true;
} else {
    $response->state = false;
    $response->detail = "No se pudo eliminar el objeto";
}

echo json_encode($response);
