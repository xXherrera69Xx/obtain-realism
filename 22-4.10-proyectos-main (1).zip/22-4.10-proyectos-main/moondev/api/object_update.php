<?php

include("../includes/config.php");
$response = new stdClass();

//$response -> state=true;
$codigo = $_POST['codigo'];
$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$precio = $_POST['precio'];
$rareza = $_POST['rareza'];
$enventa = $_POST['enventa'];
$rutimgobj = $_POST['rutimgobj'];

if ($nombre == "") {
    $response->state = false;
    $response->detail = "Falta el nombre";
} else {
    if ($descripcion == "") {
        $response->state = false;
        $response->detail = "Falta la descripcion";
    } else {
        if ($precio == "") {
            $response->state = false;
            $response->detail = "Falta el precio";
        } else {
            if ($rareza == "") {
                $response->state = false;
                $response->detail = "Falta La rareza";
            } else {
                if (isset($_FILES['imagen'])) {
                    $nombre_imagen = date("YmdHis") . ".jpg";
                    $sql = "UPDATE objetos SET nombre = '$nombre', descripcion = '$descripcion', precio = $precio, rareza_id = $rareza, se_vende = $enventa, ruta_img = '$nombre_imagen' WHERE id_obj = '$codigo'";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        if (move_uploaded_file($_FILES['imagen']['tmp_name'], "../img/" . $nombre_imagen)) {
                            $response->state = true;
                            unlink("../img/" . $rutimgobj);
                        } else {
                            $response->state = false;
                            $response->detail = "Error al cargar la imagen";
                        }
                    } else {
                        $response->state = false;
                        $response->detail = "No se pudo actualizar el objeto";
                    }
                } else {
                    $sql = "UPDATE objetos SET nombre = '$nombre', descripcion = '$descripcion', precio = $precio, rareza_id = $rareza, se_vende = $enventa WHERE id_obj = '$codigo'";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        $response->state = true;
                    } else {
                        $response->state = false;
                        $response->detail = "No se pudo actualizar el objeto";
                    }
                }
            }
        }
    }
}

echo json_encode($response);
