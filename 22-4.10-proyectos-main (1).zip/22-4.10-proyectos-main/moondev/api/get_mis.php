<?php
include("../includes/config.php");
$response = new stdClass();

$id_mis = $_POST['id_mis'];
$sql = "SELECT * FROM misiones WHERE id_mis=$id_mis";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

$obj = new stdClass();
$obj->titulo_mis = utf8_encode($row['titulo_mis']);
$obj->descripcion_mis = utf8_encode($row['descripcion_mis']);
$obj->oro_mis = $row['oro_mis'];
$obj->droprate_mis = $row['droprate_mis'];
$obj->winrate_mis = $row['winrate_mis'];
$obj->mis_rutaimg = $row['mis_rutaimg'];
$response->missions = $obj;

echo json_encode($response);
