<?php
class autoLogin {
    public function __construct() {
        $this->inicializate();
    }
    public function inicializate() {
        session_start();
        $this->expirationCode = (14 * 24 * 60 * 60);
        session_set_cookie_params($this->expirationCode);
    }
    public function isLogged() {
        if (isset($_SESSION['userid'])) {
            return true;
        } else {
            return false;    
        }
    }
}