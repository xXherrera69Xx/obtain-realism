<?php

$GLOBALS['response'] = new stdClass;

function login_exception_handler($exception) {
    $GLOBALS['response']->http_code = $exception->getCode();
    $GLOBALS['response']->message = $exception->getMessage(); 
    echo(json_encode($GLOBALS['response']));
    die;
}

set_exception_handler('login_exception_handler');

function error_handler($errno, $errstr, $errline) {
    $GLOBALS['response']->errno = $errno;
    $GLOBALS['response']->errstr = $errstr;
    $GLOBALS['response']->errline = $errline;
    throw new Exception("global.ErrorException", 500);
}

set_error_handler("error_handler");

function query_success() {
    $GLOBALS['response']->http_code = 200;
    $GLOBALS['response']->message = 'La consulta fue un exito';
    echo(json_encode($GLOBALS['response']));
    die;
}

// Datos de prueba, desactivar en caso de uso real.

/*
$_POST['email'] = 'nicokrule@gmail.com';
$_POST['username'] = 'test205';
$_POST['password'] = 'EJEJ78372378sdndn&';
$_POST['password2'] = 'EJEJ78372378sdndn&';
$_POST['birthdate'] = '26-06-2005';
*/

if ($_SERVER['REQUEST_METHOD'] ===  'POST') { 

require_once("mysqli_connector.php");

abstract class validateData {
    public static $error;
    public static $error2;
    public static $error3;
    public static $htmlchars;
    public static $information;
    protected $result;
    protected $isRegister;
    protected $data;
    protected $useemail;
    protected const REGEX_PASSWORD_NUMBER = "/(?=.*\d)/";
    protected const REGEX_PASSWORD_LOWERCASE = "/(?=.*[a-z])/";
    protected const REGEX_PASSWORD_UPPERCASE = "/(?=.*[A-Z])/";
    protected const REGEX_PASSWORD_SPECIAL = "/(?=.*\W)/";
    public const REGEX_SLASH = "/(?=.*[\/])/";
    protected const PASSWORD_MAX_LENGHT = 32;
    protected const PASSWORD_MIN_LENGHT = 8;
    protected const USERNAME_MAX_LENGHT = 15;
    protected const USERNAME_MIN_LENGHT = 4;

    protected function __construct($isRegister, $useEmail) {
        $this->validateDataSuccess = false;
        $this->isRegister = $isRegister;
        $this->useemail = $useEmail;
        $this->getData($this->isRegister);
        $this->validateEmail();
        $this->validatePassword();
        if ($this->isRegister === true) {
            $this->doPasswordMatch();
            $this->validateUsername();
            $this->validateBirthdate();
        }
        $this->hashPassword();
        $this->validateDataSuccess = true;
    }
    public static function dataExists($data, $error, $error2, $error3, $htmlchars) {
        if ((isset($_POST[$data]) !== true) || ($_POST[$data] == (null || ""))) { throw new Exception($error, 401); }
        else if (gettype($_POST[$data]) !== 'string') { throw new Exception($error2, 401); } 
        else if ((preg_match(self::REGEX_SLASH, $_POST[$data])) !== 0) { throw new Exception($error3, 401); }
        else { 
            $information = stripslashes(trim($_POST[$data]));
            if ($htmlchars === true) {
                $information = htmlspecialchars($information);
            }
            //echo("<pre>" . print_r([$_POST[$data]]) . "</pre>");
            return $information;
            }
        }
    protected function getData() {
        $this->email = $this->dataExists('email', 'mle.empty', 'mle.non_string', 'mle.slash', true);
        $this->password = $this->dataExists('password', 'ple.empty', 'ple.non_string', 'ple.slash', false);
        $this->password_lenght = strlen($this->password);
        if ($this->isRegister === true) {
            $this->username = $this->dataExists('username', 'username.empty', 'username.non_string', 'username.slash', true);
            $this->username_lenght = strlen($this->username);
            $this->birthdate = $this->dataExists('birthdate', 'birthdate.empty', 'birthdate.non_string', 'birthdate.slash', true);
            $this->password2 = $this->dataExists('password2', 'ple.empty', 'ple.non_string', 'ple.slash', false);
        }
    }
    protected function validateEmail() {
        if (filter_var($this->email, FILTER_VALIDATE_EMAIL)) { return true; } 
        else { throw new Exception("mle.wrong", 401); }
    }
    protected function validatePassword() {
        if (($this->password_lenght > self::PASSWORD_MAX_LENGHT) !== false) { throw new Exception("ple.max_error", 401); }
        else if (($this->password_lenght < self::PASSWORD_MIN_LENGHT) !== false) { throw new Exception("ple.min_error", 401); }
        else if ((preg_match(self::REGEX_PASSWORD_NUMBER, $this->password)) !== 1) { throw new Exception("ple.missing.number", 401); }
        else if ((preg_match(self::REGEX_PASSWORD_LOWERCASE, $this->password)) !== 1) { throw new Exception("ple.missing.lowercase", 401); }
        else if ((preg_match(self::REGEX_PASSWORD_UPPERCASE, $this->password)) !== 1) { throw new Exception("ple.missing.uppercase", 401); }
        else if ((preg_match(self::REGEX_PASSWORD_SPECIAL, $this->password)) !== 1) { throw new Exception("ple.missing.special", 401); }
        else { return true; };
    }
    protected function doPasswordMatch() {
        if (($this->password) === ($this->password2)) { return true; }
        else { throw new Exception("ple.not_the_same", 401); }
    }
    protected function validateUsername() {
        if (($this->username_lenght > self::USERNAME_MAX_LENGHT) !== false) { throw new Exception("username.max_error", 401);}
        else if (($this->username_lenght < self::USERNAME_MIN_LENGHT) !== false) { throw new Exception("username.min_error", 401); }
        else { return true; }
    }
    protected function validateBirthdate() {
        // Falta completar
        return ("2022-10-12");
    }
    protected function hashPassword() {
        $this->password_hashed = password_hash($this->password, PASSWORD_DEFAULT);
        echo ("<pre> Contrasenia hasheada: " . $this->password_hashed . "<pre>");
        return true;
    }
    protected function selectUserID($useemail) {
        $this->query = ("SELECT id FROM usuario WHERE ");
        if ($useemail === true) {
            $this->query .= ("mail = '" . $this->email . "';");
        } else {
            $this->query .= ("usuario = '" . $this->username . "';");
        }
        $result = $GLOBALS["mysqli"]->query($this->query);
        $GLOBALS["mClass"]->storeMySQLiResult_exception($result, 'global.query_failed.selectUserID');       
        $GLOBALS["mClass"]->numRowIsNotZero('global.selectUserID.unknow_userid', $result);
        return $result->fetch_assoc()['id'];
    }
    protected function doesUserExists($isRegister) {
        //$this->query = ("SELECT Email FROM Users WHERE Email='" . $this->email . "';");
        $this->query = ("SELECT mail FROM usuario WHERE mail='" . $this->email . "';");
        $result = $GLOBALS["mysqli"]->query($this->query);
        if ($GLOBALS["mClass"]->storeMySQLiResult_exception($result, "global.doesUserExists.email_failed")) {
            if ($isRegister === true) {
                $GLOBALS["mClass"]->numRowIsZero('mle.used', $result);
            } else {
                $GLOBALS["mClass"]->numRowIsNotZero('eeeeeee', $result);
            }
        }
        //$this->query = ("SELECT Name FROM Users WHERE Name='" . $this->username . "';");
        $this->query = ("SELECT usuario FROM usuario WHERE usuario='" . $this->username . "';");
        $result = $GLOBALS["mysqli"]->query($this->query);
        if ($GLOBALS["mClass"]->storeMySQLiResult_exception($result, "global.doesUserExists.name_failed")) {   
            if ($isRegister === true) {
                $GLOBALS["mClass"]->numRowIsZero('username.used', $result);
            } else {
                $GLOBALS["mClass"]->numRowIsNotZero('username.notFound', $result);
            }
        }
        return true;
    }
    protected function destroyUser($useemail, $destroyAuthToken, $destroyCookie, $destroyUser) {
        //SOLO UTILIZAR EN CASOS DE PRUEBA
        if ($destroyAuthToken === true ) {
        }
        if ($destroyCookie === true) {

        }
        if ($destroyUser === true) {
            $this->query = ("DELETE FROM usuario WHERE ");
            if ($this->useemail === true) {
                $this->query .= ("mail = '" . $this->email . "';");
            } else {
                $this->query = ("");
            }
        }
        return true;
    }
}

/*
trait createCookie {
    // Faltan corregir errores
    private $expirationDays;
    private function cookieConstructor() {
        //Este constructor requiere si o si un UserID para funcionar.
        if (isset($this->userid) !== true) { throw new Exception("global.cookie.unknow_userid", 500); }
        $this->createToken();
        $this->databaseToken();
        $this->setUserCookie();
    }
    private function createToken() {
        $expirationDays = 30;
        $this->unhashedToken = random_bytes(32);
        $this->expirationDate = time() + ($expirationDays * 24 * 60 * 60);
        $this->hashedToken = password_hash($this->password, PASSWORD_DEFAULT);
        return true;
    }
    private function databaseToken() {
        $this->query = ("INSERT INTO authTokens(Token, expirationTime, usuario_id) ");
        $this->query .= ("VALUES ('" . $this->hashedToken . "', '" . $this->expirationDate ."', '" . $this->userid . "');");
        $result = $GLOBALS["mysqli"]->query($this->query);
        $GLOBALS["mClass"]->storeMySQLiResult_exception($result, "global.cookie.database_failed");
        return true;
    }
    private function setUserCookie() {
        setcookie("moondev_login", $this->unhashedToken, $this->expirationDate, "/", "", false, true);
        return true;
    }
}
*/

trait createSessionID {
    private function sessionConstructor() {
        $this->isLogged();
    }
    private function isLogged() {
        require_once 'api/islogged.php';
        $GLOBALS['authentification_login']  = new autoLogin;
        session_unset();
        $_SESSION['userid'] = $this->userid();
        return true;
    }
}

class register extends validateData {
    protected $result;
    //use createCookie;
    use createSessionID;
    final public function __construct() {
        //$this->saveSession = $saveSession;
        parent::__construct(true, true);
        if ($this->validateDataSuccess === true) {
            createClass();
            $this->doesUserExists($this->isRegister);
            $this->createUser();
            $this->userid = $this->selectUserID(true);
            //if ($this->saveSession === true) { $this->cookieConstructor(); }
            $this->sessionConstructor();
            query_success();
        }
    }
    private function createUser() {
        //$this->finalquery = "INSERT INTO Users(ID, Name, Email, Password, birthdate, activation_date, desactivation_date, moderationRoles_ID, suscriptions_ID, email_validated, points) ";
        //$this->finalquery .= "VALUES (" . rand(20050, 20200) . ", '" . $this->username . "', '" .  $this->email . "', '" . $this->password_hashed . "', " . $this->birthdate . ", NOW(), null, 1, 3, false, 100);";
        $this->finalquery = ("INSERT INTO usuario(ID, mail, clave, personaje_id, usuario, monedas) ");
        $this->finalquery .= ("VALUES(" . rand(100, 200) . ", '" . $this->email . "', '" . $this->password_hashed . "', 100, '" . $this->username . "', 100);");
        $result = $GLOBALS["mysqli"]->query($this->finalquery);
        $GLOBALS["mClass"]->storeMySQLiResult_exception($result, "global.query_failed.register");
        return true;
    }
}

class login extends validateData {
    //use createCookie;
    use createSessionID;
    final public function __construct() {
        parent::__construct(false, true);
        if ($this->validateDataSuccess === true) {
            createClass();
            $this->doesUserExists(false);
            $this->AuthenticatePassword();
            $this->userid = $this->selectUserID(true);            
            //if ($this->saveSession === true) { $this->cookieConstructor(); }
            $this->sessionConstructor();
            query_success();
        }       
    }
    private function AuthenticatePassword() {
        $this->finalquery = ("SELECT clave FROM usuario WHERE clave = '" . $this->hashed_password . "');");
        $result = $GLOBALS["mysqli"]->query($this->finalquery);
        $GLOBALS["mClass"]->storeMySQLiResult_exception($result, "global.query_failed.login");
        $GLOBALS["mClass"]->numRowIsNotZero('ple.wrong', $result);
        return true;
    }
}

$test = new register(true);

} else {
    throw new Exception("global.invalid_request_method", 400);
}
?>