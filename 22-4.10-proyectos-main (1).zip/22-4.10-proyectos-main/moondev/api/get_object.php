<?php
include("../includes/config.php");
$response = new stdClass();

$id_obj = $_POST['id_obj'];
$sql = "SELECT * FROM objetos WHERE id_obj=$id_obj";

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result);

$obj = new stdClass();
$obj->nombre = utf8_encode($row['nombre']);
$obj->descripcion = utf8_encode($row['descripcion']);
$obj->precio = $row['precio'];
$obj->rareza_id = $row['rareza_id'];
$obj->ruta_img = $row['ruta_img'];
$obj->se_vende = $row['se_vende'];
$response->products = $obj;

echo json_encode($response);
