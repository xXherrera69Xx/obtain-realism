<?php

include("../includes/config.php");
$response = new stdClass();

$id_usu = $_POST['id_usu'];
$sql = "DELETE FROM usuario WHERE id_usu=$id_usu";

$result = mysqli_query($conn, $sql);

if ($result) {
    $response->state = true;
} else {
    $response->state = false;
    $response->detail = "No se pudo eliminar el objeto";
}

echo json_encode($response);
