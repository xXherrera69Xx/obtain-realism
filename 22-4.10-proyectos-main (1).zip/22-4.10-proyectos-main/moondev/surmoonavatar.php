<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Surmoon</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body class="fondoav">
  <div class="sidenav">
    <?php include "includes/sidenav.php" ?>
  </div>
  <div class="avatar">
    <img src="img/h3.png" alt="cargando" class="humano">
  </div>
  <div class="items">
    <table class="tab_items"> 
      <tr>
        <td class="equip_tab_items">Casco</td>
        <td class="equip_tab_items">Armadura</td>
      </tr>
      <tr>
        <td class="equip_tab_items">Piernas</td>
        <td class="equip_tab_items">Arma</td>
      </tr>
      <tr>
        <td class="equip_tab_items">Botas</td>
        <td class="equip_tab_items">Mascota</td>
      </tr>
    </table>
  </div>
  <table class="objetos">
    <tbody class="tablaobj">
      <tr class="primero">
        <th>Inventario</th>
      </tr>
      <tr>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
        <td class="avatart">Objeto</td>
      </tr>
    </tbody>
  </table>
</body>
</html>