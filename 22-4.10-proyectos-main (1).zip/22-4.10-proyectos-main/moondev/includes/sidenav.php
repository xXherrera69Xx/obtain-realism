<div class="main-container">
    <div class="body-nav-bar">
        <ul class="mt10">
            <li><a href="<?php echo ($GLOBALS["index_root"]) ?>mercado"><img src="img/mercado.png" class="img-sidenav"></a></li>
            <li><a href="<?php echo ($GLOBALS["index_root"]) ?>404"><img src="img/monline.png" class="img-sidenav"></a></li>
            <li><a href="<?php echo ($GLOBALS["index_root"]) ?>misiones"><img src="img/misiones.png" class="img-sidenav"></a></li>
        </ul>
    </div>
</div>